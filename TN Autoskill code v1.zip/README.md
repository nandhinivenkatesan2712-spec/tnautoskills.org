
  # Clickable Design with Scroll Animation

  This is a code bundle for Clickable Design with Scroll Animation. The original project is available at https://www.figma.com/design/2ihMiew7gdAslkEEADDhWP/Clickable-Design-with-Scroll-Animation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  