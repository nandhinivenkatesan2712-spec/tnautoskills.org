import { createContext, useContext, useState, useEffect, ReactNode } from "react";

type Language = "EN" | "தமிழ்";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    // Load saved language preference from localStorage
    const saved = localStorage.getItem("tn-auto-skills-language");
    return (saved as Language) || "EN";
  });

  useEffect(() => {
    // Save language preference to localStorage
    localStorage.setItem("tn-auto-skills-language", language);
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): string => {
    // Import translations dynamically
    const translations = language === "தமிழ்" ? tamilTranslations : englishTranslations;
    
    // Navigate nested keys (e.g., "header.home")
    const keys = key.split(".");
    let value: any = translations;
    
    for (const k of keys) {
      value = value?.[k];
    }
    
    return value || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return context;
}

// English Translations
const englishTranslations: any = {
  header: {
    home: "Home",
    aboutUs: "About Us",
    courses: "Courses",
    careers: "Careers",
    successStories: "Success Stories",
    exploreMore: "Explore More",
    contact: "Contact",
    gallery: "Gallery",
    news: "News",
    events: "Events",
    podcast: "Podcast",
    applyNow: "Apply Now",
    brandName: "TN AutoSkills",
    brandSubtitle: "Skill Development Centre",
    topBarTamil: "தமிழ்நாடு உயர்திறன் மேம்பாட்டு மையம் - ஆட்டோமொபைல்",
    topBarEnglish: "Tamil Nadu Apex Skill Development Centre for Automobile",
  },
  hero: {
    title: "Transform Your Automotive Career",
    subtitle: "Government-Certified Training Programs for the Next Generation of Automotive Professionals",
    exploreCourses: "Explore Courses",
    applyNow: "Apply Now",
  },
  whoWeAre: {
    title: "Who We Are",
    description: "TN Auto Skills is a government initiative focused on developing industry-ready automotive talent across Tamil Nadu and preparing the next-generation workforce for global automotive and mobility industries.",
    readMore: "Read More",
    explorePrograms: "Explore Programs",
  },
  featuredPrograms: {
    title: "Featured Training Programs",
    subtitle: "Industry-aligned certification programs",
    duration: "Duration",
    viewDetails: "View Details",
    advanced: "Advanced",
    intermediate: "Intermediate",
    beginner: "Beginner",
    months: "Months",
    programs: {
      ev: "Electric Vehicle Technology",
      ast: "Automotive Service Technician",
      cvs: "Connected Vehicle Systems",
      hvm: "Hybrid Vehicle Maintenance",
    },
  },
  stakeholders: {
    title: "Empowering Every Stakeholder",
    candidates: {
      title: "Candidates",
      description: "Access government-certified training, hands-on skills, and direct placement opportunities.",
    },
    industry: {
      title: "Industry",
      description: "Partner with us to build a skilled workforce aligned with your technology needs.",
    },
    academia: {
      title: "Academia",
      description: "Collaborate on curriculum development and provide students with industry exposure.",
    },
    trainers: {
      title: "Trainers & Assessors",
      description: "Join our network of certified professionals delivering world-class training.",
    },
    learnMore: "Learn More",
  },
  coe: {
    title: "Centre of Excellence",
    subtitle: "World-Class Training Infrastructure",
    description: "State-of-the-art facilities equipped with the latest automotive technology, providing hands-on learning experiences in EV systems, diagnostics, and advanced manufacturing processes.",
    features: {
      labs: "Modern Labs",
      equipment: "Industry Equipment",
      technology: "Latest Technology",
      certification: "Global Standards",
    },
    exploreFacilities: "Explore Facilities",
  },
  curriculum: {
    title: "Global Automotive Curriculum Framework",
    subtitle: "Industry-Aligned Learning Pathways",
    description: "Our curriculum is designed in collaboration with leading automotive manufacturers and aligned with international standards, ensuring graduates are job-ready from day one.",
    viewCurriculum: "View Curriculum",
    modules: {
      foundation: "Foundation Modules",
      advanced: "Advanced Technology",
      practical: "Practical Training",
      certification: "Industry Certification",
    },
  },
  partners: {
    title: "Our Partners",
    subtitle: "Trusted by leading automotive companies",
  },
  employment: {
    title: "Employment Opportunities",
    subtitle: "Connect with Top Automotive Employers",
    description: "Access exclusive job openings from our network of industry partners including OEMs, suppliers, and service networks.",
    viewOpenings: "View Job Openings",
    registerNow: "Register Now",
    stats: {
      companies: "Partner Companies",
      openings: "Active Openings",
      placements: "Successful Placements",
      rate: "Placement Rate",
    },
  },
  hrRegistration: {
    title: "HR Registration for Recruitment",
    badge: "Recruitment",
    description: "Register your organization to access our pool of trained and certified automotive professionals.",
    points: {
      candidates: "Access to 2500+ trained candidates",
      certified: "Industry-certified professionals",
      process: "Streamlined recruitment process",
    },
    registerNow: "Register Now",
    contactUs: "Contact Us",
  },
  csr: {
    title: "CSR Projects",
    subtitle: "Collaborate with us on Corporate Social Responsibility initiatives",
    projects: {
      community: {
        title: "Community Skill Development",
        description: "Partner with us to provide free automotive training to underprivileged youth and create employment opportunities in rural Tamil Nadu.",
      },
      women: {
        title: "Women in Automotive Initiative",
        description: "Support our program to train and empower women in automotive technology, breaking gender barriers in the industry.",
      },
    },
    register: "CSR Partnership Registration",
  },
  academia: {
    title: "Academia & Alumni Support",
    subtitle: "Bridging the gap between academic learning and industry requirements",
    cards: {
      campus: {
        title: "Campus Support",
        description: "Curriculum co-development and faculty training",
      },
      alumni: {
        title: "Alumni Guidance",
        description: "Continuous upskilling and career advancement",
      },
      internship: {
        title: "Internship Pipelines",
        description: "Direct industry connections for students",
      },
      placement: {
        title: "Placement Assistance",
        description: "100% placement support for graduates",
      },
    },
    contact: "Contact Academic Support",
  },
  milestones: {
    title: "Our Milestones",
    subtitle: "Transforming automotive education across Tamil Nadu",
    stats: {
      trained: "Students Trained",
      certified: "Certified Professionals",
      placements: "Placements",
      partners: "Industry Partners",
      successRate: "Success Rate",
    },
  },
  successStories: {
    title: "Success Stories",
    subtitle: "Hear from our graduates",
    viewAll: "View All Stories",
  },
  placementRegistration: {
    title: "Placement Registration",
    description: "Register your educational institution to enable your students to access placement opportunities with leading automotive companies through TN Auto Skills.",
    register: "Register Your Institution",
  },
  footer: {
    tagline: "Empowering Automotive Excellence",
    description: "Building India's automotive future through world-class skill development and industry partnerships.",
    quickLinks: "Quick Links",
    programs: "Programs",
    resources: "Resources",
    connect: "Connect",
    newsletter: "Newsletter",
    newsletterText: "Subscribe to receive updates on programs and opportunities",
    subscribe: "Subscribe",
    emailPlaceholder: "Enter your email",
    links: {
      about: "About Us",
      courses: "Courses",
      careers: "Careers",
      contact: "Contact",
      admissions: "Admissions",
      faculty: "Faculty",
      facilities: "Facilities",
      blog: "Blog",
      news: "News",
      events: "Events",
      gallery: "Gallery",
    },
    followUs: "Follow Us",
    rights: "All rights reserved.",
    govt: "Government of Tamil Nadu",
  },
  common: {
    learnMore: "Learn More",
    readMore: "Read More",
    viewMore: "View More",
    viewAll: "View All",
    exploreNow: "Explore Now",
    getStarted: "Get Started",
    contactUs: "Contact Us",
    apply: "Apply",
    register: "Register",
    submit: "Submit",
    cancel: "Cancel",
    close: "Close",
    next: "Next",
    previous: "Previous",
    loading: "Loading...",
    search: "Search",
  },
};

// Tamil Translations
const tamilTranslations: any = {
  header: {
    home: "முகப்பு",
    aboutUs: "எங்களைப் பற்றி",
    courses: "பாடநெறிகள்",
    careers: "தொழில் வாய்ப்புகள்",
    successStories: "வெற்றிக் கதைகள்",
    exploreMore: "மேலும் அறிய",
    contact: "தொடர்பு",
    gallery: "படத்தொகுப்பு",
    news: "செய்திகள்",
    events: "நிகழ்வுகள்",
    podcast: "பாட்காஸ்ட்",
    applyNow: "இப்போதே விண்ணப்பிக்கவும்",
    brandName: "டிஎன் ஆட்டோஸ்கில்ஸ்",
    brandSubtitle: "திறன் மேம்பாட்டு மையம்",
    topBarTamil: "தமிழ்நாடு உயர்திறன் மேம்பாட்டு மையம் - ஆட்டோமொபைல்",
    topBarEnglish: "Tamil Nadu Apex Skill Development Centre for Automobile",
  },
  hero: {
    title: "உங்கள் ஆட்டோமோட்டிவ் தொழிலை மாற்றியமைக்கவும்",
    subtitle: "உலகளாவிய ஆட்டோமோட்டிவ் மற்றும் மொபிலிட்டி தொழில்களுக்கான அடுத்த தலைமுறை நிபுணர்களுக்கான அரசு சான்றிதழ் பெற்ற பயிற்சி திட்டங்கள்",
    exploreCourses: "பாடநெறிகளை ஆராயுங்கள்",
    applyNow: "இப்போதே விண்ணப்பிக்கவும்",
  },
  whoWeAre: {
    title: "நாங்கள் யார்",
    description: "டிஎன் ஆட்டோ ஸ்கில்ஸ் என்பது தமிழ்நாடு முழுவதும் தொழில்துறைக்கு தயாரான ஆட்டோமோட்டிவ் திறமையை வளர்ப்பதில் கவனம் செலுத்தும் ஒரு அரசு முன்முயற்சியாகும் மற்றும் உலகளாவிய ஆட்டோமோட்டிவ் மற்றும் மொபிலிட்டி தொழில்களுக்கான அடுத்த தலைமுறை பணியாளர்களை தயார்படுத்துகிறது.",
    readMore: "மேலும் படிக்க",
    explorePrograms: "திட்டங்களை ஆராயுங்கள்",
  },
  featuredPrograms: {
    title: "சிறப்பு பயிற்சி திட்டங்கள்",
    subtitle: "தொழில்துறை சீரமைக்கப்பட்ட சான்றிதழ் திட்டங்கள்",
    duration: "காலம்",
    viewDetails: "விவரங்களைக் காண்க",
    advanced: "மேம்பட்ட",
    intermediate: "இடைநிலை",
    beginner: "ஆரம்ப",
    months: "மாதங்கள்",
    programs: {
      ev: "மின்சார வாகன தொழில்நுட்பம்",
      ast: "ஆட்டோமோட்டிவ் சேவை தொழில்நுட்ப வல்லுநர்",
      cvs: "இணைக்கப்பட்ட வாகன அமைப்புகள்",
      hvm: "கலப்பின வாகன பராமரிப்பு",
    },
  },
  stakeholders: {
    title: "ஒவ்வொரு பங்குதாரரையும் மேம்படுத்துதல்",
    candidates: {
      title: "விண்ணப்பதாரர்கள்",
      description: "அரசு சான்றிதழ் பெற்ற பயிற்சி, நேரடி திறன்கள் மற்றும் நேரடி வேலைவாய்ப்பு வாய்ப்புகளை அணுகவும்.",
    },
    industry: {
      title: "தொழில்துறை",
      description: "உங்கள் தொழில்நுட்ப தேவைகளுக்கு ஏற்ப திறமையான பணியாளர்களை உருவாக்க எங்களுடன் கூட்டு சேரவும்.",
    },
    academia: {
      title: "கல்வி நிறுவனங்கள்",
      description: "பாடத்திட்ட மேம்பாடு மற்றும் மாணவர்களுக்கு தொழில்துறை வெளிப்பாடு வழங்குதல் குறித்து ஒத்துழைக்கவும்.",
    },
    trainers: {
      title: "பயிற்சியாளர்கள் & மதிப்பீட்டாளர்கள்",
      description: "உலகத்தரம் வாய்ந்த பயிற்சியை வழங்கும் சான்றளிக்கப்பட்ட நிபுணர்களின் எங்கள் வலைப்பின்னலில் சேரவும்.",
    },
    learnMore: "மேலும் அறிய",
  },
  coe: {
    title: "சிறப்பு மையம்",
    subtitle: "உலகத்தரம் வாய்ந்த பயிற்சி உள்கட்டமைப்பு",
    description: "மின்சார வாகன அமைப்புகள், கண்டறிதல் மற்றும் மேம்பட்ட உற்பத்தி செயல்முறைகளில் நேரடி கற்றல் அனுபவங்களை வழங்கும் சமீபத்திய ஆட்டோமோட்டிவ் தொழில்நுட்பத்துடன் பொருத்தப்பட்ட நவீன வசதிகள்.",
    features: {
      labs: "நவீன ஆய்வகங்கள்",
      equipment: "தொழில்துறை உபகரணங்கள்",
      technology: "சமீபத்திய தொழில்நுட்பம்",
      certification: "உலகளாவிய தரநிலைகள்",
    },
    exploreFacilities: "வசதிகளை ஆராயுங்கள்",
  },
  curriculum: {
    title: "உலகளாவிய ஆட்டோமோட்டிவ் பாடத்திட்ட கட்டமைப்பு",
    subtitle: "தொழில்துறை சீரமைக்கப்பட்ட கற்றல் பாதைகள்",
    description: "எங்கள் பாடத்திட்டம் முன்னணி ஆட்டோமோட்டிவ் உற்பத்தியாளர்களுடன் இணைந்து வடிவமைக்கப்பட்டுள்ளது மற்றும் சர்வதேச தரநிலைகளுடன் இணைக்கப்பட்டுள்ளது, பட்டதாரிகள் முதல் நாளிலிருந்தே வேலைக்குத் தயாராக உள்ளனர் என்பதை உறுதி செய்கிறது.",
    viewCurriculum: "பாடத்திட்டத்தைக் காண்க",
    modules: {
      foundation: "அடிப்படை தொகுதிகள்",
      advanced: "மேம்பட்ட தொழில்நுட்பம்",
      practical: "நடைமுறை பயிற்சி",
      certification: "தொழில்துறை சான்றிதழ்",
    },
  },
  partners: {
    title: "எங்கள் கூட்டாளர்கள்",
    subtitle: "முன்னணி ஆட்டோமோட்டிவ் நிறுவனங்களால் நம்பப்படுகிறது",
  },
  employment: {
    title: "வேலைவாய்ப்பு வாய்ப்புகள்",
    subtitle: "முன்னணி ஆட்டோமோட்டிவ் முதலாளிகளுடன் இணைக்கவும்",
    description: "OEM கள், சப்ளையர்கள் மற்றும் சேவை நெட்வொர்க்குகள் உட்பட எங்கள் தொழில்துறை கூட்டாளர்களின் வலைப்பின்னலில் இருந்து பிரத்யேக வேலை வாய்ப்புகளை அணுகவும்.",
    viewOpenings: "வேலை வாய்ப்புகளைக் காண்க",
    registerNow: "இப்போதே பதிவு செய்யவும்",
    stats: {
      companies: "கூட்டாளர் நிறுவனங்கள்",
      openings: "செயலில் உள்ள வாய்ப்புகள்",
      placements: "வெற்றிகரமான வேலைவாய்ப்புகள்",
      rate: "வேலைவாய்ப்பு விகிதம்",
    },
  },
  hrRegistration: {
    title: "ஆட்சேர்ப்புக்கான எச்ஆர் பதிவு",
    badge: "ஆட்சேர்ப்பு",
    description: "பயிற்சி பெற்ற மற்றும் சான்றளிக்கப்பட்ட ஆட்டோமோட்டிவ் நிபுணர்களின் எங்கள் குழுவை அணுக உங்கள் நிறுவனத்தை பதிவு செய்யவும்.",
    points: {
      candidates: "2500+ பயிற்சி பெற்ற விண்ணப்பதாரர்களுக்கான அணுகல்",
      certified: "தொழில்துறை சான்றளிக்கப்பட்ட நிபுணர்கள்",
      process: "எளிதாக்கப்பட்ட ஆட்சேர்ப்பு செயல்முறை",
    },
    registerNow: "இப்போதே பதிவு செய்யவும்",
    contactUs: "எங்களை தொடர்பு கொள்ளவும்",
  },
  csr: {
    title: "சிஎஸ்ஆர் திட்டங்கள்",
    subtitle: "பெருநிறுவன சமூக பொறுப்பு முயற்சிகளில் எங்களுடன் ஒத்துழைக்கவும்",
    projects: {
      community: {
        title: "சமூக திறன் மேம்பாடு",
        description: "ஏழை இளைஞர்களுக்கு இலவச ஆட்டோமோட்டிவ் பயிற்சி அளிக்கவும், கிராமப்புற தமிழ்நாட்டில் வேலைவாய்ப்பு வாய்ப்புகளை உருவாக்கவும் எங்களுடன் கூட்டு சேரவும்.",
      },
      women: {
        title: "ஆட்டோமோட்டிவில் பெண்கள் முன்முயற்சி",
        description: "தொழில்துறையில் பாலின தடைகளை உடைத்து, ஆட்டோமோட்டிவ் தொழில்நுட்பத்தில் பெண்களுக்கு பயிற்சி அளிக்கவும் மேம்படுத்தவும் எங்கள் திட்டத்தை ஆதரிக்கவும்.",
      },
    },
    register: "சிஎஸ்ஆர் கூட்டாண்மை பதிவு",
  },
  academia: {
    title: "கல்வி மற்றும் முன்னாள் மாணவர் ஆதரவு",
    subtitle: "கல்வி கற்றலுக்கும் தொழில்துறை தேவைகளுக்கும் இடையிலான இடைவெளியை நிரப்புதல்",
    cards: {
      campus: {
        title: "வளாக ஆதரவு",
        description: "பாடத்திட்ட இணை மேம்பாடு மற்றும் ஆசிரியர் பயிற்சி",
      },
      alumni: {
        title: "முன்னாள் மாணவர் வழிகாட்டுதல்",
        description: "தொடர்ச்சியான திறன் மேம்பாடு மற்றும் தொழில் முன்னேற்றம்",
      },
      internship: {
        title: "பயிற்சி குழாய்கள்",
        description: "மாணவர்களுக்கான நேரடி தொழில்துறை இணைப்புகள்",
      },
      placement: {
        title: "வேலைவாய்ப்பு உதவி",
        description: "பட்டதாரிகளுக்கு 100% வேலைவாய்ப்பு ஆதரவு",
      },
    },
    contact: "கல்வி ஆதரவை தொடர்பு கொள்ளவும்",
  },
  milestones: {
    title: "எங்கள் மைல்கற்கள்",
    subtitle: "தமிழ்நாடு முழுவதும் ஆட்டோமோட்டிவ் கல்வியை மாற்றியமைத்தல்",
    stats: {
      trained: "பயிற்சி பெற்ற மாணவர்கள்",
      certified: "சான்றளிக்கப்பட்ட நிபுணர்கள்",
      placements: "வேலைவாய்ப்புகள்",
      partners: "தொழில்துறை கூட்டாளர்கள்",
      successRate: "வெற்றி விகிதம்",
    },
  },
  successStories: {
    title: "வெற்றிக் கதைகள்",
    subtitle: "எங்கள் பட்டதாரிகளிடமிருந்து கேளுங்கள்",
    viewAll: "அனைத்து கதைகளையும் காண்க",
  },
  placementRegistration: {
    title: "வேலைவாய்ப்பு பதிவு",
    description: "உங்கள் மாணவர்கள் டிஎன் ஆட்டோ ஸ்கில்ஸ் மூலம் முன்னணி ஆட்டோமோட்டிவ் நிறுவனங்களுடன் வேலைவாய்ப்பு வாய்ப்புகளை அணுக உங்கள் கல்வி நிறுவனத்தை பதிவு செய்யவும்.",
    register: "உங்கள் நிறுவனத்தை பதிவு செய்யவும்",
  },
  footer: {
    tagline: "ஆட்டோமோட்டிவ் சிறப்பை மேம்படுத்துதல்",
    description: "உலகத்தரம் வாய்ந்த திறன் மேம்பாடு மற்றும் தொழில்துறை கூட்டாண்மை மூலம் இந்தியாவின் ஆட்டோமோட்டிவ் எதிர்காலத்தை உருவாக்குதல்.",
    quickLinks: "விரைவு இணைப்புகள்",
    programs: "திட்டங்கள்",
    resources: "வளங்கள்",
    connect: "இணைக்கவும்",
    newsletter: "செய்திமடல்",
    newsletterText: "திட்டங்கள் மற்றும் வாய்ப்புகள் குறித்த புதுப்பிப்புகளைப் பெற குழுசேரவும்",
    subscribe: "குழுசேரவும்",
    emailPlaceholder: "உங்கள் மின்னஞ்சலை உள்ளிடவும்",
    links: {
      about: "எங்களைப் பற்றி",
      courses: "பாடநெறிகள்",
      careers: "தொழில் வாய்ப்புகள்",
      contact: "தொடர்பு",
      admissions: "சேர்க்கைகள்",
      faculty: "ஆசிரியர்கள்",
      facilities: "வசதிகள்",
      blog: "வலைப்பதிவு",
      news: "செய்திகள்",
      events: "நிகழ்வுகள்",
      gallery: "படத்தொகுப்பு",
    },
    followUs: "எங்களைப் பின்தொடரவும்",
    rights: "அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.",
    govt: "தமிழ்நாடு அரசு",
  },
  common: {
    learnMore: "மேலும் அறிய",
    readMore: "மேலும் படிக்க",
    viewMore: "மேலும் காண்க",
    viewAll: "அனைத்தையும் காண்க",
    exploreNow: "இப்போது ஆராயுங்கள்",
    getStarted: "தொடங்குங்கள்",
    contactUs: "எங்களை தொடர்பு கொள்ளவும்",
    apply: "விண்ணப்பிக்கவும்",
    register: "பதிவு செய்யவும்",
    submit: "சமர்ப்பிக்கவும்",
    cancel: "ரத்து செய்",
    close: "மூடு",
    next: "அடுத்து",
    previous: "முந்தைய",
    loading: "ஏற்றுகிறது...",
    search: "தேடு",
  },
};
