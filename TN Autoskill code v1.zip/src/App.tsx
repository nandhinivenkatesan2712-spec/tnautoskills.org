import { useState, useEffect } from "react";
import { RedesignedHeader } from "./components/RedesignedHeader";
import { ModernHero } from "./components/ModernHero";
import { Footer } from "./components/Footer";
import { LanguageProvider } from "./contexts/LanguageContext";

// Redesigned Modern UI Sections
import {
  RedesignedWhoWeAre,
  RedesignedStakeholders,
  RedesignedMilestones,
  RedesignedSuccessStories,
} from "./components/RedesignedSections";

import { PremiumCentreOfExcellence } from "./components/PremiumCentreOfExcellence";
import { CompactGlobalCurriculum } from "./components/CompactGlobalCurriculum";
import { PremiumPartners } from "./components/PremiumPartners";
import { EmploymentOpportunities } from "./components/EmploymentOpportunities";
import { ModernCSRProjects } from "./components/ModernCSRProjects";
import { ModernPlacementRegistration } from "./components/ModernPlacementRegistration";
import { FeaturedTrainingPrograms } from "./components/FeaturedTrainingPrograms";
import { HRRegistrationSection } from "./components/HRRegistrationSection";
import { HRRegistrationPage } from "./components/HRRegistrationPage";
import { PlacementRegistrationPage } from "./components/PlacementRegistrationPage";
import { AcademiaAlumniSection } from "./components/AcademiaAlumniSection";

import { ProgramsPage } from "./components/ProgramsPage";
import { CoursesPage } from "./components/CoursesPage";
import { CourseDetailPage } from "./components/CourseDetailPage";
import { SuccessStoriesPageFull } from "./components/SuccessStoriesPageFull";
import { AboutPage } from "./components/AboutPage";
import { BoardMembersPage } from "./components/BoardMembersPage";
import { TeamPage } from "./components/TeamPage";
import { ContactPageFull } from "./components/ContactPageFull";
import { ApplyNowPageFull } from "./components/ApplyNowPageFull";

export default function App() {
  const [currentPage, setCurrentPage] = useState<
    | "home"
    | "programs"
    | "courses"
    | "success-stories"
    | "about"
    | "board-members"
    | "our-team"
    | "contact"
    | "apply"
    | "hr-register"
    | "placement-register"
    | "course-detail"
  >("home");
  
  const [selectedCourseId, setSelectedCourseId] = useState<number | null>(null);

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      
      // Check for course detail pages (#course/1, #course/2, etc.)
      const courseMatch = hash.match(/^#course\/(\d+)$/);
      if (courseMatch) {
        const courseId = parseInt(courseMatch[1]);
        setSelectedCourseId(courseId);
        setCurrentPage("course-detail");
        window.scrollTo(0, 0);
        return;
      }
      
      if (hash === "#programs") {
        setCurrentPage("programs");
        window.scrollTo(0, 0);
      } else if (hash === "#courses") {
        setCurrentPage("courses");
        window.scrollTo(0, 0);
      } else if (hash === "#success-stories") {
        setCurrentPage("success-stories");
        window.scrollTo(0, 0);
      } else if (hash === "#about") {
        setCurrentPage("about");
        window.scrollTo(0, 0);
      } else if (hash === "#board-members") {
        setCurrentPage("board-members");
        window.scrollTo(0, 0);
      } else if (hash === "#our-team") {
        setCurrentPage("our-team");
        window.scrollTo(0, 0);
      } else if (hash === "#contact") {
        setCurrentPage("contact");
        window.scrollTo(0, 0);
      } else if (hash === "#apply") {
        setCurrentPage("apply");
        window.scrollTo(0, 0);
      } else if (hash === "#hr-register") {
        setCurrentPage("hr-register");
        window.scrollTo(0, 0);
      } else if (hash === "#placement-register") {
        setCurrentPage("placement-register");
        window.scrollTo(0, 0);
      } else {
        setCurrentPage("home");
        window.scrollTo(0, 0);
      }
    };

    handleHashChange();
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  return (
    <LanguageProvider>
      <div className="bg-white min-h-screen w-full overflow-x-hidden">
        {/* Fixed Header */}
        <RedesignedHeader />

        {/* Spacer for fixed header */}
        <div className="h-[88px] lg:h-[96px]" />

        {/* Page Content */}
        {currentPage === "home" && (
          <>
            <ModernHero />
            <RedesignedWhoWeAre />
            <FeaturedTrainingPrograms />
            <RedesignedStakeholders />
            <PremiumCentreOfExcellence />
            <CompactGlobalCurriculum />
            <PremiumPartners />
            <EmploymentOpportunities />
            <HRRegistrationSection />
            <ModernCSRProjects />
            <AcademiaAlumniSection />
            <RedesignedMilestones />
            <RedesignedSuccessStories />
            <ModernPlacementRegistration />
          </>
        )}

        {currentPage === "programs" && <ProgramsPage />}
        {currentPage === "courses" && <CoursesPage />}
        {currentPage === "course-detail" && selectedCourseId && (
          <CourseDetailPage courseId={selectedCourseId} />
        )}
        {currentPage === "success-stories" && <SuccessStoriesPageFull />}
        {currentPage === "about" && <AboutPage />}
        {currentPage === "board-members" && <BoardMembersPage />}
        {currentPage === "our-team" && <TeamPage />}
        {currentPage === "contact" && <ContactPageFull />}
        {currentPage === "apply" && <ApplyNowPageFull />}
        {currentPage === "hr-register" && <HRRegistrationPage />}
        {currentPage === "placement-register" && <PlacementRegistrationPage />}

        {/* Footer */}
        <Footer />
      </div>
    </LanguageProvider>
  );
}