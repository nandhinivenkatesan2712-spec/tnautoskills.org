import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Boxes, Wrench, HandshakeIcon, Target, TrendingUp, Users, ArrowRight } from "lucide-react";

export function ModernCSRProjects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const projects = [
    {
      icon: Boxes,
      title: "Delta Technologies Centre of Excellence",
      description: "Advanced training in Robotics, Cobotics, IoT, and Embedded Systems",
      color: "blue",
    },
    {
      icon: Wrench,
      title: "SAIL – India's First Plastic Welding Training",
      description: "Pioneering plastic welding skills for automotive manufacturing",
      color: "teal",
    },
    {
      icon: HandshakeIcon,
      title: "CSR Partnership Registration",
      description: "Join us to create skill development impact across Tamil Nadu",
      color: "violet",
    },
  ];

  const stats = [
    { icon: Target, value: "15+", label: "CSR Initiatives" },
    { icon: TrendingUp, value: "₹12Cr+", label: "CSR Investment" },
    { icon: Users, value: "5000+", label: "Lives Impacted" },
  ];

  return (
    <section ref={ref} className="py-20 bg-gradient-to-b from-gray-50/30 to-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Corporate Social Responsibility (CSR)
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto mb-2">
            Two CSR projects successfully completed.
          </p>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            High-impact CSR initiatives improving skill development across Tamil Nadu.
          </p>
        </motion.div>

        {/* CSR Impact Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-3 gap-6 mb-10"
        >
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={idx}
                className="bg-white border border-gray-200/60 rounded-[20px] p-6 text-center hover:shadow-md transition-shadow duration-250"
              >
                <Icon className="size-6 text-[#0066FF] mx-auto mb-3" strokeWidth={1.5} />
                <div className="text-3xl font-extrabold text-[#0A0A0A] mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-[#64748B] font-medium">
                  {stat.label}
                </div>
              </div>
            );
          })}
        </motion.div>

        {/* CSR Project Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-10">
          {projects.map((project, idx) => {
            const Icon = project.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 + 0.3 }}
                className={`group bg-white border border-gray-200/60 rounded-[20px] p-8 hover:bg-gradient-to-br ${
                  project.color === "blue"
                    ? "hover:from-blue-50/40 hover:to-blue-100/20"
                    : project.color === "teal"
                    ? "hover:from-teal-50/40 hover:to-teal-100/20"
                    : "hover:from-violet-50/40 hover:to-violet-100/20"
                } hover:border-gray-300/80 hover:shadow-[0_10px_28px_rgba(0,0,0,0.09)] hover:-translate-y-1 transition-all duration-300 cursor-pointer`}
              >
                {/* Icon */}
                <div className="mb-5">
                  <Icon
                    className={`size-8 ${
                      project.color === "blue"
                        ? "text-blue-500"
                        : project.color === "teal"
                        ? "text-teal-500"
                        : "text-violet-500"
                    } transition-transform duration-300 group-hover:scale-110`}
                    strokeWidth={1.5}
                  />
                </div>

                {/* Content */}
                <h3 className="font-semibold text-[19px] text-[#0A0A0A] mb-3">
                  {project.title}
                </h3>
                <p className="text-[15px] text-[#64748B] leading-relaxed">
                  {project.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="text-center"
        >
          <button className="group inline-flex items-center gap-2.5 px-8 py-4 bg-[#0066FF] hover:bg-[#0052CC] text-white rounded-[20px] font-semibold text-[15px] shadow-md hover:shadow-lg transition-all duration-250 active:scale-[0.98]">
            <span>CSR Partnership Registration</span>
            <ArrowRight className="size-5 transition-transform duration-250 group-hover:translate-x-1" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}