import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Users, Building2, GraduationCap, UserCheck } from "lucide-react";

const stakeholders = [
  {
    icon: Users,
    title: "Candidates",
    description:
      "Access industry-aligned training programs, hands-on workshops, placement support, and career guidance to launch your automotive career.",
    highlights: [
      "Government-certified courses",
      "Practical training with modern tools",
      "Job placement assistance",
      "Career counseling & interview prep",
    ],
  },
  {
    icon: Building2,
    title: "Industry",
    description:
      "Partner with us to access skilled talent, co-create training programs, and strengthen the automotive workforce pipeline.",
    highlights: [
      "Access to trained candidates",
      "Custom training programs",
      "Internship & apprenticeship support",
      "Industry collaboration opportunities",
    ],
  },
  {
    icon: GraduationCap,
    title: "Academia",
    description:
      "Collaborate to enhance automotive education, faculty development, lab infrastructure, and student placement opportunities.",
    highlights: [
      "Faculty training programs",
      "Lab infrastructure support",
      "Curriculum alignment",
      "Student placement assistance",
    ],
  },
  {
    icon: UserCheck,
    title: "Trainers & Assessors",
    description:
      "Join our network of expert trainers and certified assessors to deliver world-class automotive education and skill assessment.",
    highlights: [
      "Professional development",
      "Certification programs",
      "Industry exposure",
      "Networking opportunities",
    ],
  },
];

export function EmpoweringStakeholders() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
            <div className="size-2 bg-[#0066FF] rounded-full animate-pulse" />
            <span className="text-sm font-semibold text-[#0066FF]">
              For Everyone
            </span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
            Empowering Every Stakeholder
          </h2>

          <p className="text-lg lg:text-xl text-[#64748b] max-w-3xl mx-auto">
            Supporting candidates, industry partners, academic institutions, and training professionals
          </p>
        </motion.div>

        {/* Stakeholder Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {stakeholders.map((stakeholder, index) => {
            const IconComponent = stakeholder.icon;
            return (
              <motion.div
                key={stakeholder.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8, scale: 1.01 }}
                className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 lg:p-10 border-2 border-gray-100 hover:border-[#0066FF]/30 shadow-lg hover:shadow-2xl transition-all"
              >
                {/* Icon */}
                <div className="size-16 lg:size-20 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                  <IconComponent className="size-8 lg:size-10 text-white" strokeWidth={2} />
                </div>

                {/* Title */}
                <h3 className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A] mb-4 group-hover:text-[#0066FF] transition-colors">
                  {stakeholder.title}
                </h3>

                {/* Description */}
                <p className="text-base lg:text-lg text-[#64748b] mb-6 leading-relaxed">
                  {stakeholder.description}
                </p>

                {/* Highlights */}
                <ul className="space-y-3">
                  {stakeholder.highlights.map((highlight, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <div className="size-5 rounded-full bg-[#0066FF]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <div className="size-2 rounded-full bg-[#0066FF]" />
                      </div>
                      <span className="text-sm lg:text-base text-[#475569]">
                        {highlight}
                      </span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
