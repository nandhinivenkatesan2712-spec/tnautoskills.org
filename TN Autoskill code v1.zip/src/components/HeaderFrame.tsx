import { motion } from "motion/react";
import imgLogo1 from "figma:asset/14f8e66972ba1a8006cc1445bbada7a653c5bac0.png";
import imgLogo2 from "figma:asset/64ac74e9e444adfa885175931c60fd5a99042ce9.png";

export function HeaderFrame() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
      className="bg-white py-5 px-4 lg:px-8"
    >
      <div className="max-w-[1440px] mx-auto flex flex-col md:flex-row items-center justify-center gap-8 lg:gap-28">
        {/* Logo 1 */}
        <div className="flex-shrink-0 w-[140px] md:w-[180px] lg:w-[200px]">
          <img
            src={imgLogo1}
            alt="Government Logo"
            className="w-full h-auto"
          />
        </div>

        {/* Center Text */}
        <div className="flex flex-col gap-2 text-center max-w-3xl">
          <p
            className="text-[#c62828] text-base md:text-lg lg:text-xl"
            style={{
              fontFamily: "'Noto Sans Tamil', sans-serif",
              fontVariationSettings: "'wdth' 100"
            }}
          >
            தமிழ்நாடு உயர்திறன் மேம்பாட்டு மையம் - ஆட்டோமொபைல்
          </p>
          <p className="text-black text-lg md:text-xl lg:text-2xl">
            TAMILNADU APEX SKILL DEVELOPMENT CENTRE FOR AUTOMOBILE
          </p>
        </div>

        {/* Logo 2 */}
        <div className="flex-shrink-0 w-[140px] md:w-[180px] lg:w-[200px]">
          <img
            src={imgLogo2}
            alt="ASDC Logo"
            className="w-full h-auto"
          />
        </div>
      </div>
    </motion.div>
  );
}
