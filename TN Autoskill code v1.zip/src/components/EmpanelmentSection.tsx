import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight, Building2, Package, Store, Lightbulb } from "lucide-react";

const categories = [
  {
    icon: Building2,
    title: "OEM",
    count: 4,
    items: [
      "Vehicle Manufacturing",
      "Assembly Operations",
      "Quality Control",
      "R&D Collaboration",
    ],
  },
  {
    icon: Package,
    title: "Auto Suppliers",
    count: 5,
    items: [
      "Component Manufacturing",
      "Parts Supply Chain",
      "Tier 1 & Tier 2 Suppliers",
      "Quality Assurance",
      "Technical Support",
    ],
  },
  {
    icon: Store,
    title: "Retail Partners",
    count: 5,
    items: [
      "Dealership Networks",
      "Service Centers",
      "Spare Parts Retailers",
      "After-Sales Support",
      "Customer Service",
    ],
  },
  {
    icon: Lightbulb,
    title: "Startups",
    count: 4,
    items: [
      "EV Technology",
      "Mobility Solutions",
      "Auto-Tech Innovation",
      "Digital Platforms",
    ],
  },
];

export function EmpanelmentSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
            <div className="size-2 bg-[#0066FF] rounded-full animate-pulse" />
            <span className="text-sm font-semibold text-[#0066FF]">
              Partnership Opportunities
            </span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
            Empanelment
          </h2>

          <p className="text-lg lg:text-xl text-[#64748b] max-w-3xl mx-auto">
            Join our network of empaneled partners and contribute to building India's automotive workforce
          </p>
        </motion.div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mb-12">
          {categories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="bg-white rounded-2xl p-6 lg:p-8 border-2 border-gray-100 hover:border-[#0066FF]/30 shadow-lg hover:shadow-2xl transition-all group"
              >
                {/* Icon & Badge */}
                <div className="flex items-start justify-between mb-6">
                  <div className="size-14 bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <IconComponent className="size-7 text-[#0066FF]" strokeWidth={2} />
                  </div>
                  <span className="px-3 py-1 bg-blue-100 text-[#0066FF] rounded-full text-xs font-bold">
                    {category.count} Areas
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-[#0A0A0A] mb-4 group-hover:text-[#0066FF] transition-colors">
                  {category.title}
                </h3>

                {/* Items List */}
                <ul className="space-y-2">
                  {category.items.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-[#64748b]">
                      <div className="size-1.5 rounded-full bg-[#0066FF] mt-1.5 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>

        {/* CTA Banner */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-3xl p-8 lg:p-12 text-center"
        >
          <h3 className="text-3xl font-extrabold text-white mb-4">
            Ready to Partner with Us?
          </h3>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Become an empaneled partner and access skilled automotive talent, training collaboration opportunities, and industry networking.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-3 px-8 py-4 bg-white text-[#0066FF] rounded-xl font-bold text-base shadow-xl hover:shadow-2xl transition-all"
          >
            <span>Become an Empaneled Partner</span>
            <ArrowRight className="size-5" />
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
