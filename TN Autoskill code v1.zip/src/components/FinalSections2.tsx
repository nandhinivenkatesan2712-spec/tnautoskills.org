import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Zap,
  Leaf,
  Cpu,
  Layers,
  Shield,
  Target,
  Award,
  CheckCircle,
  ArrowRight,
  Building2,
} from "lucide-react";

// SECTION 5 — Centre of Excellence
export function FinalCentreOfExcellence() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    "EV & Hybrid Labs with state-of-the-art equipment",
    "Smart Connected Vehicles IoT workshops",
    "BS6 Compliance and emission standards training",
    "Industry-certified training programs",
    "Advanced diagnostic tools and technology",
  ];

  return (
    <section ref={ref} className="py-15 bg-gradient-to-br from-[#F0F9FF] via-white to-[#F0FDFA] relative overflow-hidden">
      {/* Soft Futuristic Gradient Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-[#0066FF]/10 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-gradient-to-tr from-[#00BCD4]/10 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left — Illustration */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative">
              {/* Tech Icons Grid */}
              <div className="grid grid-cols-2 gap-4">
                {[Zap, Cpu, Shield, Award].map((Icon, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ duration: 0.6, delay: idx * 0.1 }}
                    className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 border border-gray-100 flex items-center justify-center"
                  >
                    <Icon className="size-16 text-[#0066FF]" strokeWidth={1.5} />
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right — Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-6">
              Centre of Excellence
            </h2>

            {/* Bullet List */}
            <ul className="space-y-3 mb-8">
              {features.map((feature, idx) => (
                <motion.li
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + idx * 0.1 }}
                  className="flex items-start gap-3"
                >
                  <CheckCircle className="size-5 text-[#0066FF] flex-shrink-0 mt-0.5" strokeWidth={2} />
                  <span className="text-base text-[#475569]">{feature}</span>
                </motion.li>
              ))}
            </ul>

            {/* CTA */}
            <a
              href="#facilities"
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] text-white rounded-xl font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all"
            >
              <span>Explore Facilities</span>
              <ArrowRight className="size-4" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// SECTION 6 — Global Automotive Curriculum Framework
export function FinalGlobalCurriculum() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const frameworks = [
    {
      icon: Zap,
      title: "EV Framework",
      description: "Electric vehicle training modules and battery technology systems.",
    },
    {
      icon: Cpu,
      title: "SDV Framework",
      description: "Software-defined vehicle systems and digital architecture.",
    },
    {
      icon: Leaf,
      title: "Green & Flexi Fuel",
      description: "Sustainable automotive technologies and alternative fuel systems.",
    },
    {
      icon: Layers,
      title: "Vehicle Architecture",
      description: "Modern automotive design principles and platform engineering.",
    },
  ];

  const partners = ["Hyundai", "Maruti Suzuki", "Tata Motors", "TVS Motors", "Ashok Leyland", "Ather Energy"];

  return (
    <section ref={ref} className="py-15 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Global Automotive Curriculum Framework
          </h2>
          <p className="text-lg text-[#64748B] max-w-3xl mx-auto">
            Internationally recognized automotive curriculum standards
          </p>
        </motion.div>

        {/* 4 Modern Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {frameworks.map((framework, idx) => {
            const Icon = framework.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -8, boxShadow: "0 20px 40px rgba(0,102,255,0.15)" }}
                className="group bg-white rounded-[20px] p-6 border border-gray-100 hover:border-[#0066FF]/30 transition-all"
              >
                {/* Icon */}
                <div className="size-14 bg-gradient-to-br from-[#0066FF] to-[#00BCD4] rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-6 transition-all shadow-lg">
                  <Icon className="size-7 text-white" strokeWidth={2} />
                </div>

                {/* Title */}
                <h3 className="font-bold text-lg text-[#0A0A0A] mb-2">
                  {framework.title}
                </h3>

                {/* Description (2 lines) */}
                <p className="text-sm text-[#64748B] leading-relaxed line-clamp-2">
                  {framework.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Partner Logos Slider */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
        >
          <h3 className="text-center text-lg font-semibold text-[#64748B] mb-6">
            Curriculum Partners
          </h3>
          <div className="flex gap-8 justify-center items-center flex-wrap">
            {partners.map((partner, idx) => (
              <div
                key={idx}
                className="px-6 py-3 bg-gray-50 rounded-xl border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-md transition-all"
              >
                <div className="flex items-center gap-2">
                  <Building2 className="size-5 text-[#0066FF]" />
                  <span className="font-semibold text-sm text-[#0A0A0A]">{partner}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 7 — Zero Fatalities by 2030
export function FinalZeroFatalities() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const pillars = [
    {
      icon: Shield,
      title: "Advanced Safety Systems",
      description: "Training on vehicle safety technologies",
    },
    {
      icon: Target,
      title: "Driver Education",
      description: "Behavior and road safety programs",
    },
    {
      icon: Award,
      title: "Emergency Response",
      description: "First aid and crisis management",
    },
  ];

  return (
    <section ref={ref} className="py-15 bg-gradient-to-br from-[#0A1628] via-[#1E293B] to-[#0F172A] text-white relative overflow-hidden">
      {/* Faint Tamil Nadu Map Outline */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border-2 border-white/30 rounded-[30%_70%_70%_30%/30%_30%_70%_70%]" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold mb-4">
            Zero Fatalities by 2030
          </h2>
          {/* Glow Line Underline */}
          <div className="w-32 h-1 bg-gradient-to-r from-transparent via-[#00BCD4] to-transparent mx-auto mb-6" />
          
          <p className="text-lg text-white/80 max-w-3xl mx-auto leading-relaxed">
            We are committed to achieving the UN's Sustainable Development Goal of reducing road traffic deaths and injuries through comprehensive safety training.
          </p>
        </motion.div>

        {/* Three Pillars */}
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {pillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + idx * 0.15 }}
                className="bg-white/10 backdrop-blur-md rounded-[20px] p-6 border border-white/20 hover:bg-white/20 transition-all"
              >
                <div className="size-12 bg-white/20 rounded-xl flex items-center justify-center mb-4">
                  <Icon className="size-6 text-white" strokeWidth={2} />
                </div>
                <h3 className="font-bold text-lg mb-2">{pillar.title}</h3>
                <p className="text-sm text-white/70">{pillar.description}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Stats/Initiative Bullets */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto"
        >
          {[
            { label: "Target Reduction", value: "50%" },
            { label: "Achievement Year", value: "2030" },
            { label: "Safety Trainees", value: "1000+" },
            { label: "Awareness Programs", value: "100+" },
          ].map((stat, idx) => (
            <div key={idx} className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <div className="text-3xl font-extrabold mb-1">{stat.value}</div>
              <div className="text-sm text-white/70">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 8 — Our Milestones
export function FinalMilestones() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stats = [
    { icon: "👨‍🎓", value: "2500+", label: "Students Trained" },
    { icon: "🎓", value: "500+", label: "Certified Professionals" },
    { icon: "💼", value: "200+", label: "Placements" },
    { icon: "🏢", value: "40+", label: "Industry Partners" },
    { icon: "📊", value: "95%", label: "Success Rate" },
  ];

  return (
    <section ref={ref} className="py-15 bg-gradient-to-br from-[#0066FF] via-[#0055DD] to-[#00BCD4]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 text-white"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold mb-3">Our Milestones</h2>
          <p className="text-lg text-white/90">Transforming automotive education across Tamil Nadu</p>
        </motion.div>

        {/* 5-Card Stat Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {stats.map((stat, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.8, y: 30 }}
              animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              whileHover={{ scale: 1.08, y: -8 }}
              className="bg-white/15 backdrop-blur-md rounded-[20px] p-6 border border-white/25 text-center text-white hover:bg-white/25 transition-all"
            >
              {/* Icon */}
              <div className="text-4xl mb-3">{stat.icon}</div>

              {/* Counter Animation - Value */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={isInView ? { opacity: 1 } : {}}
                transition={{ duration: 0.8, delay: 0.5 + idx * 0.1 }}
                className="text-4xl font-extrabold mb-2"
              >
                {stat.value}
              </motion.div>

              {/* Label */}
              <div className="text-xs text-white/80 font-medium uppercase tracking-wide">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
