import { motion } from "motion/react";
import { CheckCircle2 } from "lucide-react";
import { Button } from "./ui/button";
import { useEffect, useState } from "react";

interface SuccessMessageProps {
  onBackToHome: () => void;
  onSubmitAnother: () => void;
}

export function SuccessMessage({ onBackToHome, onSubmitAnother }: SuccessMessageProps) {
  const [confetti, setConfetti] = useState<Array<{ id: number; x: number; delay: number }>>([]);

  useEffect(() => {
    // Generate confetti particles
    const particles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100 - 50, // Random horizontal position (-50 to 50)
      delay: Math.random() * 0.3, // Random delay
    }));
    setConfetti(particles);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F8FAFB] via-white to-[#F8FAFB] flex items-center justify-center py-12 px-6">
      <div className="max-w-[600px] w-full relative">
        {/* Subtle Confetti Animation */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {confetti.map((particle) => (
            <motion.div
              key={particle.id}
              initial={{ y: -20, x: 0, opacity: 0, scale: 0 }}
              animate={{
                y: 400,
                x: particle.x,
                opacity: [0, 1, 1, 0],
                scale: [0, 1, 1, 0],
              }}
              transition={{
                duration: 2,
                delay: particle.delay,
                ease: "easeOut",
              }}
              className="absolute top-0 left-1/2"
            >
              <div
                className="w-2 h-2 rounded-full"
                style={{
                  background: `linear-gradient(135deg, ${
                    particle.id % 3 === 0
                      ? "#0066FF"
                      : particle.id % 3 === 1
                      ? "#00BCD4"
                      : "#E0F2FE"
                  }, transparent)`,
                }}
              />
            </motion.div>
          ))}
        </div>

        {/* Success Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="bg-white rounded-2xl shadow-2xl border border-gray-100 p-8 lg:p-12 relative z-10"
        >
          {/* Animated Checkmark */}
          <div className="flex justify-center mb-6">
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{
                type: "spring",
                stiffness: 200,
                damping: 15,
                delay: 0.2,
              }}
              className="relative"
            >
              {/* Outer Circle Pulse */}
              <motion.div
                initial={{ scale: 1, opacity: 0.5 }}
                animate={{ scale: 1.5, opacity: 0 }}
                transition={{
                  duration: 1,
                  repeat: 2,
                  delay: 0.5,
                }}
                className="absolute inset-0 bg-green-500 rounded-full"
              />

              {/* Checkmark Circle */}
              <div className="relative size-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                <motion.div
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: 1 }}
                  transition={{
                    duration: 0.6,
                    delay: 0.4,
                    ease: "easeOut",
                  }}
                >
                  <CheckCircle2 className="size-12 text-white" strokeWidth={2.5} />
                </motion.div>
              </div>
            </motion.div>
          </div>

          {/* Success Message */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="text-center space-y-4"
          >
            <h2 className="text-2xl lg:text-[32px] font-extrabold text-[#0A1628] leading-tight">
              Registration Submitted Successfully
            </h2>
            <p className="text-base lg:text-[17px] text-[#64748B] leading-relaxed max-w-md mx-auto">
              Thank you. Your HR recruitment request has been submitted. Our team will contact you shortly.
            </p>
          </motion.div>

          {/* Additional Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="mt-8 p-4 bg-gradient-to-r from-[#0066FF]/5 to-[#00BCD4]/5 rounded-xl border border-[#0066FF]/10"
          >
            <p className="text-sm text-[#475569] text-center leading-relaxed">
              <span className="font-semibold text-[#0066FF]">What happens next?</span>
              <br />
              Our recruitment team will review your request and contact you within{" "}
              <span className="font-semibold">48 hours</span> to discuss suitable candidates.
            </p>
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1 }}
            className="mt-8 flex flex-col sm:flex-row gap-4 items-center justify-center"
          >
            <Button
              onClick={onBackToHome}
              className="w-full sm:w-auto px-8 h-12 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] hover:from-[#0055DD] hover:to-[#00ACC4] text-white font-semibold shadow-lg hover:shadow-xl transition-all text-base"
            >
              Back to Home
            </Button>

            <button
              onClick={onSubmitAnother}
              className="text-[#0066FF] font-semibold text-base hover:underline transition-all"
            >
              Submit Another Request
            </button>
          </motion.div>
        </motion.div>

        {/* Bottom Contact Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 1.2 }}
          className="mt-6 text-center"
        >
          <p className="text-sm text-[#64748B]">
            Questions? Reach out at{" "}
            <a
              href="mailto:hr@tnautoskills.in"
              className="text-[#0066FF] font-semibold hover:underline"
            >
              hr@tnautoskills.in
            </a>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
