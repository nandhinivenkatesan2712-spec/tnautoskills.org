import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { 
  ArrowRight, 
  ArrowLeft,
  Clock, 
  Award,
  CheckCircle2,
  Briefcase,
  BookOpen,
  Target,
  GraduationCap,
  Zap,
  Battery,
  Settings,
  Cpu,
  Wrench,
  CircuitBoard,
  Cog,
  Truck,
  Users
} from "lucide-react";
import { ImageWithFallback } from './figma/ImageWithFallback';
import { courseImages } from './course-images';

interface CourseDetailPageProps {
  courseId: number;
}

// Detailed course data
const detailedCourses = [
  {
    id: 1,
    title: "Auto Electrical Maintenance — Junior Technician",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "ITI (Electrician / Mechanic Auto Electrical / Electronics) OR Diploma/BE in Electrical / Electronics / EEE / Mechatronics / Mechanical for advanced roles",
    shortSummary: "This course trains candidates to diagnose, maintain and repair vehicle electrical & electronic systems found in passenger cars, light commercial vehicles and two-wheelers.",
    fullDescription: "This course trains candidates to diagnose, maintain and repair vehicle electrical & electronic systems found in passenger cars, light commercial vehicles and two-wheelers. Learners practise wiring, battery & charging systems, starters, lighting, sensors, basic ECU fault reading, CAN-bus overview, alternators, ignition systems and accessory installations. Emphasis is on safe workshop practices, circuit testing with multi-meters / oscilloscopes, reading wiring diagrams, basic CAN diagnostics and customer-facing communication for service jobs. The program includes hands-on bench work, supervised live-vehicle diagnostics and a final job-oriented project.",
    icon: "Battery",
    pastelFrom: "#FFE5F1",
    pastelTo: "#FFF0F8",
    iconColor: "#FF6B9D",
    courseImage: courseImages.autoElectricalMaintenance,
    topics: [
      "Electrical fundamentals (Ohm's law, circuits, wiring color codes)",
      "Batteries, charging & starting systems (testing, replacement, maintenance)",
      "Lighting, signalling and accessory circuits",
      "Ignition systems and basic fuel-injection electronics",
      "Sensors & actuators (MAP, TPS, crank/cam sensors)",
      "Intro to ECUs and CAN/CAN-FD networks (fault reading, connectors)",
      "Wiring harness repair, crimping, soldering and heat shrink techniques",
      "Use of diagnostic tools: multimeter, clamp meter, battery tester, OBD scanner",
      "Workshop safety, 5S, PPE, basic first aid and electrical hazard control"
    ],
    skills: [
      "Test and replace batteries, alternators, starters",
      "Trace and repair wiring faults and short circuits",
      "Read basic wiring diagrams and perform continuity/insulation tests",
      "Use OBD readers & perform basic ECU fault interpretation",
      "Install electrical accessories and ensure system integrity",
      "Follow safety, environmental & workshop protocols"
    ],
    jobRoles: [
      "Auto Electrical Technician — dealer service centres (Maruti, Hyundai, Tata, etc.)",
      "Junior Service Technician — multi-brand garages / fast-fit chains",
      "Two-wheeler electrical technician — OEM & aftermarket dealers",
      "Accessory fitter / car-audio & telematics installer",
      "Battery service technician in EV transition teams (entry role)"
    ]
  },
  {
    id: 2,
    title: "Automotive CNC Operator (Machining Technician)",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "10th pass with relevant experience OR ITI (Machinist / Turner / Fitter / Tool & Die) OR Diploma (Mechanical / Production / Manufacturing)",
    shortSummary: "This program makes trainees competent at setting up and operating CNC turning/milling machines for automotive components.",
    fullDescription: "This program makes trainees competent at setting up and operating CNC turning/milling machines for automotive components. Focus areas: tooling selection, part programming (basic G-code understanding), fixture & work-holding, machine zeroing, tool offsets, machine operating cycles, process monitoring, inspection with vernier/micro-meter/CMM basics, and 5S shop practices. Training combines simulator programming, offline CAM basics and hands-on machining with quality checks to produce components to drawing tolerances.",
    icon: "Settings",
    pastelFrom: "#E0F2FE",
    pastelTo: "#F0F9FF",
    iconColor: "#38BDF8",
    courseImage: courseImages.automotiveCNCOperator,
    topics: [
      "Workshop math & engineering drawing basics for machining",
      "CNC fundamentals: axes, coordinates, G/M codes, canned cycles",
      "Tooling: inserts, tool holders, collets, chucks, fixture design basics",
      "Machine set up: zeroing, offsets, tool length measurement",
      "Operation sequences: program loading, dry run, part cycle, cycle stop",
      "Basic CNC programming and CAM workflow (milling & turning)",
      "Inspection & quality: gauges, micro-meters, surface finish, tolerances",
      "Preventive maintenance, machine safety and 5S"
    ],
    skills: [
      "Load and run CNC programs safely and efficiently",
      "Set up work holding and tooling for production jobs",
      "Perform basic troubleshooting and machine maintenance",
      "Interpret part drawings and perform in-process inspection",
      "Apply machining feeds/speeds for different materials"
    ],
    jobRoles: [
      "CNC Operator / Machinist — Tier-1 component manufacturers (Chennai, Hosur)",
      "Shop floor CNC operator — capital goods & auto components units",
      "Junior CAM operator (after additional CAM training)",
      "Inspection technician (shop-floor QC)"
    ]
  },
  {
    id: 3,
    title: "Battery Electric Vehicle (BEV) Technician — Jr. Technician",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "ITI (Automobile / Electrical / Electronics), Diploma/BE (EEE / Mechanical / Mechatronics / Automobile)",
    shortSummary: "A job-oriented course on servicing, diagnostics and safe handling of BEV systems with focus on high-voltage safety protocols.",
    fullDescription: "A job-oriented course on servicing, diagnostics and safe handling of BEV systems. Trainees learn battery fundamentals (cell/module/pack architecture), BMS basics, high-voltage safety protocols, traction motor basics, power electronics (inverter/charger), DC/DC converter, thermal management and high-voltage cabling connectors. Practical modules include HV isolation procedures, battery health checks, pack disassembly (simulator/lab), charging systems, regenerative braking basics and low-voltage electronics servicing. Strong focus on safety (isolation, PPE, lockout/tagout) and regulatory compliance.",
    icon: "Zap",
    pastelFrom: "#FEF3C7",
    pastelTo: "#FEF9E7",
    iconColor: "#FBBF24",
    topics: [
      "Fundamentals of Li-ion cells, modules, packs & SoC/SoH concepts",
      "Battery Management System (BMS): sensing, balancing, communication",
      "High-voltage safety, PPE, isolation & rescue procedures",
      "Traction motors: BLDC/AC motor basics and maintenance",
      "Power electronics: inverter, onboard charger, DC/DC converters",
      "Charging standards, CCS/Type-2/GB/T and home vs DC fast charging basics",
      "Thermal management & cooling systems for batteries",
      "Diagnostics, fault finding, use of insulation testers & vehicle diagnostic tools"
    ],
    skills: [
      "Perform HV isolation and safety checks on BEVs",
      "Diagnose battery health & basic pack faults (cells & balancing)",
      "Replace 12V auxiliary systems and low-voltage electronics",
      "Use EV diagnostic tools and interpret BMS logs",
      "Carry out charging station basics and customer guidance"
    ],
    jobRoles: [
      "EV Service Technician / Jr. EV Technician — passenger & two-wheeler service centres",
      "Battery maintenance technician  battery repack/refurbish units",
      "Workshop technician at OEM authorised EV service centres (Chennai, Hosur)",
      "Charging station technician / field service engineer (entry)"
    ]
  },
  {
    id: 4,
    title: "CNC Programmer-cum-Setter — Milling & Turning",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "ITI (Machinist / Fitter / Turner) with experience OR Diploma / BE (Mechanical / Production / Manufacturing / Mechatronics)",
    shortSummary: "This advanced program trains candidates to create and validate CNC programs for milling and turning, set machines for production, and optimize cycles.",
    fullDescription: "This advanced program trains candidates to create and validate CNC programs for milling and turning, set machines for production, perform trial runs, optimise cycles and ensure finished parts meet drawing tolerances. The syllabus covers manual G-code programming, conversational programming, CAM (basic toolpath generation), cutting tool selection, fixture design, work holding, machining strategy, optimisation for cycle time, and SPC & quality inspection methods. The course balances theory (CAM, metallurgy, cutting mechanics) with extensive shop practice on VMCs and CNC lathes.",
    icon: "Cpu",
    pastelFrom: "#DDD6FE",
    pastelTo: "#EDE9FE",
    iconColor: "#A78BFA",
    topics: [
      "Advanced CNC programming (G/M codes, subprograms, macro basics)",
      "CAM workflow for milling and turning (toolpaths, talkback)",
      "Tool selection, cutting parameters, coolant strategies",
      "Fixtures, jigs, and work-holding design for repeatability",
      "Machine calibration, tool offsets, backlash compensation",
      "Trial runs, in-process corrections and program optimisation",
      "Geometric tolerancing, surface finish, measurement for QA",
      "Preventive maintenance and TPM basics"
    ],
    skills: [
      "Write and optimise CNC programs for complex parts",
      "Set up machines, tools and fixtures for first-piece validation",
      "Implement process improvements to reduce cycle time / scrap",
      "Use CAM software to generate toolpaths (entry level)",
      "Perform SPC checks and hand off to quality teams"
    ],
    jobRoles: [
      "CNC Programmer / Setter — automotive component manufacturers",
      "Process Engineer (shop-floor programming & optimisation)",
      "Production CNC Lead / Senior Machine Operator",
      "Junior CAM Programmer (after CAM modules)"
    ]
  },
  {
    id: 5,
    title: "Fitter — Fabrication",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "ITI (Fitter / Turner / Sheet Metal / Welder) OR Diploma (Mechanical / Production) for supervisory roles",
    shortSummary: "Hands-on training in mechanical fitting and fabrication: reading drawings, marking, cutting, forming, assembly, and welding basics.",
    fullDescription: "Hands-on training in mechanical fitting and fabrication: reading fabrication drawings, marking, cutting, forming, bench work, assembly, gas cutting and welding basics (SMAW/TIG/MIG basics depending on scope). Focus on producing fabricated sub-assemblies to drawing tolerances and preparing components for welding/assembly lines. Covers workshop safety, material handling, use of power tools, drilling, tapping, grinding and finishing.",
    icon: "Wrench",
    pastelFrom: "#FFEDD5",
    pastelTo: "#FEF3E2",
    iconColor: "#FB923C",
    topics: [
      "Interpretation of fabrication drawings & templates",
      "Measuring tools, marking, drilling, tapping, reaming",
      "Sheet metal operations: bending, shearing, rolling (basic)",
      "Welding basics & preparation (SMAW/GMAW/TIG intro) — joint prep & tack welding",
      "Fit-up, alignment, clamps and jig usage",
      "Surface finish, deburring and corrosion protection"
    ],
    skills: [
      "Mark and prepare components accurately for fabrication",
      "Perform basic assembly and fitment to tolerance",
      "Prepare joints and carry out basic welding & finishing tasks",
      "Follow safety & hot-work permit processes"
    ],
    jobRoles: [
      "Fitter (Fabrication) — fabrication shops, automotive body shops, construction subcontractors",
      "Junior welder/fabricator (with welding module)",
      "Shop floor fitter in capital goods and MSME fabrication units"
    ]
  },
  {
    id: 6,
    title: "Robot Operator & Programmer — Arc Welding",
    duration: "350 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "Diploma/BE in Mechanical / Mechatronics / EEE / Robotics / Welding Technology",
    shortSummary: "This course prepares trainees to operate and program industrial robotic welding cells focusing on safety, teach pendant programming, and path generation.",
    fullDescription: "This course prepares trainees to operate and program industrial robotic welding cells (arc welding — MIG/GMAW/GTAW depending on cell), focusing on robot safety, teach pendant programming, path generation, weld parameter mapping, fixture & part clamping, seam tracking basics and offline programming fundamentals. Practical labs with simulation and live robot cells cover process validation, weld quality checks, parameter tuning and routine maintenance of robotic cells.",
    icon: "CircuitBoard",
    pastelFrom: "#CCFBF1",
    pastelTo: "#E0F2FE",
    iconColor: "#14B8A6",
    topics: [
      "Introduction to industrial robots, kinematics and safety zones",
      "Teach pendant basics, coordinate frames and jogging techniques",
      "Welding process basics: MIG, TIG, flux-core, parameter impact on weld quality",
      "Offline programming overview & simulation workflows",
      "Fixture design for robotic welding and part handling",
      "Weld inspection techniques (visual, fillet size, penetration basics)",
      "Cell maintenance, FMEA for robotic cells and SOPs"
    ],
    skills: [
      "Operate, jog and teach robot paths for arc welding tasks",
      "Program basic welding sequences and set weld parameters",
      "Validate welds and perform first-piece checks",
      "Troubleshoot common robot faults & follow safety lockout procedures"
    ],
    jobRoles: [
      "Robot Welding Operator — automotive body shops (Chennai, Sriperumbudur)",
      "Robotic Cell Technician — Tier-1 OEM suppliers",
      "Welding process technician (robotic cell support)",
      "Offline programmer (with added CAM/robotics software training)"
    ]
  },
  {
    id: 7,
    title: "Technician — Automotive Service (2 & 3 Wheelers)",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "ITI (Motor Mechanic / Two-Wheeler Mechanic) or Diploma (Automobile / Mechanical)",
    shortSummary: "Practical course on routine maintenance, servicing and light repairs for two-wheelers and three-wheelers (auto rickshaws).",
    fullDescription: "Practical course on routine maintenance, servicing and light repairs for two-wheelers and three-wheelers (auto rickshaws). Covers engine tune-up, fuel systems (carburetor & FI), brakes, suspension, clutch, gearbox, electrical troubleshooting, emission norms and vehicle inspection. Teaches quick turn-around service skills required by dealerships and roadside service providers, with emphasis on customer service and turnaround time.",
    icon: "Cog",
    pastelFrom: "#D1FAE5",
    pastelTo: "#ECFDF5",
    iconColor: "#10B981",
    topics: [
      "Two/three-wheeler engine basics: lubrication, cooling & fuel systems",
      "Carburettor & fuel-injection servicing, tune-ups and emission checks",
      "Brakes, tyres, wheel alignment and suspension checks",
      "Gearbox, clutch inspection and adjustments",
      "Electrical basics, battery replacement and lighting checks",
      "Preventive maintenance schedules and service checklists"
    ],
    skills: [
      "Perform scheduled servicing & basic repairs on 2/3-wheelers",
      "Diagnose common faults and perform corrective maintenance",
      "Advise customers on preventive care & emissions compliance",
      "Use service manuals and complete jobcards accurately"
    ],
    jobRoles: [
      "Two-wheeler mechanic — OEM & local dealerships (Hero, TVS, Bajaj, etc.)",
      "Auto rickshaw service technician — fleet owners & municipal fleets",
      "Quick service center technician / mobile service provider"
    ]
  },
  {
    id: 8,
    title: "Light Motor Vehicle (LMV) Driving",
    duration: "21 Days",
    nsqfLevel: "",
    eligibility: "8th pass",
    shortSummary: "Competency-based LMV driving training covering practical driving, traffic rules, road safety, and basic vehicle maintenance.",
    fullDescription: "Competency-based LMV driving training covering practical driving, traffic rules, road safety, basic vehicle maintenance and pre-trip inspections. Trainees learn clutch/throttle control, junction negotiating, safe overtaking, parking and reverse manoeuvres, night driving basics and emergency handling. Includes classroom modules on road rules, eco-driving, basic first aid and soft skills to interact with passengers/employers.",
    icon: "Truck",
    pastelFrom: "#FCE7F3",
    pastelTo: "#FDF2F8",
    iconColor: "#F472B6",
    topics: [
      "Controls, gears and clutch handling; start/stop on slopes",
      "City and highway driving practices, lane discipline",
      "Road signs, signals and CMVR/traffic rules",
      "Night driving, bad-weather driving, emergency evasive actions",
      "Vehicle pre-trip inspection and basic troubleshooting",
      "Defensive driving & eco-driving techniques"
    ],
    skills: [
      "Drive LMV safely in urban & intercity conditions",
      "Perform pre-operational vehicle checks and basic servicing",
      "Maintain logbooks and follow transport regulations",
      "Communicate professionally with passengers/dispatch"
    ],
    jobRoles: [
      "LMV Driver — taxi aggregators, school vans, corporate shuttles, logistics (last-mile)",
      "Driver-cum-Mechanic for small fleets",
      "Chauffeur for hotels & cab operators"
    ]
  },
  {
    id: 9,
    title: "Comprehensive Driving Enhancement Training — Women Auto Drivers (Pink Auto & E-Auto)",
    duration: "3 Weeks",
    nsqfLevel: "",
    eligibility: "Minimum age of 18 years (license eligibility) & Basic literacy recommended",
    shortSummary: "A women-centric, job-ready driving & empowerment program tailored for pink auto and electric auto drivers.",
    fullDescription: "A women-centric, job-ready driving & empowerment program tailored for pink auto and electric auto drivers. The course blends practical driving skills (urban navigation, passenger handling), e-auto charging basics, battery handling for e-autos, personal safety & self-defence awareness, POSH awareness for public workspaces, cashless payment handling and vehicle upkeep. Includes local route mapping, customer service, basic accounting for auto drivers, and self-confidence & communication modules to support sustainable livelihoods.",
    icon: "Users",
    pastelFrom: "#E9D5FF",
    pastelTo: "#F3E8FF",
    iconColor: "#C084FC",
    topics: [
      "Practical driving & manoeuvring for auto-rickshaws (manual and e-auto)",
      "Customer service, gender safety protocols and POSH awareness",
      "EV basics for e-autos: charging, battery care and range management",
      "Fare meter, digital payments and simple bookkeeping",
      "Personal safety, conflict de-escalation and local support systems",
      "Basic vehicle maintenance & daily checks"
    ],
    skills: [
      "Safely operate pink auto & e-auto in urban environments",
      "Manage digital payments and maintain daily accounts",
      "Perform basic battery/charging checks for e-autos",
      "Use safety & PANIC procedures; apply POSH & harassment response knowledge"
    ],
    jobRoles: [
      "Pink Auto / E-Auto Driver (municipal & private hailing)",
      "Small fleet operator / driver trainer for women's collectives"
    ]
  }
];

export function CourseDetailPage({ courseId }: CourseDetailPageProps) {
  const course = detailedCourses.find(c => c.id === courseId);
  const heroRef = useRef(null);
  const descRef = useRef(null);
  const topicsRef = useRef(null);
  const skillsRef = useRef(null);
  const rolesRef = useRef(null);
  
  const isHeroInView = useInView(heroRef, { once: true, margin: "-50px" });
  const isDescInView = useInView(descRef, { once: true, margin: "-50px" });
  const isTopicsInView = useInView(topicsRef, { once: true, margin: "-50px" });
  const isSkillsInView = useInView(skillsRef, { once: true, margin: "-50px" });
  const isRolesInView = useInView(rolesRef, { once: true, margin: "-50px" });

  if (!course) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-xl text-[#64748B]">Course not found</p>
      </div>
    );
  }

  // Icon mapping
  const iconMap: Record<string, any> = {
    Battery,
    Settings,
    Zap,
    Cpu,
    Wrench,
    CircuitBoard,
    Cog,
    Truck,
    Users,
  };

  const IconComponent = iconMap[course.icon];

  return (
    <div className="min-h-screen bg-white">
      {/* Header Section */}
      <section className="pt-32 pb-12 bg-gradient-to-br from-[#F8FAFC] via-white to-[#EEF5FF] relative overflow-hidden">
        {/* Background Decoration */}
        <div className="absolute inset-0 opacity-20">
          <div 
            className="absolute top-20 right-20 size-[500px] rounded-full blur-3xl"
            style={{
              background: `linear-gradient(to bottom right, ${course.pastelFrom}, ${course.pastelTo})`
            }}
          />
        </div>

        <div className="relative max-w-[1200px] mx-auto px-6 lg:px-8">
          {/* Back Button */}
          <motion.a
            href="#courses"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 text-[#0066FF] hover:text-[#0055DD] font-semibold mb-8 group transition-colors"
          >
            <ArrowLeft className="size-5 group-hover:-translate-x-1 transition-transform" />
            <span>Back to All Courses</span>
          </motion.a>

          {/* Hero Layout */}
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left: Course Summary */}
            <motion.div
              ref={heroRef}
              initial={{ opacity: 0, y: 30 }}
              animate={isHeroInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7 }}
            >
              {/* Course Title */}
              <h1 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-6 leading-[1.15]">
                {course.title}
              </h1>

              {/* Meta Info - Duration & NSQF Level */}
              <div className="flex flex-wrap gap-3 mb-6">
                <div className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#EEF5FF] rounded-xl border border-[#0066FF]/20">
                  <Clock className="size-5 text-[#0066FF]" strokeWidth={2} />
                  <span className="font-semibold text-[#0066FF]">{course.duration}</span>
                </div>
                {course.nsqfLevel && (
                  <div className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#F0FDF4] rounded-xl border border-[#16A34A]/20">
                    <Award className="size-5 text-[#16A34A]" strokeWidth={2} />
                    <span className="font-semibold text-[#16A34A]">{course.nsqfLevel}</span>
                  </div>
                )}
              </div>

              {/* Eligibility Summary */}
              <div className="bg-white rounded-2xl border-2 border-[#E2E8F0] p-6 mb-6 shadow-sm">
                <div className="flex items-start gap-3 mb-3">
                  <div 
                    className="p-2.5 rounded-lg flex-shrink-0"
                    style={{
                      background: `linear-gradient(to bottom right, ${course.pastelFrom}, ${course.pastelTo})`
                    }}
                  >
                    <GraduationCap className="size-5" style={{ color: course.iconColor }} strokeWidth={2} />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0A0A0A] mb-1">Eligibility Criteria</h3>
                    <p className="text-[15px] text-[#475569] leading-[1.6]">
                      {course.eligibility}
                    </p>
                  </div>
                </div>
              </div>

              {/* Short Summary */}
              <p className="text-lg text-[#475569] leading-[1.75] mb-6">
                {course.shortSummary}
              </p>
            </motion.div>

            {/* Right: Real Course Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isHeroInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="relative"
            >
              {/* Premium Image Card */}
              <div className="relative w-full aspect-[10/16] lg:aspect-[10/12] rounded-3xl overflow-hidden shadow-2xl border-2 border-[#E2E8F0]">
                <ImageWithFallback
                  src={courseImages[course.id]}
                  alt={course.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Floating Badge */}
              <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl shadow-xl p-5 border-2 border-[#E2E8F0] z-10">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-[#0066FF]/10 rounded-xl">
                    <Zap className="size-6 text-[#0066FF]" strokeWidth={2} />
                  </div>
                  <div>
                    <div className="text-xs text-[#64748B] font-medium">Industry-Ready</div>
                    <div className="font-bold text-[#0A0A0A]">Certification</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Course Description Section */}
      <section ref={descRef} className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isDescInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-[#EEF5FF] rounded-xl">
                <BookOpen className="size-6 text-[#0066FF]" strokeWidth={2} />
              </div>
              <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A]">
                Course Description
              </h2>
            </div>
            
            <div className="bg-gradient-to-br from-[#F8FAFC] to-white rounded-2xl border-2 border-[#E2E8F0] p-8 lg:p-10 shadow-sm">
              <p className="text-[17px] text-[#475569] leading-[1.85]">
                {course.fullDescription}
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Topics Covered Section */}
      <section ref={topicsRef} className="py-20 bg-gradient-to-b from-white to-[#F8FAFC]">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isTopicsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="p-3 bg-[#EEF5FF] rounded-xl">
                <Target className="size-6 text-[#0066FF]" strokeWidth={2} />
              </div>
              <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A]">
                Topics Covered
              </h2>
            </div>

            <div className="grid gap-4">
              {course.topics.map((topic, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isTopicsInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                  className="flex items-start gap-4 bg-white rounded-xl border-2 border-[#E2E8F0] p-5 hover:border-[#0066FF]/30 hover:shadow-md transition-all"
                >
                  <div className="flex-shrink-0 mt-0.5">
                    <CheckCircle2 className="size-5 text-[#0066FF]" strokeWidth={2} />
                  </div>
                  <p className="text-[15px] text-[#475569] leading-[1.6] flex-1">
                    {topic}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Skills Covered Section */}
      <section ref={skillsRef} className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isSkillsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-8">
              <div 
                className="p-3 rounded-xl"
                style={{
                  background: `linear-gradient(to bottom right, ${course.pastelFrom}, ${course.pastelTo})`
                }}
              >
                <Zap className="size-6" style={{ color: course.iconColor }} strokeWidth={2} />
              </div>
              <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A]">
                Skills You'll Develop
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {course.skills.map((skill, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isSkillsInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="group relative bg-gradient-to-br from-white to-[#F8FAFC] rounded-2xl border-2 border-[#E2E8F0] p-6 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div 
                        className="p-2 rounded-lg"
                        style={{
                          background: `linear-gradient(to bottom right, ${course.pastelFrom}, ${course.pastelTo})`
                        }}
                      >
                        <CheckCircle2 className="size-4" style={{ color: course.iconColor }} strokeWidth={2} />
                      </div>
                    </div>
                    <p className="text-[15px] text-[#475569] leading-[1.6] font-medium">
                      {skill}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Job Roles Section */}
      <section ref={rolesRef} className="py-20 bg-gradient-to-b from-[#F8FAFC] to-white">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isRolesInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="p-3 bg-[#F0FDF4] rounded-xl">
                <Briefcase className="size-6 text-[#16A34A]" strokeWidth={2} />
              </div>
              <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A]">
                Career Opportunities
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {course.jobRoles.map((role, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={isRolesInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.5, delay: index * 0.08 }}
                  className="group bg-white rounded-2xl border-2 border-[#E2E8F0] p-6 hover:border-[#16A34A]/30 hover:shadow-lg transition-all"
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <div className="p-3 bg-[#F0FDF4] rounded-xl group-hover:scale-110 transition-transform">
                        <Briefcase className="size-5 text-[#16A34A]" strokeWidth={2} />
                      </div>
                    </div>
                    <p className="text-[15px] text-[#475569] leading-[1.6] font-medium">
                      {role}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section - Register Now */}
      <section className="py-20 bg-gradient-to-br from-[#0066FF] to-[#0090FF] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-[1200px] mx-auto px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <h2 className="text-3xl lg:text-5xl font-extrabold text-white leading-tight">
              Ready to Transform Your Career?
            </h2>
            
            <p className="text-lg lg:text-xl text-white/90 max-w-2xl mx-auto leading-relaxed">
              Enroll in this industry-ready program and gain the skills needed to excel in the automotive sector
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-5 bg-white text-[#0066FF] rounded-2xl font-bold text-lg shadow-2xl hover:shadow-white/30 transition-all min-h-[56px] inline-flex items-center justify-center gap-3"
              >
                <span>Register Now</span>
                <ArrowRight className="size-6" />
              </motion.button>

              <motion.a
                href="/courses"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-5 bg-white/20 backdrop-blur-md border-2 border-white text-white rounded-2xl font-bold text-lg hover:bg-white hover:text-[#0066FF] transition-all shadow-lg min-h-[56px] inline-flex items-center justify-center gap-3"
              >
                <span>Explore All Courses</span>
              </motion.a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}