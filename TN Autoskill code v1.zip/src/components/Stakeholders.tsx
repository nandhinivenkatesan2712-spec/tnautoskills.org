import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const stakeholders = [
  {
    title: "Candidates",
    description: "Transform your career with industry-ready automotive skills",
    image: "https://images.unsplash.com/photo-1653891542022-9645e5f0fa52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvbW90aXZlJTIwd29ya3Nob3AlMjBzdHVkZW50cyUyMGxlYXJuaW5nfGVufDF8fHx8MTc2MzYxODc1OXww&ixlib=rb-4.1.0&q=80&w=1080",
    gradient: "from-blue-900/80 to-blue-600/80",
  },
  {
    title: "Industry",
    description: "Partner with us to develop skilled workforce solutions",
    image: "https://images.unsplash.com/photo-1760507453064-d0b412a7007b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvbW90aXZlJTIwZmFjdG9yeSUyMGluZHVzdHJ5JTIwbW9kZXJufGVufDF8fHx8MTc2MzYxODc2MHww&ixlib=rb-4.1.0&q=80&w=1080",
    gradient: "from-purple-900/80 to-purple-600/80",
  },
  {
    title: "Academia",
    description: "Collaborate to enhance automotive education standards",
    image: "https://images.unsplash.com/photo-1758685848521-ff7e4d136384?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2xhc3Nyb29tJTIwZW5naW5lZXJpbmclMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2MzYxODc2MHww&ixlib=rb-4.1.0&q=80&w=1080",
    gradient: "from-green-900/80 to-green-600/80",
  },
  {
    title: "Trainers & Assessors",
    description: "Join our network of certified automotive professionals",
    image: "https://images.unsplash.com/photo-1758599879065-46fd59235166?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0cmFpbmVyJTIwdGVhY2hpbmclMjB3b3Jrc2hvcHxlbnwxfHx8fDE3NjM2MTg3NjF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    gradient: "from-orange-900/80 to-orange-600/80",
  },
];

export function Stakeholders() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="pt-20 pb-14 bg-white">
      <div className="max-w-[1440px] mx-auto px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="w-24 h-1 bg-gradient-to-r from-[#004ABB] to-[#0055DD] rounded-full mx-auto mb-8" />
          <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
            Empowering Every Stakeholder
          </h2>
          <p className="text-lg xl:text-xl text-[#475569] max-w-3xl mx-auto">
            Tailored solutions for every member of the automotive ecosystem
          </p>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {stakeholders.map((stakeholder, index) => (
            <motion.div
              key={stakeholder.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="group relative h-[400px] rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 cursor-pointer"
            >
              {/* Background Image */}
              <div className="absolute inset-0">
                <ImageWithFallback
                  src={stakeholder.image}
                  alt={stakeholder.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>

              {/* Gradient Overlay */}
              <div className={`absolute inset-0 bg-gradient-to-t ${stakeholder.gradient} group-hover:opacity-90 transition-opacity duration-500`} />

              {/* Content */}
              <div className="absolute inset-0 flex flex-col justify-end p-8 lg:p-10">
                <motion.div
                  initial={{ y: 20 }}
                  whileHover={{ y: 0 }}
                  className="space-y-4"
                >
                  <h3 className="text-white text-3xl lg:text-4xl font-bold">
                    {stakeholder.title}
                  </h3>
                  <p className="text-white/90 text-lg leading-relaxed">
                    {stakeholder.description}
                  </p>
                  
                  {/* Arrow Icon */}
                  <motion.div
                    className="flex items-center gap-3 text-white"
                    whileHover={{ x: 5 }}
                  >
                    <span className="text-lg font-semibold">Learn More</span>
                    <div className="size-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/30 transition-colors">
                      <ArrowRight className="size-5" />
                    </div>
                  </motion.div>
                </motion.div>
              </div>

              {/* Hover Border Effect */}
              <div className="absolute inset-0 border-4 border-white/0 group-hover:border-white/20 rounded-3xl transition-colors duration-500" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}