import { motion } from "motion/react";

interface SectionIndicatorProps {
  isInView: boolean;
}

export function SectionIndicator({ isInView }: SectionIndicatorProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scaleX: 0 }}
      animate={isInView ? { scaleX: 1 } : {}}
      transition={{ duration: 0.8, delay: 0.2 }}
      className="w-24 h-1 bg-gradient-to-r from-[#004ABB] to-[#0055DD] rounded-full mx-auto mb-8"
      style={{ transformOrigin: "left" }}
    />
  );
}