import { motion, useMotionValue, useTransform, animate } from "motion/react";
import { useInView } from "motion/react";
import { useRef, useEffect, useState } from "react";
import { Users, FileCheck, Briefcase, Building2, TrendingUp } from "lucide-react";

const milestones = [
  {
    icon: Users,
    number: 2500,
    label: "Trained",
    suffix: "+",
    iconBg: "bg-blue-50",
    iconColor: "text-blue-600",
  },
  {
    icon: FileCheck,
    number: 500,
    label: "Assessed",
    suffix: "+",
    iconBg: "bg-purple-50",
    iconColor: "text-purple-600",
  },
  {
    icon: Briefcase,
    number: 200,
    label: "Placed",
    suffix: "+",
    iconBg: "bg-green-50",
    iconColor: "text-green-600",
  },
  {
    icon: Building2,
    number: 40,
    label: "Industry Partners",
    suffix: "+",
    iconBg: "bg-orange-50",
    iconColor: "text-orange-600",
  },
  {
    icon: TrendingUp,
    number: 95,
    label: "Placement Rate",
    suffix: "%",
    iconBg: "bg-teal-50",
    iconColor: "text-teal-600",
  },
];

function Counter({ value, suffix = "" }: { value: number; suffix?: string }) {
  const count = useMotionValue(0);
  const rounded = useTransform(count, (latest) => Math.round(latest));
  const [displayValue, setDisplayValue] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      const controls = animate(count, value, {
        duration: 2,
        ease: "easeOut",
      });
      return controls.stop;
    }
  }, [isInView, value, count]);

  useEffect(() => {
    const unsubscribe = rounded.on("change", (latest) => {
      setDisplayValue(latest);
    });
    return unsubscribe;
  }, [rounded]);

  return (
    <span ref={ref} className="tabular-nums">
      {displayValue}
      {suffix}
    </span>
  );
}

export function Milestones() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-16 lg:py-20 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 max-w-2xl mx-auto"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Our Milestones
          </h2>
          <p className="text-base text-[#64748b]">
            Real-time performance metrics driving automotive excellence
          </p>
        </motion.div>

        {/* Compact Stats Grid - Dashboard Style */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-5">
          {milestones.map((milestone, index) => {
            const Icon = milestone.icon;
            
            return (
              <motion.div
                key={milestone.label}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                whileHover={{ y: -3, boxShadow: "0 8px 16px rgba(0, 0, 0, 0.06)" }}
                className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-all duration-300"
              >
                {/* Icon at Top */}
                <div className={`size-10 ${milestone.iconBg} rounded-lg flex items-center justify-center mb-3`}>
                  <Icon className={`size-5 ${milestone.iconColor}`} strokeWidth={2.5} />
                </div>

                {/* Big Number */}
                <div className="text-3xl font-extrabold text-[#0A0A0A] mb-1 leading-none">
                  <Counter value={milestone.number} suffix={milestone.suffix} />
                </div>

                {/* Small Label */}
                <div className="text-xs text-[#64748b] font-medium leading-tight">
                  {milestone.label}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Data Source */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-8 text-center"
        >
          <p className="text-xs text-[#64748b]">
            Data updated as of <span className="font-semibold text-[#0A0A0A]">November 2024</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
