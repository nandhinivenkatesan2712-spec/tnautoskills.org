import { motion } from "motion/react";
import { ArrowRight, Target, Eye, Users, Award, Building2 } from "lucide-react";

const submenuCards = [
  {
    title: "Our Board Members",
    description: "Meet the visionary leaders guiding TN AutoSkills towards excellence in automotive skill development",
    icon: Award,
    href: "#board-members",
    stats: "6 Distinguished Leaders",
  },
  {
    title: "Our Team",
    description: "Discover the dedicated professionals and expert faculty driving transformation through quality education",
    icon: Users,
    href: "#our-team",
    stats: "50+ Team Members",
  },
];

export function AboutPage() {
  return (
    <div className="bg-white" id="about">
      {/* Section 1: About Overview */}
      <section className="py-[120px] bg-white relative">
        {/* Subtle Section Divider Top */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />

        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16 space-y-4"
          >
            <h2 className="text-5xl lg:text-6xl font-extrabold text-[rgb(0,38,255)] tracking-tight">
              About Overview
            </h2>
            <p className="text-[17px] text-[#475569] leading-[1.6] max-w-3xl mx-auto">
              Building tomorrow's automotive workforce through excellence, innovation, and industry partnerships
            </p>
          </motion.div>

          {/* Overview Grid */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Who We Are */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6 }}
              whileHover={{ y: -4 }}
              className="group"
            >
              <div className="relative p-10 bg-white rounded-xl border-2 border-[#E2E8F0] hover:border-[#0066FF]/30 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-[#0066FF]/10 h-full">
                <div className="p-4 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl w-fit mb-6">
                  <Building2 className="size-7 text-white" strokeWidth={2} />
                </div>
                
                <h3 className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A] mb-4">
                  Who We Are
                </h3>
                
                <p className="text-[17px] text-[#475569] leading-[1.6]">
                  TN AutoSkills is Tamil Nadu's apex skill development centre dedicated to the automotive sector, established under the Government of Tamil Nadu's initiative to bridge the skill gap in India's rapidly growing automotive industry. We are a state-of-the-art training facility equipped with cutting-edge technology and industry-aligned curriculum.
                </p>
              </div>
            </motion.div>

            {/* Government Initiative */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: 0.1 }}
              whileHover={{ y: -4 }}
              className="group"
            >
              <div className="relative p-10 bg-white rounded-xl border-2 border-[#E2E8F0] hover:border-[#0066FF]/30 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-[#0066FF]/10 h-full">
                <div className="p-4 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl w-fit mb-6">
                  <Award className="size-7 text-white" strokeWidth={2} />
                </div>
                
                <h3 className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A] mb-4">
                  Government Initiative
                </h3>
                
                <p className="text-[17px] text-[#475569] leading-[1.6]">
                  A flagship initiative by the Government of Tamil Nadu aimed at developing industry-ready automotive talent. With Tamil Nadu being a major automotive manufacturing hub, our centre creates a steady pipeline of trained professionals for OEMs, Tier-1 suppliers, and the broader automotive ecosystem.
                </p>
              </div>
            </motion.div>

            {/* Vision */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: 0.2 }}
              whileHover={{ y: -4 }}
              className="group"
            >
              <div className="relative p-10 bg-white rounded-xl border-2 border-[#E2E8F0] hover:border-[#0066FF]/30 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-[#0066FF]/10 h-full">
                <div className="p-4 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl w-fit mb-6">
                  <Eye className="size-7 text-white" strokeWidth={2} />
                </div>
                
                <h3 className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A] mb-4">
                  Our Vision
                </h3>
                
                <p className="text-[17px] text-[#475569] leading-[1.6] mb-6">
                  To be India's leading automotive skill development centre, recognized globally for excellence in training and creating a workforce that drives innovation, sustainability, and growth in the automotive industry.
                </p>

                <div className="flex flex-wrap gap-2">
                  {["Excellence", "Innovation", "Leadership"].map((tag) => (
                    <span
                      key={tag}
                      className="px-4 py-2 bg-[#0066FF]/8 text-[#0066FF] rounded-lg text-sm font-semibold"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Mission */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: 0.3 }}
              whileHover={{ y: -4 }}
              className="group"
            >
              <div className="relative p-10 bg-white rounded-xl border-2 border-[#E2E8F0] hover:border-[#0066FF]/30 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-[#0066FF]/10 h-full">
                <div className="p-4 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl w-fit mb-6">
                  <Target className="size-7 text-white" strokeWidth={2} />
                </div>
                
                <h3 className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A] mb-4">
                  Our Mission
                </h3>
                
                <p className="text-[17px] text-[#475569] leading-[1.6] mb-6">
                  To empower youth with industry-relevant automotive skills through world-class training infrastructure, expert faculty, and strong industry partnerships, ensuring 100% employability and fostering continuous learning.
                </p>

                <div className="flex flex-wrap gap-2">
                  {["Empower", "Train", "Transform"].map((tag) => (
                    <span
                      key={tag}
                      className="px-4 py-2 bg-[#0066FF]/8 text-[#0066FF] rounded-lg text-sm font-semibold"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Subtle Section Divider Bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />
      </section>

      {/* Section 2: Leadership Cards */}
      <section className="py-[120px] bg-[#F8FAFB] relative">
        {/* Subtle Section Divider Top */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />

        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16 space-y-4"
          >
            <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] tracking-tight">
              Meet Our Leadership
            </h2>
            <p className="text-[17px] text-[#475569] leading-[1.6] max-w-3xl mx-auto">
              Learn more about the people driving excellence at TN AutoSkills
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8">
            {submenuCards.map((card, index) => (
              <motion.a
                key={card.title}
                href={card.href}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -4 }}
                className="relative group block"
              >
                <div className="relative p-10 bg-white rounded-xl border-2 border-[#E2E8F0] group-hover:border-[#0066FF]/30 transition-all duration-300 shadow-sm group-hover:shadow-xl group-hover:shadow-[#0066FF]/10 h-full">
                  {/* Icon */}
                  <div className="p-5 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl w-fit mb-6">
                    <card.icon className="size-8 text-white" strokeWidth={2} />
                  </div>
                  
                  {/* Title & Arrow */}
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A] flex-1">
                      {card.title}
                    </h3>
                    <motion.div
                      className="p-2.5 bg-[#0066FF]/8 rounded-lg text-[#0066FF] group-hover:bg-[#0066FF] group-hover:text-white transition-all duration-300"
                      whileHover={{ scale: 1.05 }}
                    >
                      <ArrowRight className="size-5" strokeWidth={2} />
                    </motion.div>
                  </div>
                  
                  {/* Stats */}
                  <div className="mb-5 pb-5 border-b border-[#E2E8F0]">
                    <p className="text-sm font-semibold text-[#0066FF]">
                      {card.stats}
                    </p>
                  </div>

                  {/* Description */}
                  <p className="text-[17px] text-[#475569] leading-[1.6]">
                    {card.description}
                  </p>
                </div>
              </motion.a>
            ))}
          </div>
        </div>

        {/* Subtle Section Divider Bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />
      </section>

      {/* Section 3: Key Highlights */}
      <section className="py-[120px] bg-white relative">
        {/* Subtle Section Divider Top */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />

        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="relative p-12 lg:p-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl text-white overflow-hidden shadow-2xl shadow-[#0066FF]/20"
          >
            {/* Background Pattern */}
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS1vcGFjaXR5PSIwLjA1IiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30" />
            
            <div className="relative grid lg:grid-cols-4 gap-8 lg:gap-12">
              {[
                { value: "50+", label: "MoUs with Industry Leaders" },
                { value: "2,500+", label: "Students Placed Successfully" },
                { value: "100+", label: "Industry Partner Companies" },
                { value: "₹50Cr+", label: "Government Investment" },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <p className="text-4xl lg:text-5xl font-extrabold mb-3">{stat.value}</p>
                  <p className="text-white/90 text-[15px] leading-[1.6]">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Subtle Section Divider Bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />
      </section>
    </div>
  );
}