import { motion, useScroll, useTransform } from "motion/react";
import { useRef, ReactNode } from "react";

interface UnifiedBannerProps {
  title: string;
  subtitle: string;
  badge?: ReactNode;
  tamilTitle?: string;
}

export function UnifiedBanner({ title, subtitle, badge, tamilTitle }: UnifiedBannerProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0.8]);

  return (
    <section
      ref={sectionRef}
      className="relative bg-gradient-to-br from-[#EEF5FF] via-[#F8FBFF] to-[#E3F2FD] overflow-hidden"
      style={{ height: "500px" }}
    >
      {/* Animated Mesh Gradient Background */}
      <motion.div
        style={{ y }}
        className="absolute inset-0"
      >
        {/* Soft Gradient Orbs */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.3, 0.2],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-20 left-[15%] w-96 h-96 bg-[#0066FF]/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute bottom-20 right-[15%] w-96 h-96 bg-[#0090FF]/20 rounded-full blur-3xl"
        />

        {/* Subtle Wave Pattern */}
        <div className="absolute inset-0 opacity-5">
          <svg className="w-full h-full" viewBox="0 0 1440 500" xmlns="http://www.w3.org/2000/svg">
            <path 
              d="M0,250 Q360,200 720,250 T1440,250 L1440,500 L0,500 Z" 
              fill="#0066FF"
              opacity="0.1"
            />
            <path 
              d="M0,300 Q360,250 720,300 T1440,300 L1440,500 L0,500 Z" 
              fill="#0090FF"
              opacity="0.05"
            />
          </svg>
        </div>

        {/* Floating Geometric Shapes */}
        <motion.div
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-16 right-[10%] w-20 h-20 border-3 border-[#0066FF]/20 rounded-2xl rotate-12"
        />
        <motion.div
          animate={{
            y: [0, 25, 0],
            rotate: [0, -8, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute bottom-24 left-[8%] w-16 h-16 bg-[#0090FF]/10 rounded-full"
        />
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-1/3 left-[12%] w-12 h-12 bg-[#0066FF]/15 rounded-lg rotate-45"
        />
      </motion.div>

      {/* Content */}
      <div className="relative z-10 h-full flex items-center justify-center">
        <motion.div
          style={{ opacity }}
          className="max-w-[1440px] mx-auto px-8 text-center"
        >
          <div className="pt-16">
            {/* Optional Badge */}
            {badge && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="mb-6 flex justify-center"
              >
                {badge}
              </motion.div>
            )}

            {/* Tamil Title (Optional) */}
            {tamilTitle && (
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-2xl lg:text-3xl font-bold text-[#0066FF] mb-3"
                style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
              >
                {tamilTitle}
              </motion.h2>
            )}

            {/* Main Title */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: tamilTitle ? 0.2 : 0.1 }}
              className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6"
            >
              {title}
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: tamilTitle ? 0.3 : 0.2 }}
              className="text-xl lg:text-2xl text-[#475569] max-w-4xl mx-auto"
            >
              {subtitle}
            </motion.p>
          </div>
        </motion.div>
      </div>

      {/* Bottom Fade */}
      <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-white to-transparent pointer-events-none" />
    </section>
  );
}
