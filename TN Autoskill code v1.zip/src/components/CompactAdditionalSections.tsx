import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Building2,
  Cog,
  ShoppingCart,
  Lightbulb,
  UserPlus,
  Heart,
  BookOpen,
  GraduationCap,
  ArrowRight,
  CheckCircle,
  Users,
} from "lucide-react";

// 11. EMPANELMENT - Compact 4-Card Grid
export function EmpanelmentCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const categories = [
    {
      icon: Building2,
      title: "OEMs (Original Equipment Manufacturers)",
      points: [
        "Partner for workforce development programs",
        "Co-create specialized training modules",
        "Access to skilled talent pool",
        "Industry-aligned certification programs",
      ],
    },
    {
      icon: Cog,
      title: "Automotive Suppliers & Component Manufacturers",
      points: [
        "Collaborate on technical skill training",
        "Supplier-specific competency development",
        "Quality assurance and testing training",
        "Supply chain integration programs",
      ],
    },
    {
      icon: ShoppingCart,
      title: "Retail & Service Networks",
      points: [
        "Service technician training programs",
        "Customer service excellence modules",
        "After-sales support training",
        "Dealership management programs",
      ],
    },
    {
      icon: Lightbulb,
      title: "Automotive Startups & Innovation Hubs",
      points: [
        "EV and new mobility solutions training",
        "Technology integration programs",
        "Innovation and R&D collaboration",
        "Emerging technology skill development",
      ],
    },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10 mb-4">
            <div className="size-1.5 bg-[#0066FF] rounded-full" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Industry Partners</span>
          </div>

          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Empanelment Opportunities
          </h2>

          <p className="text-sm lg:text-base text-[#0A0A0A]/60 max-w-3xl mx-auto">
            Join our network of industry partners to build a skilled automotive workforce
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {categories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-gradient-to-br from-[#F3F6F9] to-white rounded-xl p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="size-12 bg-[#0066FF] rounded-lg flex items-center justify-center flex-shrink-0">
                    <IconComponent className="size-6 text-white" />
                  </div>
                  <h3 className="font-bold text-[#0A0A0A] text-base leading-tight">
                    {category.title}
                  </h3>
                </div>

                <ul className="space-y-2">
                  {category.points.map((point, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-[#0A0A0A]/70">
                      <CheckCircle className="size-3.5 text-[#0066FF] flex-shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-8"
        >
          <a
            href="#empanelment"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0066FF] text-white rounded-lg font-semibold text-sm hover:bg-[#0055EE] transition-colors"
          >
            <span>Apply for Empanelment</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 12. HR REGISTRATION - Compact CTA Section
export function HRRegistrationCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-[#F3F6F9]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="bg-white rounded-2xl p-8 lg:p-10 border border-gray-100 shadow-lg"
          >
            <div className="grid lg:grid-cols-[60%_40%] gap-8 items-center">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10">
                  <UserPlus className="size-3 text-[#0066FF]" />
                  <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Recruitment</span>
                </div>

                <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] leading-tight">
                  HR Registration for Recruitment
                </h2>

                <p className="text-base text-[#0A0A0A]/70 leading-relaxed">
                  Register your organization to access our pool of trained and certified automotive professionals. Connect with skilled candidates ready to join your workforce.
                </p>

                <ul className="space-y-2">
                  {[
                    "Access to 2500+ trained candidates",
                    "Industry-certified professionals",
                    "Streamlined recruitment process",
                    "Customized skill matching",
                  ].map((item, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-[#0A0A0A]/70">
                      <CheckCircle className="size-4 text-[#0066FF]" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-col gap-4">
                <a
                  href="#hr-register"
                  className="px-6 py-4 bg-[#0066FF] text-white rounded-xl font-bold text-base shadow-lg hover:bg-[#0055EE] transition-colors text-center"
                >
                  Register Now
                </a>
                <a
                  href="#contact"
                  className="px-6 py-4 bg-transparent text-[#0066FF] border-2 border-[#0066FF] rounded-xl font-bold text-base hover:bg-[#0066FF]/5 transition-colors text-center"
                >
                  Contact Us
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// 13. CSR PROJECTS - Compact Highlight Cards
export function CSRProjectsCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const projects = [
    {
      icon: Heart,
      title: "Community Skill Development",
      description: "Partner with us to provide free automotive training to underprivileged youth and create employment opportunities in rural Tamil Nadu.",
      impact: "500+ beneficiaries trained",
    },
    {
      icon: GraduationCap,
      title: "Women in Automotive Initiative",
      description: "Support our program to train and empower women in automotive technology, breaking gender barriers in the industry.",
      impact: "200+ women professionals",
    },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10 mb-4">
            <Heart className="size-3 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Social Impact</span>
          </div>

          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            CSR Projects
          </h2>

          <p className="text-sm lg:text-base text-[#0A0A0A]/60 max-w-3xl mx-auto">
            Collaborate with us on Corporate Social Responsibility initiatives to create lasting social impact
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {projects.map((project, index) => {
            const IconComponent = project.icon;
            return (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-gradient-to-br from-[#F3F6F9] to-white rounded-xl p-8 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                <div className="size-14 bg-[#0066FF] rounded-xl flex items-center justify-center mb-4">
                  <IconComponent className="size-7 text-white" />
                </div>

                <h3 className="text-xl font-bold text-[#0A0A0A] mb-3">
                  {project.title}
                </h3>

                <p className="text-sm text-[#0A0A0A]/70 leading-relaxed mb-4">
                  {project.description}
                </p>

                <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/10 rounded-lg">
                  <Users className="size-4 text-[#0066FF]" />
                  <span className="text-xs font-bold text-[#0066FF]">{project.impact}</span>
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center"
        >
          <a
            href="#csr-register"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0066FF] text-white rounded-lg font-semibold text-sm hover:bg-[#0055EE] transition-colors"
          >
            <span>CSR Partnership Registration</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 14. ACADEMIA & ALUMNI - Compact Two-Column
export function AcademiaAlumniCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-[#F3F6F9]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-[55%_45%] gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="space-y-5"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0066FF]/10">
              <BookOpen className="size-3 text-[#0066FF]" />
              <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Education Network</span>
            </div>

            <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] leading-tight">
              Academia & Alumni Support
            </h2>

            <p className="text-base text-[#0A0A0A]/70 leading-relaxed">
              We collaborate with engineering colleges, polytechnics, and ITIs to bridge the gap between academic learning and industry requirements. Our alumni network provides ongoing career support and mentorship.
            </p>

            <div className="space-y-3">
              {[
                {
                  title: "Academic Partnerships",
                  desc: "Curriculum co-development and faculty training programs",
                },
                {
                  title: "Student Placement",
                  desc: "Direct industry connections and job placement assistance",
                },
                {
                  title: "Alumni Network",
                  desc: "Continuous upskilling and career advancement support",
                },
                {
                  title: "Research Collaboration",
                  desc: "Joint R&D projects and innovation initiatives",
                },
              ].map((item, index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.1 + index * 0.1 }}
                  className="flex items-start gap-3 bg-white rounded-lg p-4 border border-gray-100"
                >
                  <CheckCircle className="size-5 text-[#0066FF] flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-[#0A0A0A] text-sm mb-1">{item.title}</div>
                    <div className="text-xs text-[#0A0A0A]/60">{item.desc}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            <a
              href="#academia"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#0066FF] text-white rounded-lg font-semibold text-sm hover:bg-[#0055EE] transition-colors"
            >
              <span>Partner With Us</span>
              <ArrowRight className="size-4" />
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative hidden lg:flex justify-center"
          >
            <div className="relative">
              {/* Illustration Placeholder */}
              <div className="w-full max-w-[350px] h-[350px] bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/5 rounded-2xl flex items-center justify-center border border-[#0066FF]/10">
                <div className="text-center space-y-4">
                  <GraduationCap className="size-24 text-[#0066FF]/40 mx-auto" />
                  <div className="space-y-2">
                    <div className="text-4xl font-extrabold text-[#0066FF]">500+</div>
                    <div className="text-sm font-semibold text-[#0A0A0A]/60">Academic Partners</div>
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -top-4 -right-4 size-20 bg-white rounded-xl shadow-lg border border-gray-100 flex items-center justify-center"
              >
                <BookOpen className="size-10 text-[#0066FF]" />
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// 15. PLACEMENT REGISTRATION - Compact CTA Section
export function PlacementRegistrationCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl p-8 lg:p-10 text-center text-white shadow-xl"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full border border-white/30 mb-6">
              <GraduationCap className="size-3 text-white" />
              <span className="text-xs font-bold text-white uppercase tracking-wide">For Colleges</span>
            </div>

            <h2 className="text-3xl lg:text-4xl font-extrabold text-white mb-4 leading-tight">
              College Placement Registration
            </h2>

            <p className="text-base text-white/90 leading-relaxed mb-6 max-w-2xl mx-auto">
              Register your college to enable your students to access placement opportunities with leading automotive companies through TN Auto Skills.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-6">
              <div className="flex items-center gap-2 text-sm text-white/90">
                <CheckCircle className="size-4" />
                <span>Free Registration</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-white/90">
                <CheckCircle className="size-4" />
                <span>Direct Industry Connections</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-white/90">
                <CheckCircle className="size-4" />
                <span>100% Placement Support</span>
              </div>
            </div>

            <a
              href="#placement-register"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-[#0066FF] rounded-xl font-bold text-base shadow-lg hover:shadow-xl hover:bg-blue-50 transition-all"
            >
              <span>College Registration</span>
              <ArrowRight className="size-5" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
