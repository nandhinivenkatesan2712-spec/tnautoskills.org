import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Zap,
  Cpu,
  Leaf,
  Layers,
  ArrowRight,
} from "lucide-react";

export function CompactGlobalCurriculum() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const frameworks = [
    {
      icon: Zap,
      title: "EV Framework",
      description: "batteries, motors, power electronics, charging, diagnostics",
    },
    {
      icon: Cpu,
      title: "Software-Defined Vehicle Framework",
      description: "embedded systems, AI/ML, OTA, cybersecurity",
    },
    {
      icon: Leaf,
      title: "Green & Flexi Fuel Framework",
      description: "hydrogen, ethanol, biofuels, sustainable propulsion",
    },
    {
      icon: Layers,
      title: "Vehicle Architecture Framework",
      description: "system integration, safety engineering, electronics architecture",
    },
  ];

  const partners = [
    "Hyundai",
    "Bosch",
    "NVIDIA",
    "ASDC",
    "ICAT",
  ];

  return (
    <section ref={ref} className="py-20 bg-white relative overflow-hidden">
      {/* Subtle Background Accent */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-[#0066FF]/5 to-transparent rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-[52px] font-extrabold text-[#0A1628] leading-tight mb-3">
            Global Automotive Curriculum Framework
          </h2>
          <p className="text-xl lg:text-[22px] text-[#475569] font-medium leading-relaxed max-w-4xl mx-auto">
            A Future-Ready Learning Framework Developed With Leading Global Automotive Institutions
          </p>
        </motion.div>

        {/* 2×2 Grid of Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {frameworks.map((framework, idx) => {
            const Icon = framework.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 + idx * 0.1 }}
                whileHover={{ y: -4 }}
                className="group bg-gradient-to-br from-white to-[#F8FAFB] rounded-xl p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                {/* Icon */}
                <div className="size-12 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-lg flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Icon className="size-6 text-[#0066FF]" strokeWidth={2} />
                </div>

                {/* Title */}
                <h3 className="text-xl lg:text-[22px] font-bold text-[#0A1628] leading-tight mb-2">
                  {framework.title}
                </h3>

                {/* Description */}
                <p className="text-base lg:text-[17px] text-[#64748B] leading-relaxed">
                  {framework.description}
                </p>

                {/* Hover Indicator */}
                <div className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-[#0066FF] opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Learn more</span>
                  <ArrowRight className="size-3.5" strokeWidth={2.5} />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Partner Logo Strip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="mb-8"
        >
          <p className="text-sm font-semibold text-[#64748B] uppercase tracking-wider text-center mb-6">
            Curriculum Development Partners
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8">
            {partners.map((partner, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.4, delay: 0.8 + idx * 0.08 }}
                className="grayscale hover:grayscale-0 transition-all"
              >
                <div className="px-5 py-2 bg-gray-50 rounded-lg border border-gray-100 hover:border-[#0066FF]/30 hover:bg-white transition-all">
                  <span className="text-sm font-bold text-[#0A1628]">{partner}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 1 }}
          className="text-center"
        >
          <a
            href="#curriculum"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-semibold text-[15px] shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            <span>View Full Curriculum</span>
            <ArrowRight className="size-4" strokeWidth={2.5} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
