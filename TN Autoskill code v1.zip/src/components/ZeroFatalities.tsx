import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Shield, HeartPulse, Wrench } from "lucide-react";

const pillars = [
  {
    icon: Shield,
    title: "Smart Traffic Management",
    description: "AI-powered systems for safer road networks",
    gradient: "from-blue-500 to-blue-600",
  },
  {
    icon: HeartPulse,
    title: "Emergency Care Support",
    description: "Rapid response and medical assistance",
    gradient: "from-red-500 to-red-600",
  },
  {
    icon: Wrench,
    title: "Engineering Improvements",
    description: "Infrastructure upgrades for road safety",
    gradient: "from-green-500 to-green-600",
  },
];

export function ZeroFatalities() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative pt-20 pb-14 bg-[#0A0A0A] overflow-hidden">
      {/* Background Map Pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern
              id="road-network"
              x="0"
              y="0"
              width="100"
              height="100"
              patternUnits="userSpaceOnUse"
            >
              <path
                d="M 0 50 Q 25 25 50 50 T 100 50"
                fill="none"
                stroke="white"
                strokeWidth="1"
              />
              <path
                d="M 50 0 Q 25 25 50 50 T 50 100"
                fill="none"
                stroke="white"
                strokeWidth="1"
              />
              <circle cx="50" cy="50" r="3" fill="white" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#road-network)" />
        </svg>
      </div>

      {/* Gradient Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.15, 0.25, 0.15],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-20 right-20 w-[600px] h-[600px] bg-gradient-radial from-blue-500/30 to-transparent rounded-full blur-3xl"
      />

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 lg:mb-16 space-y-5"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="inline-block"
          >
            <div className="size-20 mx-auto bg-gradient-to-br from-red-500 to-orange-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-red-500/50 mb-6">
              <Shield className="size-10 text-white" strokeWidth={2} />
            </div>
          </motion.div>

          <h2 className="text-white text-5xl lg:text-6xl xl:text-7xl font-extrabold leading-tight max-w-4xl mx-auto">
            Zero Road Fatalities by{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#0066FF] to-[#00A0E9]">
              2030
            </span>
          </h2>
          
          <p className="text-gray-300 text-xl lg:text-2xl max-w-3xl mx-auto leading-relaxed">
            Our commitment to creating safer roads through technology,
            infrastructure, and emergency response excellence.
          </p>
        </motion.div>

        {/* Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {pillars.map((pillar, index) => {
            const Icon = pillar.icon;
            
            return (
              <motion.div
                key={pillar.title}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.4 + index * 0.15 }}
                whileHover={{ y: -10, scale: 1.05 }}
                className="group relative bg-white/5 backdrop-blur-md rounded-3xl p-8 lg:p-10 border border-white/10 hover:border-white/30 transition-all duration-500"
              >
                {/* Glow Effect */}
                <div className={`absolute inset-0 bg-gradient-to-br ${pillar.gradient} opacity-0 group-hover:opacity-10 rounded-3xl transition-opacity duration-500`} />
                
                {/* Icon */}
                <div className={`relative size-20 bg-gradient-to-br ${pillar.gradient} rounded-2xl flex items-center justify-center mb-6 shadow-2xl group-hover:scale-110 transition-transform duration-500`}>
                  <Icon className="size-10 text-white" strokeWidth={2} />
                </div>

                {/* Content */}
                <div className="relative space-y-4">
                  <h3 className="text-white text-2xl lg:text-3xl font-bold leading-tight">
                    {pillar.title}
                  </h3>
                  <p className="text-gray-300 text-lg leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                {/* Number Badge */}
                <div className="absolute top-8 right-8 size-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/20">
                  <span className="text-white text-xl font-bold">
                    {index + 1}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Stats Banner */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-16 lg:mt-24 bg-gradient-to-r from-white/10 to-white/5 backdrop-blur-md rounded-3xl p-8 lg:p-12 border border-white/20"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-5xl lg:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-[#0066FF] to-[#00A0E9] mb-2">
                50%
              </div>
              <div className="text-white/80 text-lg">
                Reduction Target by 2025
              </div>
            </div>
            <div>
              <div className="text-5xl lg:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-green-600 mb-2">
                100%
              </div>
              <div className="text-white/80 text-lg">
                Vision for 2030
              </div>
            </div>
            <div>
              <div className="text-5xl lg:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-purple-600 mb-2">
                24/7
              </div>
              <div className="text-white/80 text-lg">
                Emergency Response
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}