import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Send,
  Clock,
  Headphones,
  CheckCircle2,
  AlertCircle,
  HelpCircle
} from "lucide-react";
import { UnifiedBanner } from "./UnifiedBanner";

// Contact categories for dropdown
const categories = [
  "General Inquiry",
  "Admissions",
  "Courses",
  "Partnerships",
  "Media/Press"
];

export function ContactPage() {
  const detailsRef = useRef(null);
  const formRef = useRef(null);
  const mapRef = useRef(null);
  const helplineRef = useRef(null);
  
  const isDetailsInView = useInView(detailsRef, { once: true, margin: "-100px" });
  const isFormInView = useInView(formRef, { once: true, margin: "-100px" });
  const isMapInView = useInView(mapRef, { once: true, margin: "-100px" });
  const isHelplineInView = useInView(helplineRef, { once: true, margin: "-100px" });

  // Form state
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    mobile: "",
    category: "General Inquiry",
    message: ""
  });

  const [formStatus, setFormStatus] = useState<"idle" | "success" | "error">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  // Form validation
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.fullName.trim()) {
      newErrors.fullName = "Full name is required";
    }
    
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email";
    }
    
    if (!formData.message.trim()) {
      newErrors.message = "Message is required";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      setFormStatus("error");
      return;
    }
    
    // Simulate form submission
    setFormStatus("success");
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setFormData({
        fullName: "",
        email: "",
        mobile: "",
        category: "General Inquiry",
        message: ""
      });
      setFormStatus("idle");
    }, 3000);
  };

  return (
    <div className="bg-white">
      {/* Unified Banner */}
      <UnifiedBanner
        title="Contact TN AutoSkills"
        subtitle="Reach out to us for admissions, partnerships, and general inquiries"
        badge={
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/90 backdrop-blur-md rounded-2xl shadow-lg border border-gray-100">
            <Mail className="size-8 text-[#0066FF]" />
            <div className="text-left">
              <div className="text-sm font-bold text-[#0A0A0A]">Get In Touch</div>
              <div className="text-xs text-[#64748b]">We're Here to Help</div>
            </div>
          </div>
        }
      />

      {/* Contact Details Section */}
      <section ref={detailsRef} className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isDetailsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-6" />
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
              How to Reach Us
            </h2>
            <p className="text-lg text-[#475569] max-w-3xl mx-auto">
              Multiple ways to connect with TN AutoSkills team
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {/* Address Card */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={isDetailsInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 }}
              whileHover={{ y: -8 }}
              className="bg-gradient-to-br from-[#F8FBFF] to-[#EEF5FF] rounded-2xl p-8 border border-gray-200 shadow-md hover:shadow-xl transition-all"
            >
              <div className="size-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl flex items-center justify-center mb-5 shadow-lg">
                <MapPin className="size-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#0A0A0A] mb-3">
                Our Address
              </h3>
              <p className="text-base text-[#475569] leading-relaxed">
                TN AutoSkills<br />
                Apex Skill Development Centre for Automobile<br />
                Chennai, Tamil Nadu<br />
                India - 600001
              </p>
            </motion.div>

            {/* Phone Card */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={isDetailsInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              whileHover={{ y: -8 }}
              className="bg-gradient-to-br from-[#F8FBFF] to-[#EEF5FF] rounded-2xl p-8 border border-gray-200 shadow-md hover:shadow-xl transition-all"
            >
              <div className="size-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl flex items-center justify-center mb-5 shadow-lg">
                <Phone className="size-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#0A0A0A] mb-3">
                Phone Numbers
              </h3>
              <div className="space-y-2 text-base text-[#475569]">
                <p>
                  <strong className="text-[#0A0A0A]">Office:</strong><br />
                  +91 XXXXX XXXXX
                </p>
                <p>
                  <strong className="text-[#0A0A0A]">Support:</strong><br />
                  +91 XXXXX XXXXX
                </p>
              </div>
            </motion.div>

            {/* Email Card */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={isDetailsInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 }}
              whileHover={{ y: -8 }}
              className="bg-gradient-to-br from-[#F8FBFF] to-[#EEF5FF] rounded-2xl p-8 border border-gray-200 shadow-md hover:shadow-xl transition-all"
            >
              <div className="size-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl flex items-center justify-center mb-5 shadow-lg">
                <Mail className="size-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#0A0A0A] mb-3">
                Email Addresses
              </h3>
              <div className="space-y-2 text-base text-[#475569]">
                <p>
                  <strong className="text-[#0A0A0A]">General:</strong><br />
                  <a href="mailto:info@tnautoskills.org" className="text-[#0066FF] hover:underline">
                    info@tnautoskills.org
                  </a>
                </p>
                <p>
                  <strong className="text-[#0A0A0A]">Admissions:</strong><br />
                  <a href="mailto:admissions@tnautoskills.org" className="text-[#0066FF] hover:underline">
                    admissions@tnautoskills.org
                  </a>
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section ref={formRef} className="pt-20 pb-14 bg-[#F3F6F9]">
        <div className="max-w-[1440px] mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Left: Form Info */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={isFormInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
            >
              <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mb-6" />
              <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-6">
                Send Us a Message
              </h2>
              <p className="text-lg text-[#475569] leading-relaxed mb-8">
                Have questions about our programs, admissions, or partnerships? Fill out the form and our team will get back to you within 24 hours.
              </p>

              {/* Quick Info */}
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="size-12 bg-[#0066FF]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Clock className="size-6 text-[#0066FF]" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#0A0A0A] mb-1">Office Hours</h4>
                    <p className="text-sm text-[#475569]">Monday - Friday: 9:00 AM - 6:00 PM<br />Saturday: 9:00 AM - 1:00 PM</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="size-12 bg-[#0066FF]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Headphones className="size-6 text-[#0066FF]" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#0A0A0A] mb-1">Quick Response</h4>
                    <p className="text-sm text-[#475569]">We typically respond within 24 hours on business days</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Right: Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={isFormInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-8 lg:p-10 shadow-xl border border-gray-100">
                {/* Success Message */}
                {formStatus === "success" && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl flex items-start gap-3"
                  >
                    <CheckCircle2 className="size-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-green-900 text-sm">Message Sent Successfully!</p>
                      <p className="text-xs text-green-700">We'll get back to you within 24 hours.</p>
                    </div>
                  </motion.div>
                )}

                {/* Error Message */}
                {formStatus === "error" && Object.keys(errors).length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3"
                  >
                    <AlertCircle className="size-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-red-900 text-sm">Please fix the errors below</p>
                    </div>
                  </motion.div>
                )}

                <div className="space-y-5">
                  {/* Full Name */}
                  <div>
                    <label htmlFor="fullName" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 bg-white border-2 rounded-xl text-sm focus:outline-none transition-colors min-h-[44px] ${
                        errors.fullName ? "border-red-500 focus:border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                      }`}
                      placeholder="Enter your full name"
                    />
                    {errors.fullName && (
                      <p className="mt-1 text-xs text-red-600">{errors.fullName}</p>
                    )}
                  </div>

                  {/* Email */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 bg-white border-2 rounded-xl text-sm focus:outline-none transition-colors min-h-[44px] ${
                        errors.email ? "border-red-500 focus:border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                      }`}
                      placeholder="your.email@example.com"
                    />
                    {errors.email && (
                      <p className="mt-1 text-xs text-red-600">{errors.email}</p>
                    )}
                  </div>

                  {/* Mobile Number */}
                  <div>
                    <label htmlFor="mobile" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                      Mobile Number
                    </label>
                    <input
                      type="tel"
                      id="mobile"
                      name="mobile"
                      value={formData.mobile}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-white border-2 border-gray-200 rounded-xl text-sm focus:outline-none focus:border-[#0066FF] transition-colors min-h-[44px]"
                      placeholder="+91 XXXXX XXXXX"
                    />
                  </div>

                  {/* Category Dropdown */}
                  <div>
                    <label htmlFor="category" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                      Select Category
                    </label>
                    <select
                      id="category"
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-white border-2 border-gray-200 rounded-xl text-sm focus:outline-none focus:border-[#0066FF] transition-colors min-h-[44px]"
                    >
                      {categories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Message */}
                  <div>
                    <label htmlFor="message" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                      Message <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={5}
                      className={`w-full px-4 py-3 bg-white border-2 rounded-xl text-sm focus:outline-none transition-colors resize-none ${
                        errors.message ? "border-red-500 focus:border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                      }`}
                      placeholder="Tell us more about your inquiry..."
                    />
                    {errors.message && (
                      <p className="mt-1 text-xs text-red-600">{errors.message}</p>
                    )}
                  </div>

                  {/* Submit Button */}
                  <motion.button
                    type="submit"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full px-8 py-4 bg-[#0066FF] text-white rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl hover:bg-[#0090FF] transition-all min-h-[44px] flex items-center justify-center gap-2"
                  >
                    <Send className="size-5" />
                    <span>Send Message</span>
                  </motion.button>
                </div>
              </form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Google Map Section */}
      <section ref={mapRef} className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isMapInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-6" />
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
              Visit Our Centre
            </h2>
            <p className="text-lg text-[#475569] max-w-3xl mx-auto">
              Find us on the map and plan your visit to TN AutoSkills
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isMapInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-[#0066FF]"
          >
            {/* Map Container */}
            <div className="relative w-full h-[400px] lg:h-[500px] bg-gradient-to-br from-[#EEF5FF] to-[#F8FBFF]">
              {/* Placeholder for Google Maps - Replace with actual Google Maps embed */}
              <iframe
                title="TN AutoSkills Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d248849.886539092!2d80.04419969999999!3d13.047984!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5265ea4f7d3361%3A0x6e61a70b6863d433!2sChennai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full"
              />
              
              {/* Overlay with directions link */}
              <div className="absolute bottom-6 left-6 right-6 flex justify-center">
                <motion.a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-3 bg-white text-[#0066FF] rounded-2xl font-semibold text-sm shadow-xl hover:shadow-2xl transition-all inline-flex items-center gap-2 border-2 border-[#0066FF]"
                >
                  <MapPin className="size-5" />
                  <span>Get Directions</span>
                </motion.a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Support & Helpline Section */}
      <section ref={helplineRef} className="pt-20 pb-14 bg-[#F3F6F9]">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isHelplineInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-3xl p-12 lg:p-16 text-center shadow-xl relative overflow-hidden"
          >
            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full -ml-32 -mb-32" />
            
            <div className="relative z-10">
              <div className="size-20 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Headphones className="size-10 text-white" />
              </div>
              
              <h2 className="text-4xl lg:text-5xl font-extrabold text-white mb-4">
                Need Immediate Assistance?
              </h2>
              
              <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8">
                Our support team is available to help you with any questions or concerns
              </p>

              {/* Helpline Info */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 max-w-2xl mx-auto mb-8 border border-white/20">
                <p className="text-sm text-white/80 mb-2">24/7 Support Helpline</p>
                <p className="text-3xl font-extrabold text-white mb-1">+91 XXXXX XXXXX</p>
                <p className="text-sm text-white/70">Available Monday - Sunday, All Day</p>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white text-[#0066FF] rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl transition-all min-h-[44px] flex items-center gap-2"
                >
                  <HelpCircle className="size-5" />
                  <span>View FAQs</span>
                </motion.button>

                <motion.a
                  href="tel:+91XXXXXXXXXX"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white/20 backdrop-blur-md border-2 border-white text-white rounded-2xl font-semibold text-base hover:bg-white hover:text-[#0066FF] transition-all shadow-lg min-h-[44px] flex items-center gap-2"
                >
                  <Phone className="size-5" />
                  <span>Call Now</span>
                </motion.a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
