import { motion, useScroll, useTransform, useInView } from "motion/react";
import { useRef, useState } from "react";
import { 
  ArrowRight, 
  Download, 
  Clock, 
  Award, 
  Battery, 
  Wrench, 
  Car, 
  Users,
  Shield,
  Lightbulb,
  Wifi,
  Cpu,
  Bot,
  Package,
  DollarSign,
  ChevronDown,
  CheckCircle2,
  GraduationCap
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { UnifiedBanner } from "./UnifiedBanner";

// Program data with categories
const programs = [
  {
    id: 1,
    title: "Battery Electric Vehicle Training",
    description: "Comprehensive training on EV technology, battery systems, and charging infrastructure",
    duration: "3 Months",
    level: "Advanced",
    category: "EV Technology",
    icon: Battery,
  },
  {
    id: 2,
    title: "Battery Management – EV",
    description: "Specialized course on battery management systems, diagnostics, and maintenance",
    duration: "2 Months",
    level: "Intermediate",
    category: "EV Technology",
    icon: Battery,
  },
  {
    id: 3,
    title: "CNC Operating",
    description: "Master CNC machine operation, programming, and precision manufacturing",
    duration: "2 Months",
    level: "Intermediate",
    category: "Manufacturing & Assembly",
    icon: Package,
  },
  {
    id: 4,
    title: "Automotive Service Technician",
    description: "Complete automotive diagnostics, repair, and maintenance training",
    duration: "6 Months",
    level: "Intermediate",
    category: "Automotive Diagnostics",
    icon: Wrench,
  },
  {
    id: 5,
    title: "Automotive Sales Consultant",
    description: "Sales strategies, customer relationship management, and automotive business",
    duration: "1 Month",
    level: "Beginner",
    category: "Management & Sales",
    icon: Users,
  },
  {
    id: 6,
    title: "LMV / HMV Driving",
    description: "Professional driving training for Light and Heavy Motor Vehicles",
    duration: "2 Weeks",
    level: "Beginner",
    category: "Core Skills",
    icon: Car,
  },
  {
    id: 7,
    title: "3-Wheeler Upskilling",
    description: "Specialized training for 3-wheeler mechanics and maintenance",
    duration: "1 Month",
    level: "Beginner",
    category: "Core Skills",
    icon: Car,
  },
  {
    id: 8,
    title: "Safety & Hazard Training",
    description: "Workplace safety, hazard identification, and emergency response protocols",
    duration: "2 Weeks",
    level: "Beginner",
    category: "Safety & Compliance",
    icon: Shield,
  },
  {
    id: 9,
    title: "Innovation & Core Skills",
    description: "Problem-solving, critical thinking, and innovation methodologies",
    duration: "1 Month",
    level: "Beginner",
    category: "Core Skills",
    icon: Lightbulb,
  },
  {
    id: 10,
    title: "IoT in Automotive",
    description: "Internet of Things applications, connected vehicles, and smart mobility",
    duration: "2 Months",
    level: "Advanced",
    category: "AI / IoT / Robotics",
    icon: Wifi,
  },
  {
    id: 11,
    title: "AI in Automotive",
    description: "Artificial Intelligence for autonomous vehicles and predictive maintenance",
    duration: "3 Months",
    level: "Advanced",
    category: "AI / IoT / Robotics",
    icon: Cpu,
  },
  {
    id: 12,
    title: "Robotics & Cobotics",
    description: "Industrial robotics, collaborative robots, and automation systems",
    duration: "3 Months",
    level: "Advanced",
    category: "AI / IoT / Robotics",
    icon: Bot,
  },
  {
    id: 13,
    title: "Assembly Operator",
    description: "Production line assembly, quality control, and manufacturing processes",
    duration: "1 Month",
    level: "Beginner",
    category: "Manufacturing & Assembly",
    icon: Package,
  },
  {
    id: 14,
    title: "Financial Literacy",
    description: "Financial planning, budgeting, and money management for professionals",
    duration: "2 Weeks",
    level: "Beginner",
    category: "Management & Sales",
    icon: DollarSign,
  },
];

const categories = [
  "All",
  "EV Technology",
  "Automotive Diagnostics",
  "Manufacturing & Assembly",
  "Core Skills",
  "Safety & Compliance",
  "AI / IoT / Robotics",
  "Management & Sales",
];

const levelColors = {
  Beginner: "bg-green-500",
  Intermediate: "bg-yellow-500",
  Advanced: "bg-red-500",
};

export function Programs() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [expandedProgram, setExpandedProgram] = useState<number | null>(null);
  const detailsRef = useRef(null);
  const isDetailsInView = useInView(detailsRef, { once: true, margin: "-100px" });

  // Filter programs
  const filteredPrograms = activeCategory === "All" 
    ? programs 
    : programs.filter(p => p.category === activeCategory);

  return (
    <div className="bg-white">
      {/* Unified Banner */}
      <UnifiedBanner
        title="Programs & Skill Development Courses"
        subtitle="Explore industry-aligned automotive training programs for students, professionals, and institutions"
        badge={
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/90 backdrop-blur-md rounded-2xl shadow-lg border border-gray-100">
            <GraduationCap className="size-8 text-[#0066FF]" />
            <div className="text-left">
              <div className="text-sm font-bold text-[#0A0A0A]">14 Programs Available</div>
              <div className="text-xs text-[#64748b]">All Levels</div>
            </div>
          </div>
        }
      />

      {/* Sticky Filter Bar */}
      <div className="sticky top-[68px] z-40 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-[1440px] mx-auto px-8 py-4">
          <div className="flex gap-3 overflow-x-auto scrollbar-hide">
            {categories.map((category) => (
              <motion.button
                key={category}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-2.5 rounded-xl font-semibold text-sm whitespace-nowrap transition-all min-h-[44px] ${
                  activeCategory === category
                    ? "bg-[#0066FF] text-white shadow-lg"
                    : "bg-gray-100 text-[#475569] hover:bg-gray-200"
                }`}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Program Grid Section */}
      <section className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
              {activeCategory === "All" ? "All Programs" : activeCategory}
            </h2>
            <p className="text-lg text-[#475569]">
              {filteredPrograms.length} program{filteredPrograms.length !== 1 ? "s" : ""} available
            </p>
          </motion.div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPrograms.map((program, index) => (
              <motion.div
                key={program.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ scale: 1.03, y: -8 }}
                className="bg-white rounded-2xl border border-gray-200 shadow-lg hover:shadow-2xl transition-all overflow-hidden group"
              >
                {/* Icon Header */}
                <div className="relative h-48 bg-gradient-to-br from-[#EEF5FF] to-[#E3F2FD] flex items-center justify-center overflow-hidden">
                  <motion.div
                    whileHover={{ scale: 1.2, rotate: 5 }}
                    transition={{ duration: 0.3 }}
                    className="size-24 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-3xl flex items-center justify-center shadow-xl"
                  >
                    <program.icon className="size-12 text-white" />
                  </motion.div>
                  
                  {/* Level Badge */}
                  <div className="absolute top-4 right-4 flex items-center gap-2 bg-white/95 backdrop-blur-md rounded-full px-3 py-1.5 shadow-md">
                    <div className={`size-2 rounded-full ${levelColors[program.level as keyof typeof levelColors]}`} />
                    <span className="text-xs font-bold text-[#0A0A0A]">{program.level}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <h3 className="text-xl font-bold text-[#0A0A0A] group-hover:text-[#0066FF] transition-colors">
                    {program.title}
                  </h3>
                  
                  <p className="text-sm text-[#475569] leading-relaxed line-clamp-2">
                    {program.description}
                  </p>

                  {/* Duration */}
                  <div className="flex items-center gap-2 text-sm text-[#64748b]">
                    <Clock className="size-4 text-[#0066FF]" />
                    <span className="font-medium">{program.duration}</span>
                  </div>

                  {/* View Details Button */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full px-6 py-3 bg-[#0066FF] text-white rounded-xl font-semibold text-sm hover:bg-[#0090FF] transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 min-h-[44px]"
                  >
                    <span>View Details</span>
                    <ArrowRight className="size-4" />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Program Details Preview Section */}
      <section ref={detailsRef} className="pt-20 pb-14 bg-[#F3F6F9]">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isDetailsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-8" />
            <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
              Sample Program Details
            </h2>
            <p className="text-lg xl:text-xl text-[#475569] max-w-3xl mx-auto">
              See what's included in our comprehensive training programs
            </p>
          </motion.div>

          {/* Expandable Card */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isDetailsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-br from-[#0066FF] to-[#0090FF] p-8 text-white">
              <div className="flex items-start gap-4">
                <div className="size-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Battery className="size-8 text-white" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold mb-2">Battery Electric Vehicle Training</h3>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="size-4" />
                      <span>3 Months</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Award className="size-4" />
                      <span>Advanced Level</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Expandable Sections */}
            <div className="divide-y divide-gray-200">
              {[
                {
                  title: "Overview",
                  content: "Comprehensive training covering all aspects of Battery Electric Vehicle technology, including battery systems, power electronics, charging infrastructure, and vehicle diagnostics. Gain hands-on experience with industry-standard tools and equipment."
                },
                {
                  title: "Curriculum Highlights",
                  content: "• EV Architecture & Components\n• Battery Technology & Management Systems\n• Electric Motors & Power Electronics\n• Charging Infrastructure\n• Vehicle Diagnostics & Troubleshooting\n• Safety Protocols & Standards\n• Practical Lab Sessions\n• Industry Projects"
                },
                {
                  title: "Who Can Apply?",
                  content: "This program is ideal for automotive technicians, engineers, fresh graduates, and professionals looking to upskill in electric vehicle technology. Basic understanding of automotive systems and electrical concepts is recommended."
                },
                {
                  title: "Certification Details",
                  content: "Upon successful completion, participants receive an industry-recognized certificate from TN AutoSkills, endorsed by leading automotive manufacturers. The certification is valid globally and enhances career prospects in the EV sector."
                },
                {
                  title: "Job Outcomes",
                  content: "Graduates can pursue careers as EV Technicians, Battery Specialists, Charging Infrastructure Engineers, EV Service Advisors, or Quality Control Engineers at leading automotive companies like Hyundai, Tata Motors, Mahindra, Ola Electric, and more."
                }
              ].map((section, index) => (
                <div key={index}>
                  <button
                    onClick={() => setExpandedProgram(expandedProgram === index ? null : index)}
                    className="w-full p-6 flex items-center justify-between hover:bg-gray-50 transition-colors text-left min-h-[64px]"
                  >
                    <span className="text-lg font-bold text-[#0A0A0A]">{section.title}</span>
                    <motion.div
                      animate={{ rotate: expandedProgram === index ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <ChevronDown className="size-6 text-[#0066FF]" />
                    </motion.div>
                  </button>
                  
                  <motion.div
                    initial={false}
                    animate={{
                      height: expandedProgram === index ? "auto" : 0,
                      opacity: expandedProgram === index ? 1 : 0
                    }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6 text-[#475569] leading-relaxed whitespace-pre-line">
                      {section.content}
                    </div>
                  </motion.div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="pt-20 pb-14 bg-gradient-to-br from-[#0066FF] to-[#0090FF] relative overflow-hidden">
        {/* Decorative Elements */}
        <motion.div
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          className="absolute top-10 right-10 w-64 h-64 border-4 border-white/10 rounded-full"
        />
        <motion.div
          animate={{ rotate: [0, -360] }}
          transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-10 left-10 w-80 h-80 border-4 border-white/10 rounded-3xl"
        />

        <div className="relative z-10 max-w-[1440px] mx-auto px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl lg:text-6xl font-extrabold text-white mb-6">
              Ready to Upskill?
            </h2>
            
            <p className="text-xl lg:text-2xl text-white/90 max-w-3xl mx-auto mb-12">
              Enroll today and take your career to the next level with industry-recognized certification
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white text-[#0066FF] rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl transition-all min-h-[44px] flex items-center gap-2"
              >
                <span>Enroll Now</span>
                <ArrowRight className="size-5" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-transparent border-2 border-white text-white rounded-2xl font-semibold text-base hover:bg-white hover:text-[#0066FF] transition-all shadow-lg min-h-[44px] flex items-center gap-2"
              >
                <Users className="size-5" />
                <span>Talk to Us</span>
              </motion.button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mt-16 max-w-4xl mx-auto">
              {[
                { icon: Users, value: "2,242+", label: "Candidates Trained" },
                { icon: Award, value: "95%", label: "Placement Rate" },
                { icon: CheckCircle2, value: "213", label: "Industry Partners" }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <stat.icon className="size-12 text-white mx-auto mb-3" />
                  <div className="text-4xl font-extrabold text-white mb-2">{stat.value}</div>
                  <div className="text-white/80">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}