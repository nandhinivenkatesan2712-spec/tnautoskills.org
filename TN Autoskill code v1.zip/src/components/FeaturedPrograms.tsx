import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Clock, Award } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { CTAButton } from "./CTAButton";

const programs = [
  {
    title: "Electric Vehicle Technology",
    duration: "6 Months",
    level: "Advanced",
    image: "https://images.unsplash.com/photo-1760538978585-f82dc257ec15?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpYyUyMHZlaGljbGUlMjBjaGFyZ2luZyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYzNjE4NzYxfDA&ixlib=rb-4.1.0&q=80&w=1080",
    color: "green",
  },
  {
    title: "Automotive Robotics & Automation",
    duration: "4 Months",
    level: "Intermediate",
    image: "https://images.unsplash.com/photo-1761195696590-3490ea770aa1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb2JvdGljcyUyMGF1dG9tYXRpb24lMjBmYWN0b3J5fGVufDF8fHx8MTc2MzYxODc2MXww&ixlib=rb-4.1.0&q=80&w=1080",
    color: "purple",
  },
  {
    title: "Vehicle Dynamics Simulation",
    duration: "3 Months",
    level: "Advanced",
    image: "https://images.unsplash.com/photo-1695427845003-e2b007b6d78d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvbW90aXZlJTIwc2ltdWxhdGlvbiUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYzNjE4NzYyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    color: "blue",
  },
  {
    title: "Advanced Diagnostics",
    duration: "5 Months",
    level: "Intermediate",
    image: "https://images.unsplash.com/photo-1702146713870-8cdd7ab983fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBkaWFnbm9zdGljcyUyMG1lY2hhbmljJTIwd29ya3Nob3B8ZW58MXx8fHwxNzYzNjE4NzYyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    color: "orange",
  },
];

const levelColors = {
  Advanced: "bg-red-500",
  Intermediate: "bg-yellow-500",
  Beginner: "bg-green-500",
};

export function FeaturedPrograms() {
  const ref = useRef(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 400;
      const newScrollLeft =
        scrollRef.current.scrollLeft +
        (direction === "left" ? -scrollAmount : scrollAmount);
      scrollRef.current.scrollTo({
        left: newScrollLeft,
        behavior: "smooth",
      });

      // Update button states
      setTimeout(() => {
        if (scrollRef.current) {
          setCanScrollLeft(scrollRef.current.scrollLeft > 0);
          setCanScrollRight(
            scrollRef.current.scrollLeft <
              scrollRef.current.scrollWidth - scrollRef.current.clientWidth - 10
          );
        }
      }, 300);
    }
  };

  return (
    <section ref={ref} className="pt-20 pb-14 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-[1440px] mx-auto px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="w-24 h-1 bg-gradient-to-r from-[#004ABB] to-[#0055DD] rounded-full mx-auto mb-8" />
          <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
            Featured Training Programs
          </h2>
          <p className="text-lg xl:text-xl text-[#475569] max-w-3xl mx-auto">
            Industry-leading programs designed for tomorrow's automotive professionals
          </p>
        </motion.div>

        {/* Scrollable Programs */}
        <div
          ref={scrollRef}
          className="flex gap-6 overflow-x-auto scrollbar-hide scroll-smooth pb-4"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {programs.map((program, index) => (
            <motion.div
              key={program.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="flex-shrink-0 w-[340px] bg-white rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 group"
            >
              {/* Image */}
              <div className="relative h-56 overflow-hidden">
                <ImageWithFallback
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                
                {/* Level Badge */}
                <div className="absolute top-4 right-4">
                  <div className="flex items-center gap-2 bg-white/95 backdrop-blur-sm rounded-full px-4 py-2 shadow-lg">
                    <div className={`size-2 rounded-full ${levelColors[program.level as keyof typeof levelColors]}`} />
                    <span className="text-sm font-semibold text-[#0b1220]">
                      {program.level}
                    </span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                <h3 className="text-[#0b1220] text-xl font-bold leading-tight group-hover:text-[#004ABB] transition-colors">
                  {program.title}
                </h3>

                {/* Duration */}
                <div className="flex items-center gap-2 text-[#64748b]">
                  <Clock className="size-4" />
                  <span className="text-sm font-medium">{program.duration}</span>
                </div>

                {/* Button */}
                <CTAButton variant="primary" size="md" className="w-full">
                  View Details
                </CTAButton>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}