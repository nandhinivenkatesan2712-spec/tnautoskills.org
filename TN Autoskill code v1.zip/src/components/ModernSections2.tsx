import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Shield,
  CheckCircle,
  Users,
  Award,
  Briefcase,
  Building2,
  Target,
  TrendingUp,
  Quote,
  ChevronRight,
  Heart,
  GraduationCap,
  ArrowRight,
  UserPlus,
  Cog,
  ShoppingCart,
  Lightbulb,
  BookOpen,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// 8. ZERO FATALITIES 2030
export function ModernZeroFatalities() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const initiatives = [
    { icon: Shield, title: "Advanced Safety Systems", description: "Training on vehicle safety technologies" },
    { icon: Target, title: "Driver Education", description: "Behavior and road safety programs" },
    { icon: Award, title: "Emergency Response", description: "First aid and crisis management" },
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-br from-[#1E293B] to-[#0F172A] text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-[45%_55%] gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <div className="inline-block px-4 py-1.5 bg-white/10 backdrop-blur-sm rounded-full text-xs font-semibold uppercase tracking-wide">
              Road Safety Initiative
            </div>

            <h2 className="text-3xl lg:text-5xl font-extrabold">
              Zero Fatalities by 2030
            </h2>

            <p className="text-base text-white/80 leading-relaxed">
              We are committed to achieving the UN's Sustainable Development Goal of reducing road traffic deaths and injuries through comprehensive safety training and awareness programs.
            </p>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                <div className="text-3xl font-extrabold mb-1">50%</div>
                <div className="text-xs text-white/70">Target Reduction</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                <div className="text-3xl font-extrabold mb-1">2030</div>
                <div className="text-xs text-white/70">Achievement Year</div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-4"
          >
            {initiatives.map((item, idx) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + idx * 0.1 }}
                  className="bg-white/10 backdrop-blur-sm rounded-xl p-5 border border-white/20 hover:bg-white/20 transition-all"
                >
                  <div className="flex items-start gap-4">
                    <div className="size-12 bg-white/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon className="size-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">{item.title}</h3>
                      <p className="text-sm text-white/70">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })}

            <a
              href="#safety"
              className="inline-flex items-center gap-2 text-white font-semibold text-sm hover:gap-3 transition-all"
            >
              <span>Learn More</span>
              <ChevronRight className="size-4" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// 9. MILESTONES / STATS
export function ModernMilestones() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const stats = [
    { icon: Users, value: "2500+", label: "Students Trained" },
    { icon: Award, value: "500+", label: "Certified Professionals" },
    { icon: Briefcase, value: "200+", label: "Placements" },
    { icon: Building2, value: "40+", label: "Industry Partners" },
    { icon: Target, value: "95%", label: "Success Rate" },
    { icon: TrendingUp, value: "10+", label: "Training Centers" },
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 text-white"
        >
          <h2 className="text-3xl lg:text-4xl font-extrabold mb-2">Our Milestones</h2>
          <p className="text-sm text-white/80">Transforming automotive education across Tamil Nadu</p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="bg-white/15 backdrop-blur-md rounded-xl p-5 border border-white/20 text-center text-white hover:bg-white/25 transition-all"
              >
                <div className="inline-flex items-center justify-center size-11 bg-white/20 rounded-lg mb-3">
                  <Icon className="size-5 text-white" />
                </div>
                <div className="text-3xl font-extrabold mb-1">{stat.value}</div>
                <div className="text-xs text-white/80 font-medium">{stat.label}</div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 10. SUCCESS STORIES
export function ModernSuccessStories() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const stories = [
    {
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
      name: "Rajesh Kumar",
      role: "EV Technician",
      company: "Ather Energy",
      quote: "The hands-on training I received helped me secure my dream job in the EV industry.",
    },
    {
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop",
      name: "Priya Sharma",
      role: "Automotive Engineer",
      company: "Hyundai",
      quote: "TN Auto Skills provided me with industry-relevant skills and direct placement support.",
    },
    {
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop",
      name: "Arjun Patel",
      role: "Service Manager",
      company: "TVS Motors",
      quote: "The certification program opened doors to leadership roles in the automotive sector.",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-[#0066FF]/8 rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4">
            Testimonials
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A]">Success Stories</h2>
        </motion.div>

        <div className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide">
          {stories.map((story, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="min-w-[320px] lg:min-w-[360px] bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all border border-gray-100 snap-start"
            >
              <Quote className="size-10 text-[#0066FF]/20 mb-4" />
              <p className="text-sm text-[#475569] italic mb-6 leading-relaxed">"{story.quote}"</p>
              <div className="flex items-center gap-4">
                <div className="size-14 rounded-full overflow-hidden border-2 border-[#0066FF]/20">
                  <ImageWithFallback
                    src={story.image}
                    alt={story.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="font-bold text-[#0A0A0A]">{story.name}</div>
                  <div className="text-sm text-[#64748B]">{story.role}</div>
                  <div className="text-xs text-[#0066FF] font-semibold">{story.company}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// 11. PARTNERS
export function ModernPartners() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const partners = [
    "Hyundai", "Maruti Suzuki", "Tata Motors", "TVS Motors",
    "Ashok Leyland", "Royal Enfield", "Ather Energy", "Ola Electric"
  ];

  return (
    <section ref={ref} className="py-16 bg-[#F8FAFB]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-white rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4 shadow-sm">
            Partnerships
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A]">Our Partners</h2>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {partners.map((partner, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: idx * 0.05 }}
              whileHover={{ y: -4 }}
              className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all border border-gray-100 flex items-center justify-center"
            >
              <div className="text-center">
                <Building2 className="size-10 text-[#0066FF]/30 mx-auto mb-2" />
                <div className="font-bold text-[#0A0A0A] text-sm">{partner}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// 12. EMPANELMENT
export function ModernEmpanelment() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const categories = [
    {
      icon: Building2,
      title: "OEMs (Original Equipment Manufacturers)",
      points: [
        "Partner for workforce development programs",
        "Co-create specialized training modules",
        "Access to skilled talent pool",
      ],
    },
    {
      icon: Cog,
      title: "Automotive Suppliers & Component Manufacturers",
      points: [
        "Collaborate on technical skill training",
        "Supplier-specific competency development",
        "Quality assurance training",
      ],
    },
    {
      icon: ShoppingCart,
      title: "Retail & Service Networks",
      points: [
        "Service technician training programs",
        "Customer service excellence modules",
        "After-sales support training",
      ],
    },
    {
      icon: Lightbulb,
      title: "Automotive Startups & Innovation Hubs",
      points: [
        "EV and new mobility solutions training",
        "Technology integration programs",
        "Innovation and R&D collaboration",
      ],
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-[#0066FF]/8 rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4">
            Industry Partners
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Empanelment Opportunities
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            Join our network of industry partners to build a skilled automotive workforce
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 mb-10">
          {categories.map((category, idx) => {
            const Icon = category.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="size-12 bg-[#0066FF] rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon className="size-6 text-white" />
                  </div>
                  <h3 className="font-bold text-[#0A0A0A] text-base leading-tight pt-2">{category.title}</h3>
                </div>
                <ul className="space-y-2">
                  {category.points.map((point, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-[#64748B]">
                      <CheckCircle className="size-4 text-[#0066FF] flex-shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#empanelment"
            className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#0066FF] text-white rounded-lg font-semibold text-sm shadow-md hover:shadow-lg hover:bg-[#0055DD] transition-all"
          >
            <span>Apply for Empanelment</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 13. HR REGISTRATION
export function ModernHRRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section ref={ref} className="py-16 bg-[#F8FAFB]">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="bg-white rounded-2xl p-8 lg:p-10 shadow-lg border border-gray-100"
        >
          <div className="grid lg:grid-cols-[60%_40%] gap-8 items-center">
            <div className="space-y-4">
              <div className="inline-block px-4 py-1.5 bg-[#0066FF]/8 rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide">
                Recruitment
              </div>
              <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A]">
                HR Registration for Recruitment
              </h2>
              <p className="text-base text-[#475569] leading-relaxed">
                Register your organization to access our pool of trained and certified automotive professionals.
              </p>
              <ul className="space-y-2">
                {[
                  "Access to 2500+ trained candidates",
                  "Industry-certified professionals",
                  "Streamlined recruitment process",
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-[#475569]">
                    <CheckCircle className="size-4 text-[#0066FF]" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex flex-col gap-3">
              <a
                href="#hr-register"
                className="px-6 py-4 bg-[#0066FF] text-white rounded-lg font-semibold text-sm shadow-md hover:shadow-lg hover:bg-[#0055DD] transition-all text-center"
              >
                Register Now
              </a>
              <a
                href="#contact"
                className="px-6 py-4 bg-transparent text-[#0066FF] border-2 border-[#0066FF] rounded-lg font-semibold text-sm hover:bg-[#0066FF]/5 transition-all text-center"
              >
                Contact Us
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// 14. CSR PROJECTS
export function ModernCSRProjects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const projects = [
    {
      icon: Heart,
      title: "Community Skill Development",
      description: "Partner with us to provide free automotive training to underprivileged youth and create employment opportunities in rural Tamil Nadu.",
      impact: "500+ beneficiaries trained",
    },
    {
      icon: GraduationCap,
      title: "Women in Automotive Initiative",
      description: "Support our program to train and empower women in automotive technology, breaking gender barriers in the industry.",
      impact: "200+ women professionals",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-[#0066FF]/8 rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4">
            Social Impact
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">CSR Projects</h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            Collaborate with us on Corporate Social Responsibility initiatives to create lasting social impact
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6 mb-10">
          {projects.map((project, idx) => {
            const Icon = project.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-8 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                <div className="size-14 bg-[#0066FF] rounded-xl flex items-center justify-center mb-4">
                  <Icon className="size-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#0A0A0A] mb-3">{project.title}</h3>
                <p className="text-sm text-[#475569] leading-relaxed mb-4">{project.description}</p>
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/10 rounded-lg">
                  <Users className="size-4 text-[#0066FF]" />
                  <span className="text-xs font-bold text-[#0066FF]">{project.impact}</span>
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center"
        >
          <a
            href="#csr-register"
            className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#0066FF] text-white rounded-lg font-semibold text-sm shadow-md hover:shadow-lg hover:bg-[#0055DD] transition-all"
          >
            <span>CSR Partnership Registration</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 15. ACADEMIA & ALUMNI
export function ModernAcademiaAlumni() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section ref={ref} className="py-16 bg-[#F8FAFB]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-white rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4 shadow-sm">
            Education Network
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Academia & Alumni Support
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            We collaborate with engineering colleges, polytechnics, and ITIs to bridge the gap between academic learning and industry requirements
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6 mb-10">
          {[
            {
              icon: BookOpen,
              title: "Academia Support",
              points: [
                "Curriculum co-development and faculty training",
                "Student placement and industry connections",
                "Research collaboration and innovation",
              ],
            },
            {
              icon: Users,
              title: "Alumni Support",
              points: [
                "Continuous upskilling programs",
                "Career advancement support",
                "Networking and mentorship opportunities",
              ],
            },
          ].map((card, idx) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-white rounded-xl p-8 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                <div className="size-14 bg-[#0066FF] rounded-xl flex items-center justify-center mb-4">
                  <Icon className="size-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#0A0A0A] mb-4">{card.title}</h3>
                <ul className="space-y-2">
                  {card.points.map((point, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-[#475569]">
                      <CheckCircle className="size-4 text-[#0066FF] flex-shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center"
        >
          <a
            href="#academia"
            className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#0066FF] text-white rounded-lg font-semibold text-sm shadow-md hover:shadow-lg hover:bg-[#0055DD] transition-all"
          >
            <span>Partner With Us</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 16. PLACEMENT REGISTRATION
export function ModernPlacementRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section ref={ref} className="py-16 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl p-8 lg:p-10 text-center text-white shadow-xl"
        >
          <div className="inline-block px-4 py-1.5 bg-white/20 backdrop-blur-sm rounded-full text-xs font-semibold uppercase tracking-wide mb-6">
            For Colleges
          </div>

          <h2 className="text-3xl lg:text-4xl font-extrabold mb-4">
            College Placement Registration
          </h2>

          <p className="text-base text-white/90 leading-relaxed mb-6 max-w-2xl mx-auto">
            Register your college to enable your students to access placement opportunities with leading automotive companies through TN Auto Skills.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-6 text-sm">
            {["Free Registration", "Direct Industry Connections", "100% Placement Support"].map((item, i) => (
              <div key={i} className="flex items-center gap-2 text-white/90">
                <CheckCircle className="size-4" />
                <span>{item}</span>
              </div>
            ))}
          </div>

          <a
            href="#placement-register"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-[#0066FF] rounded-lg font-bold shadow-lg hover:shadow-xl hover:bg-blue-50 transition-all"
          >
            <span>College Registration</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
