import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight, Quote, Star } from "lucide-react";

const stories = [
  {
    name: "Rajesh Kumar",
    role: "EV Technician",
    company: "Tata Motors",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    quote:
      "TN AutoSkills transformed my career. The hands-on EV training helped me secure a position at Tata Motors within 2 months of completion.",
    rating: 5,
  },
  {
    name: "Priya Selvam",
    role: "Service Advisor",
    company: "Hyundai",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
    quote:
      "The automotive sales training gave me confidence and skills. I'm now thriving as a Service Advisor at Hyundai with excellent career growth.",
    rating: 5,
  },
  {
    name: "Karthik Murugan",
    role: "CNC Operator",
    company: "Ashok Leyland",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop",
    quote:
      "The CNC training program was exceptional. I learned modern manufacturing techniques and got placed at Ashok Leyland immediately.",
    rating: 5,
  },
];

export function SuccessStoriesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
            <Star className="size-4 text-[#0066FF] fill-[#0066FF]" />
            <span className="text-sm font-semibold text-[#0066FF]">
              Alumni Stories
            </span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
            Success Stories
          </h2>

          <p className="text-lg lg:text-xl text-[#64748b] max-w-3xl mx-auto">
            Real stories from our alumni who transformed their careers through our training programs
          </p>
        </motion.div>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-12">
          {stories.map((story, index) => (
            <motion.div
              key={story.name}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -8, scale: 1.02 }}
              className="group bg-gradient-to-br from-white to-gray-50 rounded-3xl overflow-hidden border-2 border-gray-100 hover:border-[#0066FF]/30 shadow-lg hover:shadow-2xl transition-all"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden bg-gray-200">
                <img
                  src={story.image}
                  alt={story.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                
                {/* Rating */}
                <div className="absolute top-4 right-4 flex gap-1">
                  {[...Array(story.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="size-4 text-yellow-400 fill-yellow-400"
                    />
                  ))}
                </div>
              </div>

              {/* Content */}
              <div className="p-6 lg:p-8">
                {/* Quote Icon */}
                <Quote className="size-8 text-[#0066FF]/20 mb-4" />

                {/* Quote */}
                <p className="text-sm lg:text-base text-[#475569] italic mb-6 leading-relaxed">
                  "{story.quote}"
                </p>

                {/* Author */}
                <div className="border-t border-gray-200 pt-4">
                  <h3 className="font-bold text-[#0A0A0A] mb-1">
                    {story.name}
                  </h3>
                  <p className="text-sm text-[#0066FF] font-semibold">
                    {story.role}
                  </p>
                  <p className="text-sm text-[#64748b]">{story.company}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Industry Collaboration Banner */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-3xl p-8 lg:p-12 mb-12"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-3xl font-extrabold text-white mb-4">
                Industry Collaboration Stories
              </h3>
              <p className="text-white/90 text-lg leading-relaxed">
                Our partnerships with leading automotive OEMs and suppliers have created pathways for thousands of candidates to build successful careers.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {["40+ Partners", "2500+ Trained", "200+ Placed", "100% Support"].map(
                (stat, i) => (
                  <div
                    key={i}
                    className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-center border border-white/20"
                  >
                    <div className="text-2xl font-extrabold text-white mb-1">
                      {stat}
                    </div>
                  </div>
                )
              )}
            </div>
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-center"
        >
          <motion.a
            href="#success-stories"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-base shadow-xl hover:shadow-2xl transition-all"
          >
            <span>View All Success Stories</span>
            <ArrowRight className="size-5" />
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}
