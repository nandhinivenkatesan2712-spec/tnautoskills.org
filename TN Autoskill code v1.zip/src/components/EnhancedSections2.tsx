import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Zap,
  Leaf,
  Cpu,
  Layers,
  Shield,
  Target,
  CheckCircle,
  ChevronRight,
  ArrowRight,
  Users,
  Award,
  Briefcase,
  Building2,
  TrendingUp,
  Play,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// 4. FEATURED TRAINING PROGRAMS - Enhanced Visual Cards
export function EnhancedFeaturedPrograms() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const programs = [
    {
      image: "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=600&h=400&fit=crop",
      badge: "EV Technology",
      badgeColor: "from-yellow-400 to-orange-500",
      title: "Electric Vehicle Technology",
      description: "Learn EV systems, battery tech, and charging infrastructure.",
    },
    {
      image: "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=600&h=400&fit=crop",
      badge: "Core Program",
      badgeColor: "from-blue-400 to-indigo-500",
      title: "Automotive Service Technician",
      description: "Master vehicle diagnostics, repair, and maintenance.",
    },
    {
      image: "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d6?w=600&h=400&fit=crop",
      badge: "Advanced Tech",
      badgeColor: "from-purple-400 to-pink-500",
      title: "Connected Vehicle Systems",
      description: "Explore IoT, telematics, and smart vehicle technology.",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-b from-white to-[#F8FAFB] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-gray-100 mb-5">
            <Award className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Programs</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] mb-4 leading-[1.1] tracking-tight">
            Featured Training Programs
          </h2>
        </motion.div>

        {/* Programs Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-7 mb-12">
          {programs.map((program, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              whileHover={{ y: -8 }}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all border border-gray-100"
            >
              {/* Image */}
              <div className="relative h-56 overflow-hidden">
                <ImageWithFallback
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                
                {/* Badge */}
                <div className={`absolute top-4 left-4 px-4 py-2 bg-gradient-to-r ${program.badgeColor} text-white text-xs font-bold rounded-full shadow-lg`}>
                  {program.badge}
                </div>

                {/* Play Icon */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="size-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border-2 border-white/50">
                    <Play className="size-7 text-white fill-white ml-1" />
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-[#0A0A0A] mb-3 leading-tight">
                  {program.title}
                </h3>
                <p className="text-[15px] text-[#64748B] leading-relaxed mb-5">
                  {program.description}
                </p>
                <a
                  href="#programs"
                  className="inline-flex items-center gap-2 text-[#0066FF] font-semibold text-sm hover:gap-3 transition-all"
                >
                  <span>Learn More</span>
                  <ChevronRight className="size-4" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#programs"
            className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-[15px] shadow-lg hover:shadow-2xl hover:scale-105 transition-all"
          >
            <span>View All Programs</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 5. CENTRE OF EXCELLENCE - Enhanced Visual Design
export function EnhancedCentreOfExcellence() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    { 
      icon: Zap, 
      title: "EV & Hybrid Labs", 
      description: "State-of-the-art electric vehicle training facilities",
      gradient: "from-yellow-400 to-orange-500"
    },
    { 
      icon: Cpu, 
      title: "Smart Connected Vehicles", 
      description: "IoT and telematics technology workshops",
      gradient: "from-blue-400 to-indigo-500"
    },
    { 
      icon: Shield, 
      title: "BS6 Compliance", 
      description: "Latest emission standards training",
      gradient: "from-green-400 to-emerald-500"
    },
    { 
      icon: Award, 
      title: "Industry Certification", 
      description: "Government-recognized credentials",
      gradient: "from-purple-400 to-pink-500"
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-to-br from-[#0066FF]/10 to-transparent rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-[#0090FF]/10 to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#0090FF]/10 rounded-full border border-[#0066FF]/20 mb-5">
            <Building2 className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Facilities</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] mb-5 leading-[1.1] tracking-tight">
            Centre of Excellence
          </h2>

          <p className="text-lg text-[#64748B] max-w-3xl mx-auto leading-relaxed">
            State-of-the-art training facilities equipped with modern automotive technologies and industry-standard equipment
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ scale: 1.05, y: -8 }}
                className={`group relative bg-gradient-to-br ${feature.gradient} rounded-2xl p-7 shadow-xl hover:shadow-2xl transition-all text-white overflow-hidden`}
              >
                {/* Animated Background Pattern */}
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full -translate-y-1/2 translate-x-1/2" />
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full translate-y-1/2 -translate-x-1/2" />
                </div>

                <div className="relative z-10">
                  {/* Icon */}
                  <div className="size-16 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center mb-5 group-hover:scale-110 group-hover:rotate-6 transition-all">
                    <Icon className="size-8 text-white" strokeWidth={2.5} />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold mb-3 leading-tight">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-white/90 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#facilities"
            className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-[15px] shadow-lg hover:shadow-2xl hover:scale-105 transition-all"
          >
            <span>Explore Facilities</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 6. GLOBAL CURRICULUM - Enhanced Visual Grid
export function EnhancedGlobalCurriculum() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const frameworks = [
    { 
      icon: Zap, 
      title: "EV Framework", 
      description: "Electric vehicle training modules",
      gradient: "from-yellow-400 to-orange-500",
      bgGradient: "from-yellow-50 to-orange-50"
    },
    { 
      icon: Leaf, 
      title: "Green/Flexi Fuel", 
      description: "Sustainable automotive technologies",
      gradient: "from-green-400 to-emerald-500",
      bgGradient: "from-green-50 to-emerald-50"
    },
    { 
      icon: Cpu, 
      title: "SDV Framework", 
      description: "Software-defined vehicle systems",
      gradient: "from-blue-400 to-indigo-500",
      bgGradient: "from-blue-50 to-indigo-50"
    },
    { 
      icon: Layers, 
      title: "Vehicle Architecture", 
      description: "Modern automotive design principles",
      gradient: "from-purple-400 to-pink-500",
      bgGradient: "from-purple-50 to-pink-50"
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-b from-[#F8FAFB] to-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-gray-100 mb-5">
            <Layers className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Curriculum</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] mb-5 leading-[1.1] tracking-tight">
            Global Automotive Curriculum Framework
          </h2>

          <p className="text-lg text-[#64748B] max-w-3xl mx-auto leading-relaxed">
            Our training programs are based on internationally recognized automotive curriculum standards
          </p>
        </motion.div>

        {/* Frameworks Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {frameworks.map((framework, idx) => {
            const Icon = framework.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -8, scale: 1.03 }}
                className="group relative bg-white rounded-2xl p-6 shadow-md hover:shadow-2xl transition-all border-2 border-gray-100 hover:border-transparent overflow-hidden"
              >
                {/* Gradient Border on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${framework.gradient} opacity-0 group-hover:opacity-100 transition-opacity`} style={{ padding: '2px', borderRadius: '16px' }}>
                  <div className="w-full h-full bg-white rounded-2xl" />
                </div>

                {/* Background Pattern */}
                <div className={`absolute inset-0 bg-gradient-to-br ${framework.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity`} />

                <div className="relative z-10">
                  {/* Icon */}
                  <div className={`size-14 bg-gradient-to-br ${framework.gradient} rounded-xl flex items-center justify-center mb-5 shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all`}>
                    <Icon className="size-7 text-white" strokeWidth={2.5} />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-bold text-[#0A0A0A] mb-2 leading-tight">
                    {framework.title}
                  </h3>
                  <p className="text-[15px] text-[#64748B] leading-relaxed">
                    {framework.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 7. ZERO FATALITIES - Enhanced Dark Section
export function EnhancedZeroFatalities() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const initiatives = [
    { 
      icon: Shield, 
      title: "Advanced Safety Systems", 
      description: "Training on vehicle safety technologies and active/passive safety features"
    },
    { 
      icon: Target, 
      title: "Driver Education", 
      description: "Comprehensive driver behavior and road safety awareness programs"
    },
    { 
      icon: Award, 
      title: "Emergency Response", 
      description: "First aid certification and crisis management training modules"
    },
    { 
      icon: CheckCircle, 
      title: "Vehicle Inspection", 
      description: "Preventive maintenance and safety inspection standards training"
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-br from-[#0A1628] via-[#1E293B] to-[#0F172A] text-white relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#0066FF]/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-[#0090FF]/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md rounded-full border border-white/20 mb-5">
            <Shield className="size-3.5 text-white" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">Road Safety Initiative</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold mb-5 leading-[1.1] tracking-tight">
            Zero Fatalities by 2030
          </h2>

          <p className="text-lg text-white/80 max-w-3xl mx-auto leading-relaxed mb-8">
            We are committed to achieving the UN's Sustainable Development Goal of reducing road traffic deaths and injuries through comprehensive safety training and awareness programs.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-12">
            {[
              { value: "50%", label: "Target Reduction" },
              { value: "2030", label: "Achievement Year" },
              { value: "1000+", label: "Safety Trainees" },
              { value: "95%", label: "Awareness Rate" },
            ].map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: 0.2 + idx * 0.1 }}
                className="bg-white/10 backdrop-blur-md rounded-xl p-5 border border-white/20"
              >
                <div className="text-3xl lg:text-4xl font-extrabold mb-1">{stat.value}</div>
                <div className="text-xs text-white/70 font-medium uppercase tracking-wide">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Initiatives Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {initiatives.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.4 + idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20 hover:bg-white/20 hover:border-white/30 transition-all"
              >
                <div className="size-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="size-6 text-white" strokeWidth={2.5} />
                </div>
                <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-sm text-white/70 leading-relaxed">{item.description}</p>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mt-12"
        >
          <a
            href="#safety"
            className="inline-flex items-center gap-3 px-8 py-4 bg-white text-[#0066FF] rounded-xl font-bold text-[15px] shadow-2xl hover:scale-105 transition-all"
          >
            <span>Learn More About Our Safety Programs</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
