import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Zap,
  Wind,
  Cpu,
  Monitor,
  Cable,
  Handshake,
  ArrowRight,
  Image as ImageIcon,
} from "lucide-react";

export function CompactCentreOfExcellence() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    {
      icon: Zap,
      title: "EV Training Lab",
      description: "hands-on learning for battery systems, motors, EV diagnostics",
    },
    {
      icon: Wind,
      title: "BS6 Technology Lab",
      description: "engine, emission systems, and testing equipment",
    },
    {
      icon: Cpu,
      title: "Robotics & Automation Lab",
      description: "industrial robots, cobots, programming",
    },
    {
      icon: Monitor,
      title: "Simulation & VR Lab",
      description: "driver simulation and real-time vehicle training",
    },
    {
      icon: Cable,
      title: "Automotive Electrical & Electronics Lab",
      description: "wiring, diagnostics, sensors",
    },
    {
      icon: Handshake,
      title: "Industry Collaboration Zone",
      description: "OEM-led projects & internships",
    },
  ];

  return (
    <section ref={ref} className="py-20 bg-gradient-to-br from-[#F8FAFB] via-white to-[#F0F9FF] relative overflow-hidden bg-[rgba(2,9,31,0)]">
      {/* Subtle Background Accent */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-[#0066FF]/5 to-transparent rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-[45%_55%] gap-12 lg:gap-16 items-center">
          
          {/* LEFT — Compact 3D Illustration */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
            whileHover={{ scale: 1.02 }}
            className="relative"
          >
            {/* Illustration Container */}
            <div className="relative bg-white/60 backdrop-blur-sm rounded-2xl p-8 border border-gray-100 shadow-lg">
              <svg viewBox="0 0 380 340" className="w-full h-full">
                {/* Definitions */}
                <defs>
                  <linearGradient id="primary" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#0066FF" />
                    <stop offset="100%" stopColor="#0090FF" />
                  </linearGradient>
                  <linearGradient id="secondary" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#00BCD4" />
                    <stop offset="100%" stopColor="#0090FF" />
                  </linearGradient>
                  <filter id="glow">
                    <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                    <feMerge>
                      <feMergeNode in="coloredBlur"/>
                      <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                  </filter>
                </defs>

                {/* Isometric Platform Base */}
                <g opacity="0.9">
                  <motion.path
                    initial={{ opacity: 0 }}
                    animate={isInView ? { opacity: 1 } : {}}
                    transition={{ duration: 0.6, delay: 0.2 }}
                    d="M 190 280 L 280 240 L 280 180 L 190 220 Z"
                    fill="url(#primary)"
                    opacity="0.15"
                    stroke="#0066FF"
                    strokeWidth="1.5"
                  />
                  <motion.path
                    initial={{ opacity: 0 }}
                    animate={isInView ? { opacity: 1 } : {}}
                    transition={{ duration: 0.6, delay: 0.25 }}
                    d="M 190 280 L 100 240 L 100 180 L 190 220 Z"
                    fill="url(#secondary)"
                    opacity="0.15"
                    stroke="#00BCD4"
                    strokeWidth="1.5"
                  />
                  <motion.path
                    initial={{ opacity: 0 }}
                    animate={isInView ? { opacity: 1 } : {}}
                    transition={{ duration: 0.6, delay: 0.3 }}
                    d="M 190 220 L 280 180 L 190 140 L 100 180 Z"
                    fill="url(#primary)"
                    opacity="0.25"
                    stroke="#0066FF"
                    strokeWidth="2"
                  />
                </g>

                {/* EV Battery Module */}
                <motion.g
                  initial={{ opacity: 0, y: 15 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <rect x="155" y="185" width="70" height="35" rx="4" fill="#0066FF" opacity="0.6"/>
                  <rect x="160" y="190" width="60" height="25" rx="3" fill="none" stroke="#00BCD4" strokeWidth="2"/>
                  <motion.circle
                    cx="190"
                    cy="202.5"
                    r="2.5"
                    fill="#00BCD4"
                    filter="url(#glow)"
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <line x1="170" y1="197" x2="175" y2="197" stroke="#00BCD4" strokeWidth="1.5"/>
                  <line x1="170" y1="202" x2="180" y2="202" stroke="#00BCD4" strokeWidth="1.5"/>
                  <line x1="170" y1="207" x2="175" y2="207" stroke="#00BCD4" strokeWidth="1.5"/>
                </motion.g>

                {/* Robot Arm */}
                <motion.g
                  initial={{ opacity: 0, rotate: -15 }}
                  animate={isInView ? { opacity: 1, rotate: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.5 }}
                  style={{ transformOrigin: "240px 190px" }}
                >
                  <line x1="240" y1="190" x2="265" y2="160" stroke="#0066FF" strokeWidth="5" strokeLinecap="round"/>
                  <line x1="265" y1="160" x2="285" y2="135" stroke="url(#secondary)" strokeWidth="4" strokeLinecap="round"/>
                  <circle cx="240" cy="190" r="5" fill="#0066FF"/>
                  <circle cx="265" cy="160" r="5" fill="#00BCD4"/>
                  <circle cx="285" cy="135" r="6" fill="url(#primary)" filter="url(#glow)"/>
                </motion.g>

                {/* Monitor/Screen */}
                <motion.g
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.5, delay: 0.6 }}
                  style={{ transformOrigin: "140px 130px" }}
                >
                  <rect x="110" y="105" width="60" height="50" rx="4" fill="rgba(255,255,255,0.9)" stroke="#0066FF" strokeWidth="2"/>
                  <rect x="115" y="110" width="50" height="35" fill="rgba(0,102,255,0.1)"/>
                  <motion.rect
                    x="120"
                    y="115"
                    width="0"
                    height="3"
                    fill="#00BCD4"
                    animate={{ width: [0, 40, 0] }}
                    transition={{ duration: 2.5, repeat: Infinity }}
                  />
                  <rect x="120" y="122" width="35" height="2" fill="#0066FF" opacity="0.4"/>
                  <rect x="120" y="128" width="30" height="2" fill="#0066FF" opacity="0.4"/>
                  <rect x="120" y="134" width="25" height="2" fill="#0066FF" opacity="0.4"/>
                  <rect x="115" y="148" width="50" height="8" rx="1" fill="#F3F6F9"/>
                </motion.g>

                {/* VR Headset */}
                <motion.g
                  initial={{ opacity: 0, y: -10 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.7 }}
                >
                  <ellipse cx="220" cy="95" rx="22" ry="12" fill="url(#secondary)" opacity="0.3"/>
                  <rect x="206" y="87" width="28" height="16" rx="6" fill="url(#primary)" opacity="0.7" stroke="#0066FF" strokeWidth="1.5"/>
                  <motion.circle
                    cx="212"
                    cy="95"
                    r="2.5"
                    fill="#00BCD4"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1.8, repeat: Infinity }}
                  />
                  <motion.circle
                    cx="228"
                    cy="95"
                    r="2.5"
                    fill="#00BCD4"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1.8, repeat: Infinity, delay: 0.6 }}
                  />
                </motion.g>

                {/* Tools */}
                <motion.g
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.5, delay: 0.8 }}
                  style={{ transformOrigin: "260px 210px" }}
                >
                  <rect x="255" y="200" width="10" height="25" rx="2" fill="#0066FF" opacity="0.5"/>
                  <rect x="268" y="205" width="10" height="20" rx="2" fill="#00BCD4" opacity="0.5"/>
                  <circle cx="260" cy="198" r="3" fill="#00BCD4"/>
                  <circle cx="273" cy="203" r="3" fill="#0066FF"/>
                </motion.g>

                {/* Connecting Data Lines */}
                <motion.path
                  d="M 190 200 Q 215 170 240 145"
                  fill="none"
                  stroke="url(#primary)"
                  strokeWidth="1.5"
                  strokeDasharray="4,4"
                  opacity="0.4"
                  initial={{ pathLength: 0 }}
                  animate={isInView ? { pathLength: 1 } : {}}
                  transition={{ duration: 1.5, delay: 0.9 }}
                />
                <motion.path
                  d="M 190 200 Q 165 155 140 120"
                  fill="none"
                  stroke="url(#secondary)"
                  strokeWidth="1.5"
                  strokeDasharray="4,4"
                  opacity="0.4"
                  initial={{ pathLength: 0 }}
                  animate={isInView ? { pathLength: 1 } : {}}
                  transition={{ duration: 1.5, delay: 1 }}
                />

                {/* Floating Particles */}
                {[...Array(6)].map((_, i) => (
                  <motion.circle
                    key={i}
                    cx={110 + i * 30}
                    cy={250 - i * 10}
                    r="1.5"
                    fill="#00BCD4"
                    opacity="0.6"
                    initial={{ opacity: 0 }}
                    animate={{
                      opacity: [0, 0.6, 0],
                      y: [0, -30],
                    }}
                    transition={{
                      duration: 2.5,
                      repeat: Infinity,
                      delay: i * 0.4,
                    }}
                  />
                ))}
              </svg>
            </div>
          </motion.div>

          {/* RIGHT — Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="space-y-6"
          >
            {/* Title */}
            <div>
              <motion.h2
                initial={{ opacity: 0, y: 15 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-4xl lg:text-[52px] font-extrabold text-[#0A1628] leading-tight mb-3"
              >
                Centre of Excellence
              </motion.h2>

              {/* Subheading */}
              <motion.p
                initial={{ opacity: 0, y: 15 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="text-xl lg:text-[22px] text-[#475569] font-medium leading-relaxed"
              >
                Advanced Automotive Training & Innovation Labs for Future Mobility
              </motion.p>
            </div>

            {/* Bullet Points - Compact Grid */}
            <div className="grid gap-3 pt-2">
              {features.map((feature, idx) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: 15 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.4 + idx * 0.06 }}
                    className="flex items-start gap-3 group"
                  >
                    {/* Icon */}
                    <div className="flex-shrink-0 size-10 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-lg flex items-center justify-center group-hover:bg-gradient-to-br group-hover:from-[#0066FF]/20 group-hover:to-[#00BCD4]/20 transition-all">
                      <Icon className="size-[18px] text-[#0066FF]" strokeWidth={2} />
                    </div>

                    {/* Text */}
                    <div className="flex-1 pt-0.5">
                      <h3 className="font-semibold text-[17px] text-[#0A1628] leading-tight mb-0.5">
                        {feature.title}
                      </h3>
                      <p className="text-[15px] text-[#64748B] leading-snug">
                        {feature.description}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="flex flex-wrap gap-3 pt-4"
            >
              {/* Primary CTA */}
              <a
                href="#facilities"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-semibold text-[15px] shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
              >
                <span>Explore Facilities</span>
                <ArrowRight className="size-4" strokeWidth={2.5} />
              </a>

              {/* Secondary CTA */}
              <a
                href="#gallery"
                className="inline-flex items-center gap-2 px-6 py-3 bg-white border-2 border-gray-200 text-[#0066FF] rounded-xl font-semibold text-[15px] hover:border-[#0066FF] hover:bg-[#0066FF]/5 transition-all"
              >
                <ImageIcon className="size-4" strokeWidth={2.5} />
                <span>View Lab Gallery</span>
              </a>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
