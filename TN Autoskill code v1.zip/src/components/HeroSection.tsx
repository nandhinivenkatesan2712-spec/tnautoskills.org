import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Zap, Award, Users } from "lucide-react";
import { CTAButton } from "./CTAButton";

export function HeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"]
  });

  const imageY = useTransform(scrollYProgress, [0, 1], ["0%", "15%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "-10%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0.85]);

  return (
    <section
      ref={sectionRef}
      className="relative bg-gradient-to-br from-[#EEF5FF] via-[#F8FBFF] to-[#E3F2FD] overflow-hidden"
      style={{ minHeight: "calc(100vh - 68px)" }}
    >
      {/* Animated Mesh Gradient Background */}
      <div className="absolute inset-0 opacity-40">
        <motion.div
          animate={{
            background: [
              "radial-gradient(circle at 20% 50%, rgba(0, 74, 187, 0.15) 0%, transparent 50%)",
              "radial-gradient(circle at 80% 50%, rgba(0, 85, 221, 0.15) 0%, transparent 50%)",
              "radial-gradient(circle at 20% 50%, rgba(0, 74, 187, 0.15) 0%, transparent 50%)",
            ],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute inset-0"
        />
      </div>

      {/* Floating Geometric Shapes */}
      <motion.div
        animate={{
          y: [0, -30, 0],
          rotate: [0, 10, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-20 right-[10%] w-24 h-24 border-4 border-blue-400/30 rounded-2xl rotate-12"
      />
      <motion.div
        animate={{
          y: [0, 40, 0],
          rotate: [0, -15, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute bottom-32 left-[8%] w-32 h-32 bg-gradient-to-br from-cyan-400/20 to-blue-500/20 rounded-full blur-xl"
      />
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.6, 0.3],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-1/3 left-[5%] w-16 h-16 bg-blue-500/20 rounded-xl rotate-45"
      />

      {/* Soft 3D Wave Overlay */}
      <motion.div
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%", "0% 0%"],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear",
        }}
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 50 Q 25 30, 50 50 T 100 50' stroke='%23004ABB' stroke-width='1' fill='none'/%3E%3C/svg%3E")`,
          backgroundSize: "100px 100px",
        }}
      />

      <motion.div
        style={{ y: contentY, opacity }}
        className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16"
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center min-h-[calc(100vh-160px)] sm:min-h-[calc(100vh-140px)] lg:min-h-[calc(100vh-132px)]">
          {/* Left Content */}
          <motion.div
            style={{ y: contentY, opacity }}
            className="relative z-10 text-center lg:text-left space-y-6 sm:space-y-8 order-2 lg:order-1"
          >
            {/* Government Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 bg-white/90 backdrop-blur-md rounded-full border border-blue-100 shadow-lg mx-auto lg:mx-0"
            >
              <div className="size-2 sm:size-2.5 bg-green-500 rounded-full animate-pulse" />
              <span className="text-xs sm:text-sm font-semibold text-[#0b1220]">
                Government of Tamil Nadu Initiative
              </span>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-extrabold leading-[1.15] text-[#0A0A0A]"
            >
              Empowering Tamil Nadu's
              <br />
              <span className="bg-gradient-to-r from-[#004ABB] to-[#0055DD] bg-clip-text text-transparent">
                Automotive Skills
              </span>
              <br />
              for Global Excellence
            </motion.h1>

            {/* Subheading */}
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-sm sm:text-base lg:text-lg xl:text-xl text-[#475569] leading-relaxed max-w-2xl mx-auto lg:mx-0"
            >
              India's premier automotive skill development centre, fostering world-class
              talent through cutting-edge training programs and industry partnerships.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-3 sm:gap-4 items-stretch sm:items-center justify-center lg:justify-start"
            >
              {/* Primary CTA */}
              <CTAButton href="#programs" variant="primary" size="lg">
                Explore Programs
              </CTAButton>
            </motion.div>

            {/* Stats Row */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="grid grid-cols-3 gap-4 sm:gap-6 pt-6 sm:pt-8"
            >
              {[
                { icon: Users, value: "10,000+", label: "Students Trained" },
                { icon: Award, value: "95%", label: "Placement Rate" },
                { icon: Zap, value: "50+", label: "Industry Partners" },
              ].map((stat, idx) => (
                <div key={idx} className="text-center lg:text-left">
                  <div className="flex items-center justify-center lg:justify-start gap-2 mb-1 sm:mb-2">
                    <stat.icon className="size-4 sm:size-5 text-[#004ABB]" />
                    <span className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-[#0b1220]">
                      {stat.value}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-[#64748b]">{stat.label}</p>
                </div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right Image */}
          <motion.div
            style={{ y: imageY }}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="relative order-1 lg:order-2"
          >
            {/* Image Container */}
            <div className="relative aspect-[4/3] lg:aspect-auto lg:h-[500px] xl:h-[600px] rounded-3xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1668348728802-043e35f5d676?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvbW90aXZlJTIwdHJhaW5pbmclMjBmYWNpbGl0eSUyMG1vZGVybnxlbnwxfHx8fDE3NjM2MTg3NTl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="TN AutoSkills Training Facility"
                className="w-full h-full object-cover"
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#004ABB]/40 via-transparent to-transparent" />
              
              {/* Floating Badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 1 }}
                className="absolute bottom-4 sm:bottom-6 left-4 sm:left-6 bg-white/95 backdrop-blur-md rounded-2xl p-3 sm:p-4 shadow-xl"
              >
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="size-10 sm:size-12 bg-gradient-to-br from-[#004ABB] to-[#0055DD] rounded-xl flex items-center justify-center">
                    <Award className="size-5 sm:size-6 text-white" />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm font-bold text-[#0A0A0A]">ISO Certified</p>
                    <p className="text-[10px] sm:text-xs text-[#64748b]">World-Class Training</p>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Decorative Elements */}
            <div className="hidden lg:block absolute -top-6 -right-6 w-32 h-32 bg-[#004ABB]/10 rounded-full blur-2xl" />
            <div className="hidden lg:block absolute -bottom-6 -left-6 w-32 h-32 bg-[#0055DD]/10 rounded-full blur-2xl" />
          </motion.div>
        </div>
      </motion.div>

      {/* Bottom Fade to Next Section */}
      <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-white/80 to-transparent pointer-events-none" />
    </section>
  );
}