import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Phone } from "lucide-react";
import { CTAButton } from "./CTAButton";

export function LetsBegin() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-20 lg:py-[100px] overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#004ABB] via-[#003D99] to-[#002D77]" />
      
      {/* Animated Wireframe Lines */}
      <div className="absolute inset-0 opacity-20">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern
              id="wireframe"
              x="0"
              y="0"
              width="100"
              height="100"
              patternUnits="userSpaceOnUse"
            >
              <motion.path
                d="M 0 0 L 100 100 M 100 0 L 0 100 M 50 0 L 50 100 M 0 50 L 100 50"
                fill="none"
                stroke="white"
                strokeWidth="0.5"
                animate={{
                  opacity: [0.3, 0.6, 0.3],
                  pathLength: [0, 1, 0],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "linear",
                }}
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#wireframe)" />
        </svg>
      </div>

      {/* Gradient Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-20 left-20 w-96 h-96 bg-gradient-radial from-white/30 to-transparent rounded-full blur-3xl"
      />
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-radial from-cyan-300/30 to-transparent rounded-full blur-3xl"
      />

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center space-y-6 lg:space-y-8"
        >
          {/* Main Heading */}
          <h2 className="text-white text-5xl lg:text-6xl xl:text-7xl font-extrabold leading-tight max-w-5xl mx-auto">
            Let's Shape the Future{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-blue-200">
              Together
            </span>
          </h2>

          {/* Subtitle */}
          <p className="text-white/90 text-xl lg:text-2xl max-w-3xl mx-auto leading-relaxed">
            Join us in revolutionizing automotive education and creating a
            skilled workforce ready for tomorrow's mobility challenges.
            Partnership opportunities available for industry leaders, academic
            institutions, and innovation partners.
          </p>

          {/* Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center pt-6"
          >
            {/* Primary CTA */}
            <CTAButton href="#partner" variant="primary" size="lg">
              Become a Partner
            </CTAButton>

            {/* Secondary CTA */}
            <CTAButton variant="secondary" size="lg">
              Contact Us
            </CTAButton>
          </motion.div>

          {/* Trust Indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="pt-8 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto"
          >
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <div className="text-4xl font-extrabold text-white mb-2">
                100+
              </div>
              <div className="text-white/80 text-lg">
                Active Partners
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <div className="text-4xl font-extrabold text-white mb-2">
                2,000+
              </div>
              <div className="text-white/80 text-lg">
                Lives Transformed
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <div className="text-4xl font-extrabold text-white mb-2">
                85%
              </div>
              <div className="text-white/80 text-lg">
                Placement Success
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}