import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Building2, Cog, ShoppingCart, Lightbulb, CheckCircle, ArrowRight } from "lucide-react";

export function PastelEmpanelment() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const categories = [
    {
      icon: Building2,
      title: "OEMs",
      subtitle: "Original Equipment Manufacturers",
      color: "blue",
      background: "from-blue-50/80 to-blue-100/60",
      hoverBg: "group-hover:from-blue-100/90 group-hover:to-blue-200/70",
      iconBg: "bg-blue-100/70",
      iconColor: "text-blue-600",
      borderColor: "border-blue-200/50",
      hoverBorder: "group-hover:border-blue-300",
      points: [
        "Workforce development programs",
        "Specialized training modules",
        "Access to skilled talent pool",
      ],
    },
    {
      icon: Cog,
      title: "Auto Suppliers",
      subtitle: "Component Manufacturers",
      color: "teal",
      background: "from-teal-50/80 to-teal-100/60",
      hoverBg: "group-hover:from-teal-100/90 group-hover:to-teal-200/70",
      iconBg: "bg-teal-100/70",
      iconColor: "text-teal-600",
      borderColor: "border-teal-200/50",
      hoverBorder: "group-hover:border-teal-300",
      points: [
        "Technical skill training",
        "Competency development",
        "Quality assurance training",
      ],
    },
    {
      icon: ShoppingCart,
      title: "Retail Partners",
      subtitle: "Service Networks",
      color: "amber",
      background: "from-amber-50/80 to-amber-100/60",
      hoverBg: "group-hover:from-amber-100/90 group-hover:to-amber-200/70",
      iconBg: "bg-amber-100/70",
      iconColor: "text-amber-600",
      borderColor: "border-amber-200/50",
      hoverBorder: "group-hover:border-amber-300",
      points: [
        "Service technician training",
        "Customer service modules",
        "After-sales support",
      ],
    },
    {
      icon: Lightbulb,
      title: "Startups",
      subtitle: "Innovation Hubs",
      color: "pink",
      background: "from-pink-50/80 to-pink-100/60",
      hoverBg: "group-hover:from-pink-100/90 group-hover:to-pink-200/70",
      iconBg: "bg-pink-100/70",
      iconColor: "text-pink-600",
      borderColor: "border-pink-200/50",
      hoverBorder: "group-hover:border-pink-300",
      points: [
        "EV and new mobility training",
        "Technology integration",
        "R&D collaboration",
      ],
    },
  ];

  return (
    <section ref={ref} className="py-12 bg-gradient-to-b from-white to-[#F8FAFB]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          {/* Title */}
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Empanelment Opportunities
          </h2>

          {/* Subtitle */}
          <p className="text-[15px] text-[#64748B] max-w-3xl mx-auto leading-relaxed">
            Partner with TN AutoSkills across OEMs, Auto Suppliers, Retail, and Startups.
          </p>
        </motion.div>

        {/* 2×2 Pastel Cards Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {categories.map((category, idx) => {
            const Icon = category.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -8 }}
                className={`group relative rounded-[24px] p-6 border ${category.borderColor} ${category.hoverBorder} bg-gradient-to-br ${category.background} ${category.hoverBg} shadow-sm hover:shadow-lg transition-all duration-300`}
              >
                {/* Icon & Header */}
                <div className="flex items-start gap-4 mb-5">
                  {/* Icon Container */}
                  <div className={`size-14 ${category.iconBg} backdrop-blur-sm rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className={`size-6 ${category.iconColor}`} strokeWidth={1.5} />
                  </div>

                  {/* Title & Subtitle */}
                  <div className="flex-1">
                    <h3 className="font-extrabold text-xl text-[#0A0A0A] mb-1">
                      {category.title}
                    </h3>
                    <p className="text-sm text-[#64748B] font-medium">
                      {category.subtitle}
                    </p>
                  </div>
                </div>

                {/* Bullet Points */}
                <ul className="space-y-2.5">
                  {category.points.map((point, i) => (
                    <li key={i} className="flex items-start gap-2.5">
                      <CheckCircle
                        className={`size-4 ${category.iconColor} flex-shrink-0 mt-0.5`}
                        strokeWidth={2}
                      />
                      <span className="text-[15px] text-[#475569] leading-relaxed">
                        {point}
                      </span>
                    </li>
                  ))}
                </ul>

                {/* Decorative Corner Accent */}
                <div className={`absolute top-0 right-0 w-24 h-24 ${category.background} opacity-30 rounded-bl-full blur-2xl pointer-events-none`} />
              </motion.div>
            );
          })}
        </div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#empanelment"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-2xl font-bold text-[15px] shadow-md hover:shadow-xl hover:scale-[1.02] transition-all duration-300"
          >
            <span>Apply for Empanelment</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
