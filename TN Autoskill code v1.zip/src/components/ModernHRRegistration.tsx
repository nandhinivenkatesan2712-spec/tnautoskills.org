import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Users, GraduationCap, Building, ArrowRight } from "lucide-react";

export function ModernHRRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    {
      icon: Users,
      title: "Skilled Workforce Hiring",
      description: "Access to certified automotive professionals ready for deployment",
      color: "blue",
    },
    {
      icon: GraduationCap,
      title: "Apprentice (NAPS/NATS) Support",
      description: "National Apprenticeship schemes for fresh talent integration",
      color: "emerald",
    },
    {
      icon: Building,
      title: "On-Campus / Virtual Recruitment",
      description: "Flexible hiring through campus drives and online platforms",
      color: "violet",
    },
  ];

  return (
    <section ref={ref} className="py-20 bg-gradient-to-b from-white to-gray-50/30">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            HR Registration for Recruitment
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            Register your company HR team to post job openings and hire TN AutoSkills-trained candidates.
          </p>
        </motion.div>

        {/* Horizontal Feature Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-10">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className={`group bg-white border border-gray-200/60 rounded-[20px] p-8 hover:bg-gradient-to-br ${
                  feature.color === "blue"
                    ? "hover:from-blue-50/40 hover:to-blue-100/20"
                    : feature.color === "emerald"
                    ? "hover:from-emerald-50/40 hover:to-emerald-100/20"
                    : "hover:from-violet-50/40 hover:to-violet-100/20"
                } hover:border-gray-300/80 hover:shadow-[0_10px_28px_rgba(0,0,0,0.09)] hover:-translate-y-1 transition-all duration-300 cursor-pointer`}
              >
                {/* Icon */}
                <div className="mb-5">
                  <Icon
                    className={`size-8 ${
                      feature.color === "blue"
                        ? "text-blue-500"
                        : feature.color === "emerald"
                        ? "text-emerald-500"
                        : "text-violet-500"
                    } transition-transform duration-300 group-hover:scale-110`}
                    strokeWidth={1.5}
                  />
                </div>

                {/* Content */}
                <h3 className="font-semibold text-[19px] text-[#0A0A0A] mb-3">
                  {feature.title}
                </h3>
                <p className="text-[15px] text-[#64748B] leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center"
        >
          <button className="group inline-flex items-center gap-2.5 px-8 py-4 bg-[#0066FF] hover:bg-[#0052CC] text-white rounded-[20px] font-semibold text-[15px] shadow-md hover:shadow-lg transition-all duration-250 active:scale-[0.98]">
            <span>Register as HR Partner</span>
            <ArrowRight className="size-5 transition-transform duration-250 group-hover:translate-x-1" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
