import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Award, Sparkles, Briefcase, UserCheck, ArrowRight } from "lucide-react";

export function ModernAcademiaAlumni() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    {
      icon: Award,
      title: "100% Placement Support",
      description: "End-to-end career guidance and placement assistance",
      color: "blue",
    },
    {
      icon: Sparkles,
      title: "Future-Skills Training",
      description: "Industry 4.0 skills including EV, AI, and automation",
      color: "emerald",
    },
    {
      icon: Briefcase,
      title: "OEM-Led Real Projects",
      description: "Hands-on experience with leading automotive companies",
      color: "violet",
    },
    {
      icon: UserCheck,
      title: "Faculty Upskilling",
      description: "Continuous professional development for educators",
      color: "amber",
    },
  ];

  const partners = [
    "Hyundai",
    "Maruti Suzuki",
    "Tata Motors",
    "TVS Motors",
    "Ashok Leyland",
    "Royal Enfield",
  ];

  return (
    <section ref={ref} className="py-20 bg-gradient-to-b from-white to-gray-50/30">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Academia & Alumni Support
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            Comprehensive support for students, alumni, and faculty in the automotive sector.
          </p>
        </motion.div>

        {/* Mini Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className={`group bg-white border border-gray-200/60 rounded-[20px] p-6 hover:bg-gradient-to-br ${
                  feature.color === "blue"
                    ? "hover:from-blue-50/40 hover:to-blue-100/20"
                    : feature.color === "emerald"
                    ? "hover:from-emerald-50/40 hover:to-emerald-100/20"
                    : feature.color === "violet"
                    ? "hover:from-violet-50/40 hover:to-violet-100/20"
                    : "hover:from-amber-50/40 hover:to-amber-100/20"
                } hover:border-gray-300/80 hover:shadow-[0_10px_28px_rgba(0,0,0,0.09)] hover:-translate-y-1 transition-all duration-300 cursor-pointer`}
              >
                {/* Icon */}
                <div className="mb-4">
                  <Icon
                    className={`size-7 ${
                      feature.color === "blue"
                        ? "text-blue-500"
                        : feature.color === "emerald"
                        ? "text-emerald-500"
                        : feature.color === "violet"
                        ? "text-violet-500"
                        : "text-amber-500"
                    } transition-transform duration-300 group-hover:scale-110`}
                    strokeWidth={1.5}
                  />
                </div>

                {/* Content */}
                <h3 className="font-semibold text-[17px] text-[#0A0A0A] mb-2">
                  {feature.title}
                </h3>
                <p className="text-[14px] text-[#64748B] leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Academic Partnerships Gallery */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="bg-white border border-gray-200/60 rounded-[20px] p-8 mb-10"
        >
          <h3 className="font-semibold text-lg text-[#0A0A0A] mb-6 text-center">
            Academic Partnerships
          </h3>
          <div className="flex flex-wrap justify-center gap-6">
            {partners.map((partner, idx) => (
              <div
                key={idx}
                className="px-5 py-3 bg-gray-50 rounded-xl border border-gray-200/60 hover:bg-gray-100 hover:border-gray-300 transition-all duration-250"
              >
                <span className="text-[15px] font-medium text-[#0A0A0A]">
                  {partner}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="text-center"
        >
          <button className="group inline-flex items-center gap-2.5 px-8 py-4 bg-[#0066FF] hover:bg-[#0052CC] text-white rounded-[20px] font-semibold text-[15px] shadow-md hover:shadow-lg transition-all duration-250 active:scale-[0.98]">
            <span>Connect With Our Academic Cell</span>
            <ArrowRight className="size-5 transition-transform duration-250 group-hover:translate-x-1" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
