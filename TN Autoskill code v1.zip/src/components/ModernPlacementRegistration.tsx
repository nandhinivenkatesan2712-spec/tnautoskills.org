import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Users, Building2, FileText, CheckCircle, ArrowRight } from "lucide-react";

export function ModernPlacementRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    {
      icon: Users,
      title: "Student Placement Pipeline",
      description: "Streamlined process from training to placement with industry partners",
      points: [
        "Pre-placement training",
        "Mock interviews",
        "Resume building",
      ],
      color: "blue",
    },
    {
      icon: Building2,
      title: "Industry Hiring Network",
      description: "Direct access to 40+ automotive OEMs and suppliers for placements",
      points: [
        "On-campus drives",
        "Virtual interviews",
        "Job matching",
      ],
      color: "emerald",
    },
  ];

  const formFields = [
    "College Name",
    "Contact Person",
    "Email Address",
    "Phone Number",
    "Student Count",
  ];

  return (
    <section ref={ref} className="py-20 bg-gradient-to-b from-gray-50/30 to-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Placement Registration for Colleges
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            Colleges can register their students for interview support and placement assistance.
          </p>
        </motion.div>

        {/* Two-Column Layout */}
        <div className="grid lg:grid-cols-2 gap-8 mb-10">
          {/* Left: Feature Cards */}
          <div className="space-y-6">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.6, delay: idx * 0.2 }}
                  className={`group bg-white border border-gray-200/60 rounded-[20px] p-7 hover:bg-gradient-to-br ${
                    feature.color === "blue"
                      ? "hover:from-blue-50/40 hover:to-blue-100/20"
                      : "hover:from-emerald-50/40 hover:to-emerald-100/20"
                  } hover:border-gray-300/80 hover:shadow-[0_10px_28px_rgba(0,0,0,0.09)] hover:-translate-y-1 transition-all duration-300`}
                >
                  {/* Icon & Title */}
                  <div className="flex items-start gap-4 mb-4">
                    <div className="flex-shrink-0">
                      <Icon
                        className={`size-7 ${
                          feature.color === "blue"
                            ? "text-blue-500"
                            : "text-emerald-500"
                        } transition-transform duration-300 group-hover:scale-110`}
                        strokeWidth={1.5}
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-[19px] text-[#0A0A0A] mb-2">
                        {feature.title}
                      </h3>
                      <p className="text-[15px] text-[#64748B] leading-relaxed mb-4">
                        {feature.description}
                      </p>

                      {/* Points */}
                      <ul className="space-y-2">
                        {feature.points.map((point, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <CheckCircle className="size-4 text-[#0066FF] flex-shrink-0" strokeWidth={2} />
                            <span className="text-[14px] text-[#475569]">{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Right: Form Preview Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-gradient-to-br from-white to-gray-50/50 border border-gray-200/60 rounded-[20px] p-8 shadow-sm"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="size-10 bg-[#0066FF]/10 rounded-xl flex items-center justify-center">
                <FileText className="size-5 text-[#0066FF]" strokeWidth={1.5} />
              </div>
              <h3 className="font-semibold text-[19px] text-[#0A0A0A]">
                Registration Form
              </h3>
            </div>

            {/* Mock Form Fields */}
            <div className="space-y-4 mb-6">
              {formFields.map((field, idx) => (
                <div key={idx}>
                  <label className="block text-sm font-medium text-[#475569] mb-2">
                    {field}
                  </label>
                  <div className="h-11 bg-white border border-gray-200 rounded-xl px-4 flex items-center">
                    <span className="text-sm text-gray-400">Enter {field.toLowerCase()}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Mock Submit Button */}
            <button className="w-full py-3 bg-gray-100 text-gray-400 rounded-xl font-medium text-[15px] cursor-not-allowed">
              Submit Registration
            </button>

            <p className="text-xs text-[#64748B] mt-4 text-center">
              Click "Register Your College" below to access the full form
            </p>
          </motion.div>
        </div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center"
        >
          <button 
            onClick={() => window.location.hash = "placement-register"}
            className="group inline-flex items-center gap-2.5 px-8 py-4 bg-[#0066FF] hover:bg-[#0052CC] text-white rounded-[20px] font-semibold text-[15px] shadow-md hover:shadow-lg transition-all duration-250 active:scale-[0.98]"
          >
            <span>Register Your College</span>
            <ArrowRight className="size-5 transition-transform duration-250 group-hover:translate-x-1" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}