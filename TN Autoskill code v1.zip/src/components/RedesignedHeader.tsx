import { motion } from "motion/react";
import { useState, useEffect } from "react";
import { ArrowRight, Menu, X, ChevronDown } from "lucide-react";
import imgLogo1 from "figma:asset/14f8e66972ba1a8006cc1445bbada7a653c5bac0.png";
import { useLanguage } from "../contexts/LanguageContext";

export function RedesignedHeader() {
  const { language, setLanguage, t } = useLanguage();
  const [activeItem, setActiveItem] = useState(t("header.home"));
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState<string | null>(null);
  const [mobileDropdownOpen, setMobileDropdownOpen] = useState<string | null>(
    null
  );

  // Dynamic nav items based on language
  const navItems = [
    { label: t("header.home"), href: "#home" },
    { label: t("header.aboutUs"), href: "#about" },
    { label: t("header.courses"), href: "#courses" },
    { label: t("header.careers"), href: "#careers" },
    { label: t("header.successStories"), href: "#success-stories" },
    {
      label: t("header.exploreMore"),
      href: "#explore-more",
      subItems: [
        { label: t("header.gallery"), href: "#gallery" },
        { label: t("header.news"), href: "#news" },
        { label: t("header.events"), href: "#events" },
        { label: t("header.podcast"), href: "#podcast" },
      ],
    },
    { label: t("header.contact"), href: "#contact" },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (label: string, href: string) => {
    setActiveItem(label);
    setMobileMenuOpen(false);
    
    if (href === "#home") {
      window.location.hash = "";
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      window.location.hash = href;
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 bg-white transition-all duration-300 ${
        scrolled ? "shadow-lg" : "shadow-md"
      }`}
    >
      {/* Top Bar - Bilingual Title */}
      <div className="bg-gradient-to-r from-[#0066FF] to-[#0090FF] border-b border-blue-700">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-2">
          <div className="flex flex-col items-center justify-center gap-1 text-center">
            {/* Tamil Title */}
            <h1
              className="text-white text-[10px] sm:text-xs lg:text-sm font-semibold tracking-wide"
              style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
            >
              தமிழ்நாடு உயர்திறன் மேம்பாட்டு மையம் - ஆட்டோமொபைல்
            </h1>
            {/* English Title */}
            <h2 className="text-white/95 text-[9px] sm:text-[10px] lg:text-xs font-medium tracking-widest uppercase">
              Tamil Nadu Apex Skill Development Centre for Automobile
            </h2>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-18">
            {/* Left - Government Logo + TN AutoSkills Logo */}
            <div className="flex items-center gap-3 lg:gap-4">
              {/* Government Logo */}
              <a
                href="#home"
                onClick={() => handleNavClick("Home", "#home")}
                className="flex items-center gap-3 cursor-pointer"
              >
                <img
                  src={imgLogo1}
                  alt="Government of Tamil Nadu"
                  className="h-10 sm:h-11 lg:h-12 w-auto flex-shrink-0"
                />
              </a>

              {/* Divider */}
              <div className="hidden sm:block w-px h-10 bg-gray-300" />

              {/* TN AutoSkills Branding */}
              <div className="hidden sm:flex flex-col">
                <span className="text-[#0A0A0A] font-bold text-sm lg:text-base leading-tight">
                  TN AutoSkills
                </span>
                <span className="text-[#64748b] text-[10px] lg:text-xs leading-tight">
                  Skill Development Centre
                </span>
              </div>
            </div>

            {/* Center - Navigation Menu (Desktop) */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-1.5">
              {navItems.map((item) => (
                <div
                  key={item.label}
                  className="relative"
                  onMouseEnter={() => item.subItems && setDropdownOpen(item.label)}
                  onMouseLeave={() => setDropdownOpen(null)}
                >
                  <motion.a
                    href={item.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(item.label, item.href);
                    }}
                    whileHover={{ y: -2 }}
                    className={`relative px-2.5 xl:px-3 py-2 rounded-lg text-[13px] font-semibold transition-all flex items-center gap-1 whitespace-nowrap ${
                      activeItem === item.label
                        ? "text-[#0066FF]"
                        : "text-[#475569] hover:text-[#0A0A0A]"
                    }`}
                  >
                    {item.label}
                    {item.subItems && (
                      <ChevronDown className={`size-3.5 transition-transform ${
                        dropdownOpen === item.label ? "rotate-180" : ""
                      }`} />
                    )}
                    {activeItem === item.label && (
                      <motion.div
                        layoutId="activeNav"
                        className="absolute bottom-0 left-2 right-2 h-0.5 bg-[#0066FF] rounded-full"
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      />
                    )}
                  </motion.a>

                  {/* Dropdown Menu */}
                  {item.subItems && dropdownOpen === item.label && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                      className="absolute top-full left-0 mt-1 bg-white rounded-xl shadow-lg border border-gray-100 py-2 min-w-[200px] z-50"
                    >
                      {item.subItems.map((subItem) => (
                        <a
                          key={subItem.label}
                          href={subItem.href}
                          onClick={(e) => {
                            e.preventDefault();
                            handleNavClick(subItem.label, subItem.href);
                            setDropdownOpen(null);
                          }}
                          className="block px-4 py-2.5 text-[13px] font-semibold text-[#475569] hover:text-[#0066FF] hover:bg-blue-50 transition-all"
                        >
                          {subItem.label}
                        </a>
                      ))}
                    </motion.div>
                  )}
                </div>
              ))}
            </nav>

            {/* Right - Language Toggle & Apply Button */}
            <div className="hidden lg:flex items-center gap-4">
              {/* Language Toggle */}
              <div className="flex items-center gap-1 px-3 py-1.5 bg-gray-50 rounded-lg border border-gray-200">
                <button
                  onClick={() => setLanguage("EN")}
                  className={`relative px-3 py-1.5 rounded-md text-[13px] font-semibold transition-all ${
                    language === "EN"
                      ? "text-[#0066FF]"
                      : "text-[#64748b] hover:text-[#0A0A0A]"
                  }`}
                >
                  EN
                  {language === "EN" && (
                    <motion.div
                      layoutId="languageIndicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0066FF] rounded-full"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
                <span className="text-gray-300">|</span>
                <button
                  onClick={() => setLanguage("தமிழ்")}
                  className={`relative px-3 py-1.5 rounded-md text-[13px] font-semibold transition-all ${
                    language === "தமிழ்"
                      ? "text-[#0066FF]"
                      : "text-[#64748b] hover:text-[#0A0A0A]"
                  }`}
                  style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
                >
                  தமிழ்
                  {language === "தமிழ்" && (
                    <motion.div
                      layoutId="languageIndicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0066FF] rounded-full"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
              </div>

              {/* Apply Now Button */}
              <motion.a
                href="#apply"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-semibold text-sm shadow-lg hover:shadow-xl transition-all"
              >
                <span>{t("header.applyNow")}</span>
                <ArrowRight className="size-4" />
              </motion.a>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#475569] hover:text-[#0A0A0A] transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="size-6" /> : <Menu className="size-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-gray-200 bg-white"
          >
            <nav className="px-4 py-4 space-y-1 max-h-[70vh] overflow-y-auto">
              {navItems.map((item) => (
                <div key={item.label}>
                  {/* Main Menu Item */}
                  <div
                    className={`block px-4 py-3 rounded-lg text-sm font-semibold transition-all min-h-[44px] flex items-center justify-between ${
                      activeItem === item.label
                        ? "bg-blue-50 text-[#0066FF]"
                        : "text-[#475569] hover:bg-gray-50 hover:text-[#0A0A0A]"
                    }`}
                  >
                    <a
                      href={item.href}
                      onClick={(e) => {
                        e.preventDefault();
                        if (!item.subItems) {
                          handleNavClick(item.label, item.href);
                        }
                      }}
                      className="flex-1"
                    >
                      {item.label}
                    </a>
                    {item.subItems && (
                      <button
                        onClick={() =>
                          setMobileDropdownOpen(
                            mobileDropdownOpen === item.label ? null : item.label
                          )
                        }
                        className="p-1"
                        aria-label={`Toggle ${item.label} submenu`}
                      >
                        <ChevronDown
                          className={`size-4 transition-transform ${
                            mobileDropdownOpen === item.label ? "rotate-180" : ""
                          }`}
                        />
                      </button>
                    )}
                  </div>

                  {/* Submenu Items */}
                  {item.subItems && mobileDropdownOpen === item.label && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-1 ml-4 space-y-1"
                    >
                      {item.subItems.map((subItem) => (
                        <a
                          key={subItem.label}
                          href={subItem.href}
                          onClick={(e) => {
                            e.preventDefault();
                            handleNavClick(subItem.label, subItem.href);
                            setMobileDropdownOpen(null);
                          }}
                          className="block px-4 py-2.5 rounded-lg text-sm font-semibold text-[#475569] hover:text-[#0066FF] hover:bg-blue-50 transition-all min-h-[44px] flex items-center"
                        >
                          {subItem.label}
                        </a>
                      ))}
                    </motion.div>
                  )}
                </div>
              ))}

              {/* Mobile Language Toggle */}
              <div className="pt-2 pb-1">
                <div className="flex items-center gap-1 px-3 py-2 bg-gray-50 rounded-lg border border-gray-200">
                  <button
                    onClick={() => setLanguage("EN")}
                    className={`flex-1 px-3 py-2.5 rounded-md text-sm font-semibold transition-all min-h-[44px] flex items-center justify-center ${
                      language === "EN"
                        ? "text-[#0066FF] bg-white shadow-sm"
                        : "text-[#64748b]"
                    }`}
                  >
                    EN
                  </button>
                  <span className="text-gray-300">|</span>
                  <button
                    onClick={() => setLanguage("தமிழ்")}
                    className={`flex-1 px-3 py-2.5 rounded-md text-sm font-semibold transition-all min-h-[44px] flex items-center justify-center ${
                      language === "தமிழ்"
                        ? "text-[#0066FF] bg-white shadow-sm"
                        : "text-[#64748b]"
                    }`}
                    style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
                  >
                    தமிழ���
                  </button>
                </div>
              </div>

              {/* Mobile Apply Button */}
              <a
                href="#apply"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-lg text-sm font-semibold text-center min-h-[44px] flex items-center justify-center gap-2 shadow-lg"
              >
                <span>{t("header.applyNow")}</span>
                <ArrowRight className="size-4" />
              </a>
            </nav>
          </motion.div>
        )}
      </div>
    </header>
  );
}