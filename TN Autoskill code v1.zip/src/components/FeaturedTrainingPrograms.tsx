import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight, Zap, Wrench, Settings } from "lucide-react";

const programs = [
  {
    id: 1,
    title: "Battery Electric Vehicle Training",
    icon: Zap,
    description: "Comprehensive training in EV technology, battery systems, power electronics, and charging infrastructure for the future of mobility",
  },
  {
    id: 2,
    title: "Automotive Service Technician",
    icon: Wrench,
    description: "Master vehicle diagnostics, repair techniques, maintenance procedures, and service management for modern automotive systems",
  },
  {
    id: 3,
    title: "Advanced Manufacturing Technology",
    icon: Settings,
    description: "Learn CNC machine operation, Industry 4.0 technologies, automation, and advanced manufacturing techniques",
  },
];

export function FeaturedTrainingPrograms() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 bg-white relative overflow-hidden">
      {/* Subtle Background Accent */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-[#0066FF]/5 to-transparent rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-[52px] font-extrabold text-[#0A1628] leading-tight mb-3">
            Featured Training Programs
          </h2>
          <p className="text-xl lg:text-[22px] text-[#475569] font-medium leading-relaxed max-w-4xl mx-auto">
            Industry-Certified Programs Designed To Build Automotive Expertise And Career Readiness
          </p>
        </motion.div>

        {/* Programs Grid - 3 Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {programs.map((program, idx) => {
            const Icon = program.icon;
            return (
              <motion.div
                key={program.id}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 + idx * 0.1 }}
                className="group relative bg-white rounded-2xl border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-xl transition-all overflow-hidden"
                style={{ boxShadow: "0 2px 8px rgba(0, 0, 0, 0.04)" }}
              >
                {/* Blue Gradient Top Border */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0066FF] to-[#00BCD4]" />

                {/* Card Content */}
                <div className="p-8">
                  {/* Icon Container */}
                  <div className="size-14 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-xl flex items-center justify-center mb-5 group-hover:scale-105 transition-transform">
                    <Icon className="size-7 text-[#0066FF]" strokeWidth={2} />
                  </div>

                  {/* Title */}
                  <h3 className="text-xl lg:text-[22px] font-bold text-[#0A1628] leading-tight mb-3">
                    {program.title}
                  </h3>

                  {/* Description */}
                  <p className="text-base lg:text-[17px] text-[#64748B] leading-relaxed mb-6">
                    {program.description}
                  </p>

                  {/* CTA Arrow */}
                  <div className="flex items-center justify-end">
                    <div className="inline-flex items-center justify-center size-10 rounded-full bg-[#0066FF]/5 group-hover:bg-[#0066FF] transition-all cursor-pointer">
                      <ArrowRight className="size-5 text-[#0066FF] group-hover:text-white group-hover:translate-x-0.5 transition-all" strokeWidth={2.5} />
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="text-center mt-12"
        >
          <a
            href="#programs"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] text-white rounded-xl font-semibold text-[15px] shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            <span>View All Programs</span>
            <ArrowRight className="size-4" strokeWidth={2.5} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
