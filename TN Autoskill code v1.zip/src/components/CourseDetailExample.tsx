/**
 * Course Detail Page - Example Usage
 * 
 * This file demonstrates how to use the CourseDetailPage component
 * with the course data from CoursesPage.tsx
 * 
 * To integrate this into your routing:
 * 1. Import the courses array from CoursesPage
 * 2. Create a route parameter for course ID
 * 3. Find the course by ID and pass it to CourseDetailPage
 */

import { CourseDetailPage } from "./CourseDetailPage";
import { courses } from "./CoursesPage";

// Example: Course Detail Page for Course ID 1
export function CourseDetail1() {
  const course = courses.find(c => c.id === 1);
  
  if (!course) {
    return <div>Course not found</div>;
  }
  
  return <CourseDetailPage course={course} />;
}

// Example: Course Detail Page for Course ID 2
export function CourseDetail2() {
  const course = courses.find(c => c.id === 2);
  
  if (!course) {
    return <div>Course not found</div>;
  }
  
  return <CourseDetailPage course={course} />;
}

// Example: Course Detail Page for Course ID 3
export function CourseDetail3() {
  const course = courses.find(c => c.id === 3);
  
  if (!course) {
    return <div>Course not found</div>;
  }
  
  return <CourseDetailPage course={course} />;
}

// ... Continue for all courses

/**
 * Alternative: Dynamic Course Detail Page
 * 
 * If you want to use URL parameters or dynamic routing:
 */
interface DynamicCourseDetailProps {
  courseId: number;
}

export function DynamicCourseDetail({ courseId }: DynamicCourseDetailProps) {
  const course = courses.find(c => c.id === courseId);
  
  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-[#0A0A0A] mb-2">
            Course Not Found
          </h1>
          <p className="text-[#64748B] mb-6">
            The course you're looking for doesn't exist.
          </p>
          <a 
            href="#courses"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0066FF] text-white rounded-xl font-semibold hover:bg-[#0090FF] transition-all"
          >
            View All Courses
          </a>
        </div>
      </div>
    );
  }
  
  return <CourseDetailPage course={course} />;
}
