import { motion } from "motion/react";
import { ArrowLeft } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const teamMembers = [
  {
    name: "Mr. KASI VISWANATHAN",
    designation: "Managing Director",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Mr. YESHWANTH KUMAR M",
    designation: "Chief Finance Officer",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Mr. SHINU THOMAS T",
    designation: "Head – CSR & Business Development (Automotive OEM Suppliers)",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Mr. LAKSHMI NARAYAN P S",
    designation: "Head – Government Projects",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Mr. LALITESH KUMAR MITTAL A",
    designation: "Head – Business Development (Automotive Startup)",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Mr. VANCHI V",
    designation: "Head – Business Development (Automotive OEM)",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Mrs. AKALYA RAJKUMAR",
    designation: "HR Associate",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Mr. ARISHKUMAR A",
    designation: "Accounts Associate",
    image: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Ms. MANCHU PRIYA P",
    designation: "Project Associate – Government Projects",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Ms. SHARMILA K",
    designation: "Project Associate – Government Projects",
    image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Ms. PREETHI J",
    designation: "Project Associate – Placements",
    image: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Ms. ARCHANA A",
    designation: "Admin & Facility Executive",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
];

// Team Member Card Component - Matching Board Members Design
interface TeamMemberCardProps {
  name: string;
  designation: string;
  image: string;
  index: number;
}

function TeamMemberCard({ name, designation, image, index }: TeamMemberCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className="w-full max-w-[360px] mx-auto"
    >
      <motion.div
        whileHover={{ y: -6, scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="bg-white overflow-hidden transition-all duration-300 h-full flex flex-col"
        style={{ 
          borderRadius: "20px",
          boxShadow: "0 8px 24px rgba(0, 0, 0, 0.05)",
          padding: "28px"
        }}
      >
        {/* Image - 360px height, 16px rounded corners, full width */}
        <div 
          className="relative w-full mb-6 overflow-hidden bg-gradient-to-br from-[#F9FBFF] to-[#E7ECF5]"
          style={{ 
            height: "360px",
            borderRadius: "16px",
            marginLeft: "-28px",
            marginRight: "-28px",
            marginTop: "-28px",
            width: "calc(100% + 56px)"
          }}
        >
          <ImageWithFallback
            src={image}
            alt={`${name} - Team Member`}
            className="w-full h-full object-cover object-center transition-transform duration-500 hover:scale-105"
          />
        </div>

        {/* Content - Center aligned */}
        <div className="text-center flex-1 flex flex-col">
          {/* Name - 18px Bold, Inter SemiBold, #141B34 */}
          <h3
            className="mb-2"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "18px",
              fontWeight: 600,
              lineHeight: "1.4",
              color: "#141B34"
            }}
          >
            {name}
          </h3>

          {/* Designation - 16px, 140% line-height, #4D5565 */}
          <p
            className="flex-1"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "16px",
              fontWeight: 400,
              lineHeight: "1.4",
              color: "#4D5565"
            }}
          >
            {designation}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}

export function TeamPage() {
  return (
    <div 
      className="relative min-h-screen"
      style={{
        background: "linear-gradient(to bottom, #F9FBFF 0%, #F1F5FF 100%)"
      }}
      id="our-team"
    >
      {/* Light Automotive Ring Patterns - 5% Opacity */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ opacity: 0.05 }}>
        {/* Top Right Ring Pattern */}
        <motion.div
          animate={{ 
            rotate: [0, 360],
          }}
          transition={{ 
            rotate: { duration: 60, repeat: Infinity, ease: "linear" }
          }}
          className="absolute top-[10%] right-[5%] w-[500px] h-[500px]"
        >
          <div className="absolute inset-0 rounded-full border-2 border-[#0A66FF]" />
          <div className="absolute inset-[15%] rounded-full border border-[#0A66FF]" />
          <div className="absolute inset-[30%] rounded-full border border-[#0A66FF]" />
          <div className="absolute inset-[45%] rounded-full border-2 border-[#0A66FF]" />
        </motion.div>

        {/* Bottom Left Ring Pattern */}
        <motion.div
          animate={{ 
            rotate: [360, 0],
          }}
          transition={{ 
            rotate: { duration: 50, repeat: Infinity, ease: "linear" }
          }}
          className="absolute bottom-[15%] left-[8%] w-[400px] h-[400px]"
        >
          <div className="absolute inset-0 rounded-full border border-[#0A66FF]" />
          <div className="absolute inset-[20%] rounded-full border-2 border-[#0A66FF]" />
          <div className="absolute inset-[40%] rounded-full border border-[#0A66FF]" />
        </motion.div>
      </div>

      {/* Hero Section - 80px top padding */}
      <section className="relative z-10" style={{ paddingTop: "80px", paddingBottom: "40px" }}>
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Side - Content */}
            <div className="space-y-6">
              {/* Back to About Button - Outlined, Minimum 44px tap area */}
              <motion.a
                href="#about"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 bg-white border-2 rounded-full transition-all duration-300 hover:border-[#0A66FF] hover:text-[#0A66FF]"
                style={{
                  paddingLeft: "20px",
                  paddingRight: "24px",
                  minHeight: "44px",
                  fontSize: "15px",
                  fontWeight: 500,
                  color: "#4D5565",
                  borderColor: "#E4E9F2",
                  fontFamily: "Inter, sans-serif"
                }}
              >
                <ArrowLeft className="size-4" strokeWidth={2.5} />
                <span>Back to About</span>
              </motion.a>

              {/* Tab Badge - "Our People" */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "10px 18px",
                  borderRadius: "12px",
                  backgroundColor: "rgba(26, 115, 232, 0.12)",
                  border: "1px solid #E2E6EF",
                }}
              >
                <div 
                  style={{ 
                    width: "6px",
                    height: "6px",
                    borderRadius: "50%",
                    backgroundColor: "#1A73E8"
                  }} 
                />
                <span 
                  style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 500,
                    color: "#1A73E8"
                  }}
                >
                  Our People
                </span>
              </motion.div>

              {/* Main Title - 56px, Inter Bold, -2% tracking */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h1 
                  style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "clamp(40px, 4vw, 56px)",
                    fontWeight: 800,
                    letterSpacing: "-0.02em",
                    lineHeight: "1.1",
                    color: "#141B34"
                  }}
                >
                  Our Team
                </h1>
              </motion.div>

              {/* Subtitle - 18px, Inter Regular, 400 weight, max 700px */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                style={{ 
                  fontFamily: "Inter, sans-serif",
                  fontSize: "18px",
                  lineHeight: "1.6",
                  fontWeight: 400,
                  maxWidth: "700px",
                  color: "#4D5565"
                }}
              >
                Meet the dedicated professionals driving excellence at TN AutoSkills. Our team combines deep industry expertise with a passion for automotive skill development, working together to empower the next generation of automotive professionals.
              </motion.p>
            </div>

            {/* Right Side - Abstract Transparent Automotive Rings */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative hidden lg:block h-[450px]"
            >
              {/* Minimal Elegant Ring Pattern */}
              <div className="absolute inset-0 flex items-center justify-center">
                {/* Outer Ring - Transparent Border */}
                <motion.div
                  animate={{ 
                    rotate: [0, 360],
                  }}
                  transition={{ 
                    rotate: { duration: 45, repeat: Infinity, ease: "linear" }
                  }}
                  className="absolute w-[420px] h-[420px] rounded-full"
                  style={{
                    border: "2px solid rgba(10, 102, 255, 0.08)",
                  }}
                >
                  {/* Decorative Dots */}
                  {[0, 90, 180, 270].map((angle, i) => (
                    <div
                      key={i}
                      className="absolute w-3 h-3 rounded-full"
                      style={{
                        background: "linear-gradient(135deg, #0A66FF 0%, #004FCC 100%)",
                        opacity: 0.15,
                        top: `${50 + 48 * Math.sin((angle * Math.PI) / 180)}%`,
                        left: `${50 + 48 * Math.cos((angle * Math.PI) / 180)}%`,
                        transform: "translate(-50%, -50%)"
                      }}
                    />
                  ))}
                </motion.div>

                {/* Middle Ring */}
                <motion.div
                  animate={{ 
                    rotate: [360, 0],
                  }}
                  transition={{ 
                    rotate: { duration: 35, repeat: Infinity, ease: "linear" }
                  }}
                  className="absolute w-[320px] h-[320px] rounded-full"
                  style={{
                    border: "1px solid rgba(10, 102, 255, 0.1)",
                  }}
                />

                {/* Inner Ring */}
                <motion.div
                  animate={{ 
                    scale: [1, 1.05, 1],
                  }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute w-[220px] h-[220px] rounded-full"
                  style={{
                    border: "2px solid rgba(10, 102, 255, 0.06)",
                    background: "radial-gradient(circle, rgba(10, 102, 255, 0.02) 0%, transparent 70%)"
                  }}
                />

                {/* Center Dot */}
                <div 
                  className="absolute w-16 h-16 rounded-full"
                  style={{
                    background: "linear-gradient(135deg, #0A66FF 0%, #004FCC 100%)",
                    opacity: 0.08
                  }}
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Team Members Grid Section - 48px spacing from hero */}
      <section className="relative z-10" style={{ paddingTop: "48px", paddingBottom: "80px" }}>
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          {/* Grid: 3 columns desktop (360px cards), 2 tablet, 1 mobile */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <TeamMemberCard
                key={member.name}
                name={member.name}
                designation={member.designation}
                image={member.image}
                index={index}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
