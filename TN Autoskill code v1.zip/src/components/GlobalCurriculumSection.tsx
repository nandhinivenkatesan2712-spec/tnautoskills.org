import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Zap, Leaf, Cpu, Car } from "lucide-react";

const frameworks = [
  {
    icon: Zap,
    title: "EV Framework",
    description:
      "Comprehensive training in electric vehicle technology, battery management systems, charging infrastructure, and EV diagnostics.",
    color: "from-blue-500 to-cyan-500",
  },
  {
    icon: Leaf,
    title: "Green & Flexi Fuel Framework",
    description:
      "Training on alternative fuels, green technologies, flex-fuel vehicles, and sustainable automotive solutions.",
    color: "from-green-500 to-emerald-500",
  },
  {
    icon: Cpu,
    title: "Software-Defined Vehicle Framework",
    description:
      "Focus on automotive software, vehicle networking, ADAS, autonomous systems, and digital automotive technologies.",
    color: "from-purple-500 to-indigo-500",
  },
  {
    icon: Car,
    title: "Vehicle Architecture Framework",
    description:
      "In-depth understanding of vehicle design, chassis systems, powertrain architecture, and modern automotive engineering.",
    color: "from-orange-500 to-red-500",
  },
];

export function GlobalCurriculumSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
            <div className="size-2 bg-[#0066FF] rounded-full animate-pulse" />
            <span className="text-sm font-semibold text-[#0066FF]">
              Global Standards
            </span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
            Global Automotive Curriculum Framework
          </h2>

          <p className="text-lg lg:text-xl text-[#64748b] max-w-3xl mx-auto">
            Internationally aligned training frameworks covering emerging automotive technologies and industry standards
          </p>
        </motion.div>

        {/* Framework Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {frameworks.map((framework, index) => {
            const IconComponent = framework.icon;
            return (
              <motion.div
                key={framework.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group bg-white rounded-3xl overflow-hidden border-2 border-gray-100 hover:border-[#0066FF]/30 shadow-lg hover:shadow-2xl transition-all"
              >
                {/* Card Header with Gradient */}
                <div className={`bg-gradient-to-br ${framework.color} p-8 relative overflow-hidden`}>
                  <div className="absolute top-0 right-0 size-40 bg-white/10 rounded-full -translate-y-20 translate-x-20" />
                  <div className="absolute bottom-0 left-0 size-32 bg-black/10 rounded-full translate-y-16 -translate-x-16" />
                  
                  <div className="relative flex items-center gap-4">
                    <div className="size-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                      <IconComponent className="size-8 text-white" strokeWidth={2} />
                    </div>
                    <h3 className="text-2xl font-extrabold text-white leading-tight">
                      {framework.title}
                    </h3>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-8">
                  <p className="text-base lg:text-lg text-[#64748b] leading-relaxed">
                    {framework.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom Info Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-12 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-2xl p-8 text-center"
        >
          <h3 className="text-2xl font-bold text-white mb-3">
            Aligned with Global Industry Standards
          </h3>
          <p className="text-white/90 text-lg">
            Our curriculum frameworks are developed in collaboration with leading automotive OEMs and international training organizations
          </p>
        </motion.div>
      </div>
    </section>
  );
}
