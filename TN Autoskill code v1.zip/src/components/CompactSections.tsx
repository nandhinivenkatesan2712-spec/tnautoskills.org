import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  ArrowRight,
  Target,
  Users,
  Award,
  TrendingUp,
  GraduationCap,
  Wrench,
  Briefcase,
  Handshake,
  Building2,
  BookOpen,
  Zap,
  Shield,
  CheckCircle,
  Car,
  Leaf,
  Cpu,
  Layers,
  Quote,
  ChevronRight,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// 1. WHO WE ARE - Compact Two-Column Layout
export function WhoWeAreCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-[60%_40%] gap-8 lg:gap-12 items-center">
          {/* Left - Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="space-y-5"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10">
              <div className="size-1.5 bg-[#0066FF] rounded-full" />
              <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">About Us</span>
            </div>

            <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] leading-tight">
              Who We Are
            </h2>

            <p className="text-base lg:text-lg text-[#0A0A0A]/80 leading-relaxed">
              <strong className="text-[#0A0A0A]">TN Auto Skills</strong> is a government initiative focused on developing industry-ready automotive talent across Tamil Nadu.
            </p>

            {/* Bullet Points */}
            <ul className="space-y-3">
              {[
                "Advanced, job-oriented training programs aligned with modern automobile technologies",
                "Bridge the skill gap and empower youth with hands-on learning",
                "Strong industry partnerships for career opportunities and internships",
                "Continuous upskilling and real-world expertise development",
              ].map((point, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.1 + index * 0.1 }}
                  className="flex items-start gap-3"
                >
                  <CheckCircle className="size-5 text-[#0066FF] flex-shrink-0 mt-0.5" />
                  <span className="text-sm lg:text-base text-[#0A0A0A]/70">{point}</span>
                </motion.li>
              ))}
            </ul>

            <motion.a
              href="#about"
              whileHover={{ x: 5 }}
              className="inline-flex items-center gap-2 text-[#0066FF] font-semibold text-sm hover:gap-3 transition-all"
            >
              <span>Read More</span>
              <ArrowRight className="size-4" />
            </motion.a>
          </motion.div>

          {/* Right - Small Image */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-lg border border-gray-100">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=600&h=400&fit=crop"
                alt="Automotive training facility"
                className="w-full h-[320px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0066FF]/20 to-transparent" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// 2. EXPLORE WHAT WE ARE DOING - Compact 4-Card Grid
export function ExploreWhatWeDoCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const services = [
    {
      icon: GraduationCap,
      title: "Industry-Aligned Training",
      description: "Government-certified automotive programs based on evolving industry standards.",
    },
    {
      icon: Wrench,
      title: "Hands-On Workshops",
      description: "Practical sessions with advanced labs and real-world automotive tools.",
    },
    {
      icon: Briefcase,
      title: "Career & Placement",
      description: "Placement support with leading companies, counseling, and interview prep.",
    },
    {
      icon: Handshake,
      title: "Industry Partnerships",
      description: "Collaborate with OEMs, suppliers, and institutions to build workforce.",
    },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-[#F3F6F9]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0066FF]/10 mb-4">
            <div className="size-1.5 bg-[#0066FF] rounded-full" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Our Services</span>
          </div>

          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Explore What We Are Doing
          </h2>

          <p className="text-sm lg:text-base text-[#0A0A0A]/60 max-w-2xl mx-auto">
            Comprehensive programs designed to develop automotive talent and bridge the industry skill gap
          </p>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4, scale: 1.02 }}
                className="group bg-white rounded-xl p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                <div className="size-12 bg-[#0066FF]/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#0066FF] transition-colors">
                  <IconComponent className="size-6 text-[#0066FF] group-hover:text-white transition-colors" />
                </div>
                <h3 className="font-bold text-[#0A0A0A] mb-2 text-base">
                  {service.title}
                </h3>
                <p className="text-xs text-[#0A0A0A]/60 leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 3. EMPOWERING STAKEHOLDERS - Compact 4 Cards
export function EmpoweringStakeholdersCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const stakeholders = [
    {
      icon: Users,
      title: "Candidates",
      description: "Access government-certified training, hands-on skills, and direct placement opportunities.",
    },
    {
      icon: Building2,
      title: "Industry",
      description: "Partner with us to build a skilled workforce aligned with your technology needs.",
    },
    {
      icon: BookOpen,
      title: "Academia",
      description: "Collaborate on curriculum development and provide students with industry exposure.",
    },
    {
      icon: Award,
      title: "Trainers & Assessors",
      description: "Join our network of certified professionals delivering world-class training.",
    },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10 mb-4">
            <div className="size-1.5 bg-[#0066FF] rounded-full" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Stakeholders</span>
          </div>

          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A]">
            Empowering Every Stakeholder
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {stakeholders.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-gradient-to-br from-[#F3F6F9] to-white rounded-xl p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-md transition-all"
              >
                <div className="size-12 bg-[#0066FF] rounded-lg flex items-center justify-center mb-4">
                  <IconComponent className="size-6 text-white" />
                </div>
                <h3 className="font-bold text-[#0A0A0A] mb-2 text-base">
                  {item.title}
                </h3>
                <p className="text-xs text-[#0A0A0A]/60 leading-relaxed">
                  {item.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 4. FEATURED TRAINING PROGRAMS - Compact 3-Column
export function FeaturedProgramsCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const programs = [
    {
      image: "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=400&h=300&fit=crop",
      badge: "EV",
      title: "Electric Vehicle Technology",
      description: "Learn EV systems, battery tech, and charging infrastructure.",
    },
    {
      image: "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400&h=300&fit=crop",
      badge: "Core",
      title: "Automotive Service Technician",
      description: "Master vehicle diagnostics, repair, and maintenance.",
    },
    {
      image: "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d6?w=400&h=300&fit=crop",
      badge: "Advanced",
      title: "Connected Vehicle Systems",
      description: "Explore IoT, telematics, and smart vehicle technology.",
    },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-[#F3F6F9]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0066FF]/10 mb-4">
            <div className="size-1.5 bg-[#0066FF] rounded-full" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Programs</span>
          </div>

          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Featured Training Programs
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {programs.map((program, index) => (
            <motion.div
              key={program.title}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -4 }}
              className="group bg-white rounded-xl overflow-hidden border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
            >
              <div className="relative h-40">
                <ImageWithFallback
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute top-3 left-3 px-3 py-1 bg-[#0066FF] text-white text-xs font-bold rounded-full">
                  {program.badge}
                </div>
              </div>
              <div className="p-5">
                <h3 className="font-bold text-[#0A0A0A] mb-2">
                  {program.title}
                </h3>
                <p className="text-xs text-[#0A0A0A]/60 mb-3">
                  {program.description}
                </p>
                <a
                  href="#programs"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#0066FF] hover:gap-2 transition-all"
                >
                  <span>Learn More</span>
                  <ChevronRight className="size-3" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center"
        >
          <a
            href="#programs"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0066FF] text-white rounded-lg font-semibold text-sm hover:bg-[#0055EE] transition-colors"
          >
            <span>View All Programs</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 5. CENTRE OF EXCELLENCE - Compact Horizontal
export function CentreOfExcellenceCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-[45%_55%] gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="relative rounded-2xl overflow-hidden shadow-lg"
          >
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1581092918484-8313e1f7e8d6?w=700&h=500&fit=crop"
              alt="Centre of Excellence facilities"
              className="w-full h-[350px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0066FF]/30 to-transparent" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-4"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10">
              <div className="size-1.5 bg-[#0066FF] rounded-full" />
              <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Facilities</span>
            </div>

            <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] leading-tight">
              Centre of Excellence
            </h2>

            <p className="text-base text-[#0A0A0A]/70 leading-relaxed">
              State-of-the-art training facilities equipped with modern automotive technologies, advanced diagnostic tools, and industry-standard equipment to provide hands-on learning experiences.
            </p>

            <ul className="space-y-2">
              {[
                "Advanced EV & Hybrid Vehicle Labs",
                "Smart Connected Vehicle Workshop",
                "Modern Diagnostic Equipment",
                "Industry-Standard Tools & Technology",
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-2 text-sm text-[#0A0A0A]/70">
                  <CheckCircle className="size-4 text-[#0066FF]" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>

            <a
              href="#facilities"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#0066FF] text-white rounded-lg font-semibold text-sm hover:bg-[#0055EE] transition-colors"
            >
              <span>Explore Facilities</span>
              <ArrowRight className="size-4" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// 6. GLOBAL CURRICULUM - Compact Card Layout
export function GlobalCurriculumCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const frameworks = [
    { icon: Zap, title: "EV Framework", description: "Electric vehicle training modules" },
    { icon: Leaf, title: "Green/Flexi Fuel", description: "Sustainable automotive technologies" },
    { icon: Cpu, title: "SDV Framework", description: "Software-defined vehicle systems" },
    { icon: Layers, title: "Vehicle Architecture", description: "Modern automotive design principles" },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-[#F3F6F9]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0066FF]/10 mb-4">
            <div className="size-1.5 bg-[#0066FF] rounded-full" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Curriculum</span>
          </div>

          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Global Automotive Curriculum Framework
          </h2>

          <p className="text-sm lg:text-base text-[#0A0A0A]/60 max-w-3xl mx-auto mb-8">
            Our training programs are based on internationally recognized automotive curriculum standards, ensuring students learn cutting-edge technologies and industry best practices.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {frameworks.map((framework, index) => {
            const IconComponent = framework.icon;
            return (
              <motion.div
                key={framework.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-white rounded-xl p-5 border border-[#0066FF]/20 hover:border-[#0066FF]/50 hover:shadow-md transition-all"
              >
                <div className="size-10 bg-[#0066FF]/10 rounded-lg flex items-center justify-center mb-3">
                  <IconComponent className="size-5 text-[#0066FF]" />
                </div>
                <h3 className="font-bold text-[#0A0A0A] text-sm mb-1">
                  {framework.title}
                </h3>
                <p className="text-xs text-[#0A0A0A]/60">
                  {framework.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 7. ZERO FATALITIES - Compact Impact Summary
export function ZeroFatalitiesCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-[40%_60%] gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-lg border border-[#0066FF]/10">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=600&h=400&fit=crop"
                alt="Road safety initiative"
                className="w-full h-[280px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0066FF]/40 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <div className="text-4xl font-extrabold text-white mb-1">2030</div>
                <div className="text-sm font-semibold text-white/90">Zero Fatalities Goal</div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-4"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10">
              <Shield className="size-3 text-[#0066FF]" />
              <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Road Safety</span>
            </div>

            <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] leading-tight">
              Zero Fatalities by 2030
            </h2>

            <p className="text-base text-[#0A0A0A]/70 leading-relaxed">
              We are committed to achieving the UN's Sustainable Development Goal of reducing road traffic deaths and injuries through comprehensive safety training and awareness programs.
            </p>

            <ul className="space-y-2">
              {[
                "Advanced vehicle safety systems training",
                "Driver behavior and road safety education",
                "Emergency response and first aid certification",
                "Preventive maintenance and vehicle inspection standards",
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-2 text-sm text-[#0A0A0A]/70">
                  <CheckCircle className="size-4 text-[#0066FF]" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>

            <a
              href="#safety"
              className="inline-flex items-center gap-2 text-[#0066FF] font-semibold text-sm hover:gap-3 transition-all"
            >
              <span>Learn More</span>
              <ArrowRight className="size-4" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// 8. MILESTONES - Compact Stats Row
export function MilestonesCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const stats = [
    { icon: Users, value: "2500+", label: "Students Trained" },
    { icon: Award, value: "500+", label: "Certified Professionals" },
    { icon: Briefcase, value: "200+", label: "Placements" },
    { icon: Building2, value: "40+", label: "Industry Partners" },
    { icon: Target, value: "95%", label: "Success Rate" },
    { icon: TrendingUp, value: "10+", label: "Training Centers" },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl lg:text-4xl font-extrabold text-white mb-2">
            Our Milestones
          </h2>
          <p className="text-sm text-white/80">
            Transforming automotive education across Tamil Nadu
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-md rounded-xl p-5 border border-white/20 text-center"
              >
                <div className="inline-flex items-center justify-center size-10 bg-white/20 rounded-lg mb-3">
                  <IconComponent className="size-5 text-white" />
                </div>
                <div className="text-3xl font-extrabold text-white mb-1">
                  {stat.value}
                </div>
                <div className="text-xs text-white/80 font-semibold">
                  {stat.label}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 9. SUCCESS STORIES - Compact Card Slider
export function SuccessStoriesCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const stories = [
    {
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
      name: "Rajesh Kumar",
      role: "EV Technician at Ather Energy",
      quote: "The hands-on training I received helped me secure my dream job in the EV industry.",
    },
    {
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop",
      name: "Priya Sharma",
      role: "Automotive Engineer at Hyundai",
      quote: "TN Auto Skills provided me with industry-relevant skills and direct placement support.",
    },
    {
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop",
      name: "Arjun Patel",
      role: "Service Manager at TVS Motors",
      quote: "The certification program opened doors to leadership roles in the automotive sector.",
    },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-[#F3F6F9]">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0066FF]/10 mb-4">
            <div className="size-1.5 bg-[#0066FF] rounded-full" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Testimonials</span>
          </div>

          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A]">
            Success Stories
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stories.map((story, index) => (
            <motion.div
              key={story.name}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -4 }}
              className="bg-white rounded-xl p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
            >
              <Quote className="size-8 text-[#0066FF]/20 mb-4" />
              <p className="text-sm text-[#0A0A0A]/70 mb-6 italic leading-relaxed">
                "{story.quote}"
              </p>
              <div className="flex items-center gap-4">
                <div className="size-12 rounded-full overflow-hidden border-2 border-[#0066FF]/20">
                  <ImageWithFallback
                    src={story.image}
                    alt={story.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="font-bold text-[#0A0A0A] text-sm">{story.name}</div>
                  <div className="text-xs text-[#0A0A0A]/60">{story.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// 10. PARTNERS - Compact Logo Grid
export function PartnersCompact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const partners = [
    "Hyundai", "Maruti Suzuki", "Tata Motors", "TVS Motors",
    "Ashok Leyland", "Royal Enfield", "Ather Energy", "Ola Electric"
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10 mb-4">
            <div className="size-1.5 bg-[#0066FF] rounded-full" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wide">Partnerships</span>
          </div>

          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A]">
            Our Partners
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4"
        >
          {partners.map((partner, index) => (
            <motion.div
              key={partner}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              className="bg-[#F3F6F9] rounded-lg p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-md transition-all flex items-center justify-center"
            >
              <div className="text-center">
                <Building2 className="size-8 text-[#0066FF]/40 mx-auto mb-2" />
                <div className="font-bold text-[#0A0A0A] text-sm">{partner}</div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
