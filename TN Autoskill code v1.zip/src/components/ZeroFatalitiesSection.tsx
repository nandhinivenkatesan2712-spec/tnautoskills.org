import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Shield, GraduationCap, Ambulance, TrendingDown, Target, Users } from "lucide-react";

export function ZeroFatalitiesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    {
      icon: Shield,
      title: "Advanced Safety Systems",
      description: "Training on cutting-edge vehicle safety technologies and collision prevention systems",
      bgColor: "bg-blue-50",
      iconColor: "text-blue-600",
    },
    {
      icon: GraduationCap,
      title: "Driver Education",
      description: "Comprehensive driver training programs focusing on defensive driving and road awareness",
      bgColor: "bg-teal-50",
      iconColor: "text-teal-600",
    },
    {
      icon: Ambulance,
      title: "Emergency Response",
      description: "First-aid and emergency response training for rapid accident management",
      bgColor: "bg-purple-50",
      iconColor: "text-purple-600",
    },
  ];

  const metrics = [
    {
      icon: TrendingDown,
      value: "50%",
      label: "Target Reduction",
    },
    {
      icon: Target,
      value: "2030",
      label: "Road Safety Goal",
    },
    {
      icon: Users,
      value: "100+",
      label: "Partners",
    },
  ];

  return (
    <section 
      ref={ref} 
      className="py-16 lg:py-20 bg-gradient-to-b from-blue-50/40 via-white to-white relative overflow-hidden"
    >
      {/* Soft Background Decoration */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 right-20 size-96 bg-blue-100 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Compact Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 max-w-2xl mx-auto"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3 leading-tight">
            Zero Fatalities by 2030
          </h2>
          <p className="text-base text-[#64748b] leading-relaxed">
            Building safer roads through comprehensive training, technology adoption,
            <br className="hidden sm:inline" />
            and emergency preparedness across Tamil Nadu
          </p>
        </motion.div>

        {/* Feature Cards - Horizontal Layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-5 mb-10">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4, boxShadow: "0 12px 24px rgba(0, 0, 0, 0.08)" }}
                className={`${feature.bgColor} rounded-2xl p-6 border border-white/60 shadow-sm hover:shadow-md transition-all duration-300`}
              >
                <div className={`size-12 ${feature.bgColor.replace('50', '100')} rounded-xl flex items-center justify-center mb-4`}>
                  <IconComponent className={`size-6 ${feature.iconColor}`} strokeWidth={2} />
                </div>
                <h3 className="text-lg font-bold text-[#0A0A0A] mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-[#64748b] leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Modern Metrics Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6"
        >
          <div className="grid grid-cols-3 divide-x divide-gray-200">
            {metrics.map((metric, index) => {
              const IconComponent = metric.icon;
              return (
                <motion.div
                  key={metric.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
                  className="text-center px-4"
                >
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <IconComponent className="size-5 text-[#004ABB]" strokeWidth={2} />
                    <div className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A]">
                      {metric.value}
                    </div>
                  </div>
                  <div className="text-xs lg:text-sm text-[#64748b] font-medium">
                    {metric.label}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
