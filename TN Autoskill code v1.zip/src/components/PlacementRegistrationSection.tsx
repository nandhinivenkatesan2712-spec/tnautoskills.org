import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight, FileText, CheckCircle2, Users, Building } from "lucide-react";

export function PlacementRegistrationSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: Form Preview */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="bg-white rounded-3xl p-8 lg:p-12 shadow-2xl border-2 border-gray-100"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="size-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl flex items-center justify-center">
                <Building className="size-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-extrabold text-[#0A0A0A]">
                  College Registration
                </h3>
                <p className="text-sm text-[#64748b]">For Placement Support</p>
              </div>
            </div>

            {/* Form Preview */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-[#0A0A0A] mb-2">
                  College Name
                </label>
                <div className="w-full h-12 bg-gray-50 rounded-lg border-2 border-gray-200" />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#0A0A0A] mb-2">
                  Contact Person
                </label>
                <div className="w-full h-12 bg-gray-50 rounded-lg border-2 border-gray-200" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-[#0A0A0A] mb-2">
                    Email
                  </label>
                  <div className="w-full h-12 bg-gray-50 rounded-lg border-2 border-gray-200" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#0A0A0A] mb-2">
                    Phone
                  </label>
                  <div className="w-full h-12 bg-gray-50 rounded-lg border-2 border-gray-200" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#0A0A0A] mb-2">
                  Number of Students
                </label>
                <div className="w-full h-12 bg-gray-50 rounded-lg border-2 border-gray-200" />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#0A0A0A] mb-2">
                  Upload Student List
                </label>
                <div className="w-full h-24 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center">
                  <div className="text-center">
                    <FileText className="size-8 text-gray-400 mx-auto mb-2" />
                    <span className="text-sm text-[#64748b]">
                      Drop files or click to upload
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right: Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
              <Users className="size-4 text-[#0066FF]" />
              <span className="text-sm font-semibold text-[#0066FF]">
                For Colleges
              </span>
            </div>

            <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
              Placement Registration
            </h2>

            <p className="text-lg lg:text-xl text-[#64748b] mb-8 leading-relaxed">
              Register your students for comprehensive placement support and career opportunities in the automotive sector.
            </p>

            {/* Benefits */}
            <div className="space-y-4 mb-8">
              {[
                "Direct access to automotive industry recruiters",
                "Pre-placement training and skill enhancement",
                "Interview preparation and soft skills development",
                "On-campus recruitment drive coordination",
                "Continuous placement support and tracking",
              ].map((benefit, index) => (
                <motion.div
                  key={benefit}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                  className="flex items-start gap-3"
                >
                  <div className="size-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 className="size-4 text-green-600" />
                  </div>
                  <span className="text-sm lg:text-base text-[#475569]">
                    {benefit}
                  </span>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-base shadow-xl hover:shadow-2xl transition-all"
            >
              <span>Register College Now</span>
              <ArrowRight className="size-5" />
            </motion.button>

            {/* Stats */}
            <div className="mt-8 grid grid-cols-3 gap-4">
              {[
                { value: "200+", label: "Placements" },
                { value: "40+", label: "Companies" },
                { value: "100%", label: "Support" },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-3xl font-extrabold text-[#0066FF] mb-1">
                    {stat.value}
                  </div>
                  <div className="text-xs text-[#64748b] font-medium">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
