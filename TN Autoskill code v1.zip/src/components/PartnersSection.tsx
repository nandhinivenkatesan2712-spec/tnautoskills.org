import { motion, useInView } from "motion/react";
import { useRef } from "react";

const partners = [
  { name: "Tata Motors", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
  { name: "Hyundai", logo: "https://images.unsplash.com/photo-1617886903355-9354bb57751f?w=200&h=100&fit=crop" },
  { name: "Mahindra", logo: "https://images.unsplash.com/photo-1617788138017-743c61bbe7e0?w=200&h=100&fit=crop" },
  { name: "Ashok Leyland", logo: "https://images.unsplash.com/photo-1611348586804-61bf6c080437?w=200&h=100&fit=crop" },
  { name: "TVS Motors", logo: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=200&h=100&fit=crop" },
  { name: "Hero MotoCorp", logo: "https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=200&h=100&fit=crop" },
  { name: "Bosch", logo: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=200&h=100&fit=crop" },
  { name: "Continental", logo: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=200&h=100&fit=crop" },
];

export function PartnersSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000008_1px,transparent_1px),linear-gradient(to_bottom,#00000008_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-30" />

      <div className="relative max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
            <div className="size-2 bg-[#0066FF] rounded-full animate-pulse" />
            <span className="text-sm font-semibold text-[#0066FF]">
              Industry Partnerships
            </span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
            Our Partners
          </h2>

          <p className="text-lg lg:text-xl text-[#64748b] max-w-3xl mx-auto">
            Collaborating with leading automotive OEMs, suppliers, and industry leaders
          </p>
        </motion.div>

        {/* Partners Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8 mb-12">
          {partners.map((partner, index) => (
            <motion.div
              key={partner.name}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-white rounded-2xl p-6 lg:p-8 flex items-center justify-center border-2 border-gray-100 hover:border-[#0066FF]/30 shadow-md hover:shadow-xl transition-all group"
            >
              <div className="w-full h-16 flex items-center justify-center">
                <img
                  src={partner.logo}
                  alt={partner.name}
                  className="max-w-full max-h-full object-contain grayscale group-hover:grayscale-0 transition-all"
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Stats Banner */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-3xl p-8 lg:p-12"
        >
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "40+", label: "Industry Partners" },
              { value: "35+", label: "Active MoUs" },
              { value: "2500+", label: "Students Trained" },
              { value: "100%", label: "Placement Support" },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.5 + index * 0.1 }}
              >
                <div className="text-4xl lg:text-5xl font-extrabold text-white mb-2">
                  {stat.value}
                </div>
                <div className="text-sm lg:text-base text-white/90 font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
