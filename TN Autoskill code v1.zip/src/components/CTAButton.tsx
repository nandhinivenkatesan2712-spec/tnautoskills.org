import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";
import { ReactNode } from "react";

interface CTAButtonProps {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "primary" | "secondary";
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function CTAButton({
  children,
  href,
  onClick,
  variant = "primary",
  size = "md",
  className = "",
}: CTAButtonProps) {
  const baseStyles = "inline-flex items-center justify-center font-semibold rounded-xl transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2";
  
  const sizeStyles = {
    sm: "px-5 py-2.5 text-sm min-h-[40px] gap-2",
    md: "px-6 py-3 text-base min-h-[44px] gap-2",
    lg: "px-8 py-4 text-lg min-h-[48px] gap-2",
  };

  const variantStyles = {
    primary: "bg-[#0066FF] text-white hover:bg-[#0052CC] shadow-md hover:shadow-lg focus:ring-[#0066FF]/50",
    secondary: "bg-white border-[1.5px] border-[#0066FF] text-[#0066FF] hover:bg-blue-50 shadow-sm hover:shadow-md focus:ring-[#0066FF]/30",
  };

  const combinedStyles = `${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`;

  const content = (
    <>
      <span>{children}</span>
      <ArrowRight className="size-4 flex-shrink-0 group-hover:translate-x-1 transition-transform" strokeWidth={2} />
    </>
  );

  if (href) {
    return (
      <motion.a
        href={href}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
        className={`group ${combinedStyles}`}
      >
        {content}
      </motion.a>
    );
  }

  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      className={`group ${combinedStyles}`}
    >
      {content}
    </motion.button>
  );
}
