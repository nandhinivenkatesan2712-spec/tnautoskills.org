import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { CheckCircle2, Zap, Cpu, Car, Gauge } from "lucide-react";
import { CTAButton } from "./CTAButton";

const facilities = [
  {
    icon: Zap,
    title: "Electric Vehicle Lab",
    description: "State-of-the-art EV testing and development facility",
  },
  {
    icon: Cpu,
    title: "Advanced Simulation Lab",
    description: "Virtual testing environment with industry-grade software",
  },
  {
    icon: Car,
    title: "Robotics & Automation Center",
    description: "Hands-on training with cutting-edge robotic systems",
  },
  {
    icon: Gauge,
    title: "Vehicle Dynamics Testing",
    description: "Professional-grade testing and diagnostic equipment",
  },
];

export function CentreOfExcellence() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="pt-20 pb-14 bg-gradient-to-br from-[#F3F6F9] to-white relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-[#004ABB] rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#0055DD] rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-[1440px] mx-auto px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="w-24 h-1 bg-gradient-to-r from-[#004ABB] to-[#0055DD] rounded-full mx-auto mb-8" />
          <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
            Centre of Excellence
          </h2>
          <p className="text-lg xl:text-xl text-[#475569] max-w-3xl mx-auto">
            World-class infrastructure and cutting-edge facilities for automotive training
          </p>
        </motion.div>

        <div className="grid grid-cols-12 gap-12 items-center">
          {/* Left Side - Infographic Illustration */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="col-span-12 lg:col-span-6"
          >
            <div className="relative">
              {/* Main Container */}
              <div className="relative bg-gradient-to-br from-[#004ABB]/10 to-[#0055DD]/10 rounded-3xl p-12 backdrop-blur-sm border border-white/50">
                {/* 3D Shape Elements */}
                <motion.div
                  animate={{
                    y: [0, -20, 0],
                    rotate: [0, 5, 0],
                  }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="absolute top-8 right-8 w-24 h-24 bg-gradient-to-br from-[#004ABB] to-[#003D99] rounded-2xl shadow-2xl opacity-80"
                  style={{ transform: "perspective(1000px) rotateX(20deg) rotateY(-20deg)" }}
                />
                
                <motion.div
                  animate={{
                    y: [0, 20, 0],
                    rotate: [0, -5, 0],
                  }}
                  transition={{
                    duration: 7,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="absolute bottom-8 left-8 w-32 h-32 bg-gradient-to-br from-[#0055DD] to-[#004ABB] rounded-full shadow-2xl opacity-70"
                />

                {/* Lab Icons Grid */}
                <div className="relative grid grid-cols-2 gap-8 z-10">
                  {facilities.map((facility, index) => {
                    const Icon = facility.icon;
                    return (
                      <motion.div
                        key={facility.title}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={isInView ? { opacity: 1, scale: 1 } : {}}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                        whileHover={{ scale: 1.05, y: -5 }}
                        className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all"
                      >
                        <div className="size-14 bg-gradient-to-br from-[#004ABB] to-[#0055DD] rounded-xl flex items-center justify-center mb-4">
                          <Icon className="size-7 text-white" strokeWidth={2} />
                        </div>
                        <h4 className="text-[#0b1220] font-bold text-sm mb-1">
                          {facility.title.split(' ')[0]}
                        </h4>
                        <p className="text-[#64748b] text-xs leading-relaxed">
                          Lab
                        </p>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Floating Badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="absolute -top-6 -right-6 bg-white rounded-2xl px-6 py-4 shadow-2xl border-2 border-[#004ABB]/20"
              >
                <div className="flex items-center gap-3">
                  <div className="size-12 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
                    <CheckCircle2 className="size-6 text-white" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-[#0b1220]">100%</div>
                    <div className="text-xs text-[#64748b]">Modern</div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Right Side - Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="col-span-12 lg:col-span-6 space-y-6"
          >
            {/* Accent Line */}
            <div className="w-16 h-1 bg-gradient-to-r from-[#004ABB] to-[#0055DD] rounded-full" />

            {/* Heading */}
            <h2 className="text-[#0b1220] text-4xl lg:text-5xl xl:text-6xl font-extrabold leading-tight">
              Centre of Excellence
            </h2>

            {/* Description */}
            <p className="text-[#475569] text-lg lg:text-xl leading-relaxed">
              Our world-class facilities combine cutting-edge technology with
              hands-on learning experiences, preparing students for the future of
              automotive innovation.
            </p>

            {/* Facilities List */}
            <div className="space-y-3 pt-2">
              {facilities.map((facility, index) => {
                const Icon = facility.icon;
                return (
                  <motion.div
                    key={facility.title}
                    initial={{ opacity: 0, x: 20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                    className="flex items-start gap-4 group cursor-pointer"
                  >
                    <div className="size-12 bg-gradient-to-br from-[#004ABB]/10 to-[#0055DD]/10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <Icon className="size-6 text-[#004ABB]" strokeWidth={2} />
                    </div>
                    <div>
                      <h3 className="text-[#0b1220] text-lg font-bold mb-1 group-hover:text-[#004ABB] transition-colors">
                        {facility.title}
                      </h3>
                      <p className="text-[#64748b] leading-relaxed">
                        {facility.description}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* CTA Button */}
            <CTAButton href="#facilities" variant="primary" size="lg">
              Explore Facilities
            </CTAButton>
          </motion.div>
        </div>
      </div>
    </section>
  );
}