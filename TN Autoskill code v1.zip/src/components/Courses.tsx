import { motion, useScroll, useTransform, useInView } from "motion/react";
import { useRef, useState } from "react";
import { 
  ArrowRight, 
  Search,
  Clock, 
  Award, 
  Battery, 
  Wrench, 
  Car, 
  Users,
  Shield,
  Wifi,
  Cpu,
  Bot,
  Package,
  CheckCircle2,
  Target,
  BookOpen,
  TrendingUp,
  Home,
  ChevronRight,
  GraduationCap,
  Briefcase,
  Zap
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { UnifiedBanner } from "./UnifiedBanner";

// Course data
const courses = [
  {
    id: 1,
    title: "Battery Electric Vehicle Technician",
    description: "Master EV technology, battery systems, diagnostics, and charging infrastructure maintenance",
    duration: "6 Months",
    level: "Advanced",
    category: "EV & Electric Mobility",
    image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800&h=600&fit=crop",
    icon: Battery,
  },
  {
    id: 2,
    title: "Automotive Service Technician",
    description: "Comprehensive automotive diagnostics, repair, and maintenance training for modern vehicles",
    duration: "5 Months",
    level: "Intermediate",
    category: "Automotive Service",
    image: "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=800&h=600&fit=crop",
    icon: Wrench,
  },
  {
    id: 3,
    title: "CNC Machine Operator",
    description: "Learn precision manufacturing, CNC programming, and advanced machining operations",
    duration: "3 Months",
    level: "Intermediate",
    category: "Manufacturing & Assembly",
    image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800&h=600&fit=crop",
    icon: Package,
  },
  {
    id: 4,
    title: "Automotive Sales Consultant",
    description: "Sales strategies, customer service excellence, and automotive business fundamentals",
    duration: "2 Months",
    level: "Beginner",
    category: "Management & Soft Skills",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=600&fit=crop",
    icon: Users,
  },
  {
    id: 5,
    title: "Assembly Operator",
    description: "Production line assembly, quality control, and manufacturing best practices",
    duration: "2 Months",
    level: "Beginner",
    category: "Manufacturing & Assembly",
    image: "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=800&h=600&fit=crop",
    icon: Package,
  },
  {
    id: 6,
    title: "Internet of Things (IoT) Fundamentals",
    description: "Connected vehicles, IoT sensors, data analytics, and smart mobility solutions",
    duration: "3 Months",
    level: "Advanced",
    category: "IoT / AI / Robotics",
    image: "https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?w=800&h=600&fit=crop",
    icon: Wifi,
  },
  {
    id: 7,
    title: "Robotics & Cobotics",
    description: "Industrial robotics, collaborative robots, and automation systems in manufacturing",
    duration: "4 Months",
    level: "Advanced",
    category: "IoT / AI / Robotics",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&h=600&fit=crop",
    icon: Bot,
  },
  {
    id: 8,
    title: "HMV / LMV Driving Training",
    description: "Professional driving certification for Heavy and Light Motor Vehicles",
    duration: "1 Month",
    level: "Beginner",
    category: "Automotive Service",
    image: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=800&h=600&fit=crop",
    icon: Car,
  },
  {
    id: 9,
    title: "3-Wheeler Driver Upskilling",
    description: "Specialized training for 3-wheeler operation, maintenance, and safety protocols",
    duration: "3 Weeks",
    level: "Beginner",
    category: "Automotive Service",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=600&fit=crop",
    icon: Car,
  },
  {
    id: 10,
    title: "Safety & Hazard Management",
    description: "Workplace safety, hazard identification, emergency response, and compliance training",
    duration: "1 Month",
    level: "Beginner",
    category: "Safety & Compliance",
    image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800&h=600&fit=crop",
    icon: Shield,
  },
];

const categories = [
  "All",
  "EV & Electric Mobility",
  "Automotive Service",
  "Manufacturing & Assembly",
  "Safety & Compliance",
  "IoT / AI / Robotics",
  "Management & Soft Skills",
];

const levelColors = {
  Beginner: "bg-green-500",
  Intermediate: "bg-yellow-500",
  Advanced: "bg-red-500",
};

const whyChoosePoints = [
  {
    icon: Target,
    title: "Industry-Aligned Curriculum",
    description: "Courses designed with input from leading automotive manufacturers"
  },
  {
    icon: Zap,
    title: "Hands-On Training Labs",
    description: "State-of-the-art facilities with real-world equipment and simulations"
  },
  {
    icon: GraduationCap,
    title: "Certified Instructors",
    description: "Learn from industry experts with years of practical experience"
  },
  {
    icon: Briefcase,
    title: "Placement Support",
    description: "Direct connections to automotive industry leaders and job opportunities"
  }
];

export function Courses() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const whyChooseRef = useRef(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const isWhyChooseInView = useInView(whyChooseRef, { once: true, margin: "-100px" });

  const { scrollYProgress } = useScroll({
    target: ctaRef,
    offset: ["start end", "end start"]
  });

  const ctaY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);

  // Filter courses
  const filteredCourses = courses.filter(course => {
    const matchesCategory = activeCategory === "All" || course.category === activeCategory;
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          course.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="bg-white">
      {/* Unified Banner */}
      <UnifiedBanner
        title="Courses & Training Programs"
        subtitle="Explore industry-aligned skill development programs designed for the automotive future"
        badge={
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/90 backdrop-blur-md rounded-2xl shadow-lg border border-gray-100">
            <BookOpen className="size-8 text-[#0066FF]" />
            <div className="text-left">
              <div className="text-sm font-bold text-[#0A0A0A]">10 Courses Available</div>
              <div className="text-xs text-[#64748b]">All Categories</div>
            </div>
          </div>
        }
      />

      {/* Filters & Search */}
      <div className="sticky top-[68px] z-40 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-[1440px] mx-auto px-8 py-4">
          {/* Search Bar */}
          <div className="mb-4">
            <div className="relative max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#475569]" />
              <input
                type="text"
                placeholder="Search for a course…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white border-2 border-gray-200 rounded-xl text-sm focus:outline-none focus:border-[#0066FF] transition-colors min-h-[44px]"
              />
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex gap-3 overflow-x-auto scrollbar-hide">
            {categories.map((category) => (
              <motion.button
                key={category}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-2.5 rounded-full font-semibold text-sm whitespace-nowrap transition-all min-h-[44px] ${
                  activeCategory === category
                    ? "bg-[#0066FF] text-white shadow-lg"
                    : "bg-gray-100 text-[#475569] hover:bg-gray-200"
                }`}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Course Cards Grid */}
      <section className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] mb-3">
              {activeCategory === "All" ? "All Courses" : activeCategory}
            </h2>
            <p className="text-base text-[#475569]">
              {filteredCourses.length} course{filteredCourses.length !== 1 ? "s" : ""} available
            </p>
          </motion.div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filteredCourses.map((course, index) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.08 }}
                whileHover={{ scale: 1.03, y: -8 }}
                className="bg-white rounded-2xl border border-gray-200 shadow-md hover:shadow-2xl transition-all overflow-hidden group cursor-pointer"
              >
                {/* Course Image */}
                <div className="relative h-48 overflow-hidden">
                  <ImageWithFallback
                    src={course.image}
                    alt={course.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  {/* Level Badge */}
                  <div className="absolute top-4 right-4 flex items-center gap-2 bg-white/95 backdrop-blur-md rounded-full px-3 py-1.5 shadow-md">
                    <div className={`size-2 rounded-full ${levelColors[course.level as keyof typeof levelColors]}`} />
                    <span className="text-xs font-bold text-[#0A0A0A]">{course.level}</span>
                  </div>

                  {/* Icon Badge */}
                  <div className="absolute bottom-4 left-4">
                    <div className="size-12 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl flex items-center justify-center shadow-lg">
                      <course.icon className="size-6 text-white" />
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-3">
                  <h3 className="text-lg font-bold text-[#0A0A0A] group-hover:text-[#0066FF] transition-colors leading-tight">
                    {course.title}
                  </h3>
                  
                  <p className="text-sm text-[#475569] leading-relaxed line-clamp-2">
                    {course.description}
                  </p>

                  {/* Duration */}
                  <div className="flex items-center gap-2 text-sm text-[#64748b]">
                    <Clock className="size-4 text-[#0066FF]" />
                    <span className="font-medium">{course.duration}</span>
                  </div>

                  {/* View Details Button */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full px-5 py-2.5 bg-[#0066FF] text-white rounded-xl font-semibold text-sm hover:bg-[#0090FF] transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 min-h-[44px]"
                  >
                    <span>View Details</span>
                    <ArrowRight className="size-4" />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>

          {/* No Results Message */}
          {filteredCourses.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-16"
            >
              <BookOpen className="size-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-[#0A0A0A] mb-2">No courses found</h3>
              <p className="text-[#475569]">Try adjusting your search or filter</p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Course Details Preview Block */}
      <section className="pt-20 pb-14 bg-[#F3F6F9]">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-white rounded-3xl shadow-2xl overflow-hidden"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              {/* Image Side */}
              <div className="relative h-64 lg:h-auto">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=1200&h=800&fit=crop"
                  alt="Featured Course"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-[#0066FF]/80 to-[#0090FF]/80" />
                
                {/* Floating Badge */}
                <div className="absolute top-6 left-6 bg-white rounded-2xl px-4 py-2 shadow-xl">
                  <div className="flex items-center gap-2">
                    <Award className="size-5 text-[#0066FF]" />
                    <span className="font-bold text-sm text-[#0A0A0A]">Featured Course</span>
                  </div>
                </div>
              </div>

              {/* Content Side */}
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <div className="mb-6">
                  <span className="inline-block px-4 py-1.5 bg-[#EEF5FF] text-[#0066FF] rounded-full text-xs font-bold mb-4">
                    🔋 EV Technology
                  </span>
                  <h3 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] mb-4">
                    Battery Electric Vehicle Technician
                  </h3>
                  <p className="text-base text-[#475569] leading-relaxed mb-6">
                    Become a certified EV technician with comprehensive training in battery systems, 
                    power electronics, charging infrastructure, and advanced diagnostics. Gain hands-on 
                    experience with cutting-edge electric vehicle technology.
                  </p>
                </div>

                {/* Outcomes */}
                <div className="space-y-3 mb-8">
                  {[
                    "Master EV battery management systems",
                    "Learn charging infrastructure installation",
                    "Industry-recognized certification",
                    "Direct placement opportunities"
                  ].map((outcome, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle2 className="size-5 text-[#0066FF] flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-[#475569]">{outcome}</span>
                    </div>
                  ))}
                </div>

                {/* Enroll Button */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-[#0066FF] text-white rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl hover:bg-[#0090FF] transition-all min-h-[44px] flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  <span>Enroll Now</span>
                  <ArrowRight className="size-5" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Why Choose TN AutoSkills */}
      <section ref={whyChooseRef} className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isWhyChooseInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-8" />
            <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
              Why Choose TN AutoSkills?
            </h2>
            <p className="text-lg xl:text-xl text-[#475569] max-w-3xl mx-auto">
              Excellence in automotive education and skill development
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChoosePoints.map((point, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                animate={isWhyChooseInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className="bg-gradient-to-br from-[#F8FBFF] to-[#EEF5FF] rounded-2xl p-6 border border-gray-200 hover:shadow-xl transition-all"
              >
                <div className="size-14 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                  <point.icon className="size-7 text-white" />
                </div>
                <h3 className="text-lg font-bold text-[#0A0A0A] mb-3">
                  {point.title}
                </h3>
                <p className="text-sm text-[#475569] leading-relaxed">
                  {point.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Enroll CTA Section with Parallax */}
      <section 
        ref={ctaRef}
        className="relative pt-20 pb-14 bg-gradient-to-br from-[#0066FF] to-[#0090FF] overflow-hidden"
      >
        {/* Parallax Background */}
        <motion.div 
          style={{ y: ctaY }}
          className="absolute inset-0"
        >
          {/* Decorative Grid Pattern */}
          <div className="absolute inset-0 opacity-10">
            <svg className="w-full h-full" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100" height="100" fill="url(#grid)" />
            </svg>
          </div>

          {/* Decorative Shapes */}
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            className="absolute top-10 right-10 w-64 h-64 border-4 border-white/10 rounded-full"
          />
          <motion.div
            animate={{ rotate: [0, -360] }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
            className="absolute bottom-10 left-10 w-80 h-80 border-4 border-white/10 rounded-3xl"
          />
        </motion.div>

        <div className="relative z-10 max-w-[1440px] mx-auto px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl lg:text-6xl font-extrabold text-white mb-6">
              Ready to Build Your Automotive Career?
            </h2>
            
            <p className="text-xl lg:text-2xl text-white/90 max-w-3xl mx-auto mb-12">
              Join thousands of successful graduates and start your journey in the automotive industry today
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white text-[#0066FF] rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl transition-all min-h-[44px] flex items-center gap-2"
              >
                <span>Enroll Now</span>
                <ArrowRight className="size-5" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-transparent border-2 border-white text-white rounded-2xl font-semibold text-base hover:bg-white hover:text-[#0066FF] transition-all shadow-lg min-h-[44px] flex items-center gap-2"
              >
                <Users className="size-5" />
                <span>Talk to Us</span>
              </motion.button>
            </div>

            {/* Trust Indicators */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mt-16 max-w-4xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="text-center"
              >
                <TrendingUp className="size-12 text-white mx-auto mb-3" />
                <div className="text-4xl font-extrabold text-white mb-2">10+</div>
                <div className="text-white/80">Skill Development Courses</div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-center"
              >
                <Award className="size-12 text-white mx-auto mb-3" />
                <div className="text-4xl font-extrabold text-white mb-2">100%</div>
                <div className="text-white/80">Industry-Aligned Training</div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="text-center"
              >
                <CheckCircle2 className="size-12 text-white mx-auto mb-3" />
                <div className="text-4xl font-extrabold text-white mb-2">2,242+</div>
                <div className="text-white/80">Trained Professionals</div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}