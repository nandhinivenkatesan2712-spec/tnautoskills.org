import { motion, useScroll, useTransform, useInView } from "motion/react";
import { useRef, useState } from "react";
import { 
  ArrowRight, 
  Award, 
  Briefcase,
  GraduationCap,
  Building2,
  Users,
  Play,
  Quote,
  TrendingUp,
  Target,
  CheckCircle2,
  MapPin,
  Calendar
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { UnifiedBanner } from "./UnifiedBanner";

// Success story data
const successStories = [
  {
    id: 1,
    name: "Rajesh Kumar",
    role: "Automotive Service Technician",
    placement: "Hyundai Motor India",
    location: "Chennai",
    category: "Students",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=800&fit=crop",
    shortStory: "From unemployed graduate to lead technician at Hyundai in just 6 months",
    fullStory: "After completing my degree, I struggled to find meaningful employment. TN AutoSkills' comprehensive EV training program gave me the practical skills and industry certification I needed. Within 3 months of graduation, I was hired by Hyundai Motor India.",
    year: "2024"
  },
  {
    id: 2,
    name: "Priya Sharma",
    role: "Battery Management Specialist",
    placement: "Ola Electric",
    location: "Bangalore",
    category: "Students",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&h=800&fit=crop",
    shortStory: "Transitioned from traditional automotive to cutting-edge EV technology",
    fullStory: "Working in traditional automotive for 5 years, I wanted to future-proof my career. The Battery Management course opened doors to the EV sector. Now I'm part of India's electric mobility revolution at Ola Electric.",
    year: "2024"
  },
  {
    id: 3,
    name: "Mohamed Ali",
    role: "CNC Machine Operator",
    placement: "Tata Motors",
    location: "Pune",
    category: "Students",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=800&h=800&fit=crop",
    shortStory: "Upskilled from basic manufacturing to precision CNC operations",
    fullStory: "I started as a general assembly operator with limited skills. The CNC training program transformed my career trajectory. Today, I operate advanced CNC machines at Tata Motors with a 60% salary increase.",
    year: "2023"
  },
  {
    id: 4,
    name: "Anitha Devi",
    role: "Automotive Sales Consultant",
    placement: "Mahindra & Mahindra",
    location: "Coimbatore",
    category: "Students",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=800&h=800&fit=crop",
    shortStory: "Became top sales consultant within first year of training",
    fullStory: "With no prior automotive background, the sales consultant program gave me product knowledge and customer relationship skills. I'm now a certified sales professional at Mahindra, consistently exceeding targets.",
    year: "2023"
  },
  {
    id: 5,
    name: "Karthik Raj",
    role: "Robotics Technician",
    placement: "Maruti Suzuki",
    location: "Manesar",
    category: "Students",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800&h=800&fit=crop",
    shortStory: "Mastered advanced robotics and automation systems",
    fullStory: "The Robotics & Cobotics program prepared me for Industry 4.0. I now maintain and program collaborative robots on Maruti's production line, working with cutting-edge automation technology.",
    year: "2024"
  },
  {
    id: 6,
    name: "Lakshmi Narayanan",
    role: "EV Charging Infrastructure Engineer",
    placement: "Tata Power",
    location: "Mumbai",
    category: "Students",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&h=800&fit=crop",
    shortStory: "Building India's EV charging network after comprehensive training",
    fullStory: "From electrical engineering graduate to EV infrastructure specialist. The program gave me expertise in charging station installation, grid integration, and smart mobility solutions.",
    year: "2024"
  }
];

const industryPartners = [
  {
    name: "Hyundai Motor India",
    logo: "Building2",
    quote: "TN AutoSkills graduates consistently demonstrate exceptional technical competence and workplace readiness. They've become invaluable members of our service teams.",
    person: "Regional HR Manager",
    impact: "65+ placements"
  },
  {
    name: "Ola Electric",
    logo: "Building2",
    quote: "The EV-focused curriculum aligns perfectly with our needs. These graduates understand battery technology and modern electric powertrains from day one.",
    person: "Head of Training & Development",
    impact: "40+ placements"
  },
  {
    name: "Tata Motors",
    logo: "Building2",
    quote: "Our partnership with TN AutoSkills ensures a steady pipeline of skilled technicians and engineers. The practical training methodology produces job-ready talent.",
    person: "Chief People Officer",
    impact: "80+ placements"
  }
];

const filterCategories = ["All", "Students", "Industry Partners", "Academia", "Trainers"];

const videoTestimonials = [
  {
    id: 1,
    thumbnail: "https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=1200&h=800&fit=crop",
    title: "From Classroom to Career: Rajesh's Journey",
    duration: "3:45",
    category: "Student Success"
  },
  {
    id: 2,
    thumbnail: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=1200&h=800&fit=crop",
    title: "Industry Partnership: Hyundai's Perspective",
    duration: "4:20",
    category: "Industry Partner"
  },
  {
    id: 3,
    thumbnail: "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=1200&h=800&fit=crop",
    title: "EV Revolution: Priya's Transition Story",
    duration: "2:50",
    category: "Student Success"
  }
];

export function SuccessStoriesPage() {
  const [activeFilter, setActiveFilter] = useState("All");
  const [currentPartnerIndex, setCurrentPartnerIndex] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const featuredRef = useRef(null);
  const videoRef = useRef(null);
  const partnerRef = useRef(null);
  
  const isFeaturedInView = useInView(featuredRef, { once: true, margin: "-100px" });
  const isVideoInView = useInView(videoRef, { once: true, margin: "-100px" });
  const isPartnerInView = useInView(partnerRef, { once: true, margin: "-100px" });

  const { scrollYProgress: heroScrollProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const { scrollYProgress: ctaScrollProgress } = useScroll({
    target: ctaRef,
    offset: ["start end", "end start"]
  });

  const heroY = useTransform(heroScrollProgress, [0, 1], ["0%", "30%"]);
  const ctaY = useTransform(ctaScrollProgress, [0, 1], ["0%", "20%"]);

  // Filter stories
  const filteredStories = activeFilter === "All" 
    ? successStories 
    : successStories.filter(story => story.category === activeFilter);

  // Featured story (first one)
  const featuredStory = successStories[0];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-[70vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#0A0A0A] via-[#1a1a2e] to-[#0A0A0A]">
        {/* Animated Background */}
        <motion.div 
          style={{ y: heroY }}
          className="absolute inset-0"
        >
          {/* Engine Blueprint Lines */}
          <motion.div
            animate={{
              backgroundPosition: ["0% 0%", "100% 100%"],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%230066FF' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
              backgroundSize: "60px 60px",
            }}
          />

          {/* Gradient Orbs */}
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#0066FF] rounded-full blur-3xl"
          />
          <motion.div
            animate={{
              scale: [1.2, 1, 1.2],
              opacity: [0.2, 0.4, 0.2],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#0090FF] rounded-full blur-3xl"
          />
        </motion.div>

        {/* Content */}
        <div className="relative z-10 max-w-[1440px] mx-auto px-8 py-20 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-8" />
            
            <h1 className="text-5xl lg:text-7xl font-extrabold text-white mb-6">
              Success Stories
            </h1>
            
            <p className="text-xl lg:text-2xl text-white/80 max-w-4xl mx-auto mb-12">
              Real journeys of students, professionals, and institutions transformed by TN AutoSkills
            </p>

            {/* Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
              {[
                { value: "2,242+", label: "Success Stories", icon: TrendingUp },
                { value: "95%", label: "Placement Rate", icon: Target },
                { value: "213", label: "Industry Partners", icon: Building2 }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                  className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20"
                >
                  <stat.icon className="size-8 text-[#0090FF] mx-auto mb-3" />
                  <div className="text-3xl font-extrabold text-white mb-1">{stat.value}</div>
                  <div className="text-sm text-white/70">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Bottom Fade */}
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-white to-transparent pointer-events-none" />
      </section>

      {/* Filter Bar */}
      <div className="sticky top-[68px] z-40 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-[1440px] mx-auto px-8 py-4">
          <div className="flex gap-3 overflow-x-auto scrollbar-hide">
            {filterCategories.map((category) => (
              <motion.button
                key={category}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveFilter(category)}
                className={`px-6 py-2.5 rounded-full font-semibold text-sm whitespace-nowrap transition-all min-h-[44px] ${
                  activeFilter === category
                    ? "bg-[#0066FF] text-white shadow-lg"
                    : "bg-gray-100 text-[#475569] hover:bg-gray-200"
                }`}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Featured Success Story */}
      <section ref={featuredRef} className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isFeaturedInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <span className="inline-block px-4 py-2 bg-[#EEF5FF] text-[#0066FF] rounded-full text-sm font-bold mb-4">
              ⭐ Featured Success Story
            </span>
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A]">
              Transforming Lives, One Story at a Time
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isFeaturedInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-gradient-to-br from-[#F8FBFF] to-[#EEF5FF] rounded-3xl shadow-2xl overflow-hidden border border-gray-200"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              {/* Image Side */}
              <div className="relative h-96 lg:h-auto">
                <ImageWithFallback
                  src={featuredStory.image}
                  alt={featuredStory.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                
                {/* Floating Badge */}
                <div className="absolute bottom-6 left-6 bg-white rounded-2xl px-5 py-3 shadow-xl">
                  <div className="flex items-center gap-3">
                    <Award className="size-6 text-[#0066FF]" />
                    <div>
                      <div className="font-bold text-sm text-[#0A0A0A]">{featuredStory.year} Graduate</div>
                      <div className="text-xs text-[#475569]">Success Story</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Content Side */}
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <div className="mb-6">
                  <h3 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] mb-3">
                    {featuredStory.name}
                  </h3>
                  <div className="flex flex-wrap gap-3 mb-4">
                    <div className="flex items-center gap-2 text-sm text-[#475569]">
                      <Briefcase className="size-4 text-[#0066FF]" />
                      <span className="font-semibold">{featuredStory.role}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#475569]">
                      <Building2 className="size-4 text-[#0066FF]" />
                      <span>{featuredStory.placement}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#475569]">
                      <MapPin className="size-4 text-[#0066FF]" />
                      <span>{featuredStory.location}</span>
                    </div>
                  </div>
                  <p className="text-xl font-bold text-[#0066FF] mb-4">
                    "{featuredStory.shortStory}"
                  </p>
                  <p className="text-base text-[#475569] leading-relaxed mb-6">
                    {featuredStory.fullStory}
                  </p>
                </div>

                {/* Read Full Story Button */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-[#0066FF] text-white rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl hover:bg-[#0090FF] transition-all min-h-[44px] flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  <span>Read Full Story</span>
                  <ArrowRight className="size-5" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Success Story Grid */}
      <section className="pt-20 pb-14 bg-[#F3F6F9]">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-8" />
            <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
              More Success Stories
            </h2>
            <p className="text-lg text-[#475569]">
              {filteredStories.length - 1} inspiring journeys
            </p>
          </motion.div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filteredStories.slice(1).map((story, index) => (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.08 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="bg-white rounded-2xl shadow-md hover:shadow-2xl transition-all overflow-hidden group cursor-pointer"
              >
                {/* Image */}
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback
                    src={story.image}
                    alt={story.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
                  
                  {/* Year Badge */}
                  <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-md rounded-full px-3 py-1.5 shadow-md flex items-center gap-1.5">
                    <Calendar className="size-3.5 text-[#0066FF]" />
                    <span className="text-xs font-bold text-[#0A0A0A]">{story.year}</span>
                  </div>

                  {/* Name at bottom */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-xl font-bold text-white mb-1">{story.name}</h3>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-[#475569]">
                      <Briefcase className="size-4 text-[#0066FF] flex-shrink-0" />
                      <span className="font-semibold line-clamp-1">{story.role}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#475569]">
                      <Building2 className="size-4 text-[#0066FF] flex-shrink-0" />
                      <span className="line-clamp-1">{story.placement}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#475569]">
                      <MapPin className="size-4 text-[#0066FF] flex-shrink-0" />
                      <span>{story.location}</span>
                    </div>
                  </div>

                  <p className="text-sm text-[#475569] leading-relaxed line-clamp-2">
                    {story.shortStory}
                  </p>

                  {/* Read More Link */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full px-5 py-2.5 bg-[#0066FF] text-white rounded-xl font-semibold text-sm hover:bg-[#0090FF] transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 min-h-[44px]"
                  >
                    <span>Read More</span>
                    <ArrowRight className="size-4" />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Video Testimonials Section */}
      <section ref={videoRef} className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isVideoInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-8" />
            <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
              Watch Their Experience
            </h2>
            <p className="text-lg text-[#475569]">
              Hear directly from our graduates and industry partners
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {videoTestimonials.map((video, index) => (
              <motion.div
                key={video.id}
                initial={{ opacity: 0, y: 50 }}
                animate={isVideoInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className="group cursor-pointer"
              >
                <div className="relative rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all">
                  {/* Thumbnail */}
                  <ImageWithFallback
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full aspect-video object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />

                  {/* Play Button */}
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
                  >
                    <div className="size-16 bg-white rounded-full flex items-center justify-center shadow-2xl">
                      <Play className="size-8 text-[#0066FF] ml-1" fill="#0066FF" />
                    </div>
                  </motion.div>

                  {/* Duration Badge */}
                  <div className="absolute top-4 right-4 bg-black/80 backdrop-blur-md rounded-full px-3 py-1.5">
                    <span className="text-xs font-bold text-white">{video.duration}</span>
                  </div>

                  {/* Bottom Info */}
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <span className="inline-block px-3 py-1 bg-[#0066FF]/90 backdrop-blur-md text-white rounded-full text-xs font-bold mb-2">
                      {video.category}
                    </span>
                    <h3 className="text-base font-bold text-white leading-tight">
                      {video.title}
                    </h3>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Partner Impact Stories */}
      <section ref={partnerRef} className="pt-20 pb-14 bg-[#F3F6F9]">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isPartnerInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-8" />
            <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
              Industry Partner Impact
            </h2>
            <p className="text-lg text-[#475569]">
              What our industry collaborators say about TN AutoSkills graduates
            </p>
          </motion.div>

          {/* Partner Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-8">
            {industryPartners.map((partner, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                animate={isPartnerInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all"
              >
                {/* Logo */}
                <div className="size-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                  <Building2 className="size-8 text-white" />
                </div>

                {/* Quote */}
                <Quote className="size-10 text-[#0066FF]/20 mb-4" />
                <p className="text-base text-[#475569] leading-relaxed mb-6 italic">
                  "{partner.quote}"
                </p>

                {/* Attribution */}
                <div className="border-t border-gray-200 pt-4">
                  <div className="font-bold text-sm text-[#0A0A0A] mb-1">{partner.name}</div>
                  <div className="text-xs text-[#64748b] mb-3">{partner.person}</div>
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#EEF5FF] rounded-full">
                    <CheckCircle2 className="size-4 text-[#0066FF]" />
                    <span className="text-xs font-bold text-[#0066FF]">{partner.impact}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isPartnerInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-center"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-[#0066FF] text-white rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl hover:bg-[#0090FF] transition-all min-h-[44px] inline-flex items-center gap-2"
            >
              <span>Explore Industry Collaborations</span>
              <ArrowRight className="size-5" />
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* CTA Block with Parallax */}
      <section 
        ref={ctaRef}
        className="relative pt-20 pb-14 bg-gradient-to-br from-[#0066FF] to-[#0090FF] overflow-hidden"
      >
        {/* Parallax Background */}
        <motion.div 
          style={{ y: ctaY }}
          className="absolute inset-0"
        >
          {/* Decorative Grid */}
          <div className="absolute inset-0 opacity-10">
            <svg className="w-full h-full" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="success-grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100" height="100" fill="url(#success-grid)" />
            </svg>
          </div>

          {/* Decorative Shapes */}
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            className="absolute top-10 right-10 w-64 h-64 border-4 border-white/10 rounded-full"
          />
          <motion.div
            animate={{ rotate: [0, -360] }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
            className="absolute bottom-10 left-10 w-80 h-80 border-4 border-white/10 rounded-3xl"
          />
        </motion.div>

        <div className="relative z-10 max-w-[1440px] mx-auto px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl lg:text-6xl font-extrabold text-white mb-6">
              Your Success Starts Here
            </h2>
            
            <p className="text-xl lg:text-2xl text-white/90 max-w-3xl mx-auto mb-12">
              Join thousands of learners building future-ready automotive careers
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <motion.button
                onClick={() => window.location.hash = "apply"}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white text-[#0066FF] rounded-2xl font-semibold shadow-lg hover:shadow-2xl transition-all flex items-center gap-2"
              >
                <GraduationCap className="size-5" />
                <span>Apply Now</span>
              </motion.button>
            </div>

            {/* Success Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 max-w-5xl mx-auto">
              {[
                { icon: Users, value: "2,242+", label: "Graduates Placed" },
                { icon: Building2, value: "213", label: "Partner Companies" },
                { icon: Award, value: "95%", label: "Success Rate" },
                { icon: TrendingUp, value: "60%", label: "Avg. Salary Increase" }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <stat.icon className="size-10 text-white mx-auto mb-3" />
                  <div className="text-3xl font-extrabold text-white mb-1">{stat.value}</div>
                  <div className="text-sm text-white/80">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}