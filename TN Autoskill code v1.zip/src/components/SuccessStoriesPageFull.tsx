import { UnifiedBanner } from "./UnifiedBanner";
import { SuccessStoriesSection } from "./SuccessStoriesSection";

export function SuccessStoriesPageFull() {
  return (
    <div className="bg-white">
      <UnifiedBanner
        title="Success Stories"
        subtitle="Inspiring journeys of our alumni who transformed their careers through our programs"
        badge={
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/95 backdrop-blur-sm rounded-full shadow-md border border-[#0066FF]/20">
            <div className="size-2 bg-[#0066FF] rounded-full animate-pulse" />
            <span className="text-sm font-semibold text-[#0A0A0A]">
              Alumni Stories
            </span>
          </div>
        }
      />
      <SuccessStoriesSection />
    </div>
  );
}
