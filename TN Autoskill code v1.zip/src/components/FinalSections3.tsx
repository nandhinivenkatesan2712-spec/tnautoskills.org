import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import {
  Quote,
  ChevronLeft,
  ChevronRight,
  Building2,
  ArrowRight,
  CheckCircle,
  Cog,
  ShoppingCart,
  Lightbulb,
  UserPlus,
  Heart,
  GraduationCap,
  BookOpen,
  Users,
  Briefcase,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// SECTION 9 — Success Stories (Carousel)
export function FinalSuccessStories() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [currentIndex, setCurrentIndex] = useState(0);

  const stories = [
    {
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop",
      name: "Rajesh Kumar",
      role: "EV Technician",
      company: "Ather Energy",
      quote: "The hands-on training I received helped me secure my dream job in the EV industry.",
    },
    {
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&h=300&fit=crop",
      name: "Priya Sharma",
      role: "Automotive Engineer",
      company: "Hyundai",
      quote: "TN Auto Skills provided me with industry-relevant skills and direct placement support.",
    },
    {
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&h=300&fit=crop",
      name: "Arjun Patel",
      role: "Service Manager",
      company: "TVS Motors",
      quote: "The certification program opened doors to leadership roles in the automotive sector.",
    },
  ];

  const next = () => setCurrentIndex((prev) => (prev + 1) % stories.length);
  const prev = () => setCurrentIndex((prev) => (prev - 1 + stories.length) % stories.length);

  return (
    <section ref={ref} className="py-15 bg-gradient-to-b from-white to-[#F8FAFB]">
      <div className="max-w-5xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Success Stories
          </h2>
          <p className="text-lg text-[#64748B]">Hear from our graduates</p>
        </motion.div>

        {/* Carousel Container */}
        <div className="relative">
          {/* Testimonial Card */}
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-[24px] p-10 shadow-xl border border-gray-100"
          >
            <div className="flex flex-col md:flex-row gap-8 items-center">
              {/* Photo */}
              <div className="flex-shrink-0">
                <div className="size-32 rounded-full overflow-hidden border-4 border-[#0066FF]/20 shadow-lg">
                  <ImageWithFallback
                    src={stories[currentIndex].image}
                    alt={stories[currentIndex].name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 text-center md:text-left">
                <Quote className="size-10 text-[#0066FF]/30 mb-4" />
                <p className="text-lg text-[#475569] italic mb-6 leading-relaxed">
                  "{stories[currentIndex].quote}"
                </p>
                <div>
                  <div className="font-bold text-xl text-[#0A0A0A]">{stories[currentIndex].name}</div>
                  <div className="text-sm text-[#64748B]">{stories[currentIndex].role}</div>
                  <div className="text-sm text-[#0066FF] font-semibold">{stories[currentIndex].company}</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Arrow Controls */}
          <div className="flex gap-3 justify-center mt-8">
            <button
              onClick={prev}
              className="size-12 bg-white border border-gray-200 rounded-full flex items-center justify-center hover:bg-[#0066FF] hover:text-white hover:border-[#0066FF] transition-all shadow-md"
            >
              <ChevronLeft className="size-6" />
            </button>
            <button
              onClick={next}
              className="size-12 bg-white border border-gray-200 rounded-full flex items-center justify-center hover:bg-[#0066FF] hover:text-white hover:border-[#0066FF] transition-all shadow-md"
            >
              <ChevronRight className="size-6" />
            </button>
          </div>

          {/* Indicators */}
          <div className="flex gap-2 justify-center mt-4">
            {stories.map((_, idx) => (
              <div
                key={idx}
                className={`h-2 rounded-full transition-all ${
                  idx === currentIndex ? "w-8 bg-[#0066FF]" : "w-2 bg-gray-300"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// SECTION 10 — Our Partners (Auto-scroll Logo Carousel)
export function FinalPartners() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const partners = [
    "Hyundai", "Maruti Suzuki", "Tata Motors", "TVS Motors",
    "Ashok Leyland", "Royal Enfield", "Ather Energy", "Ola Electric"
  ];

  return (
    <section ref={ref} className="py-15 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Our Partners
          </h2>
          <p className="text-lg text-[#64748B]">Trusted by leading automotive companies</p>
        </motion.div>

        {/* Logo Grid with Hover */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {partners.map((partner, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              whileHover={{ scale: 1.08 }}
              className="bg-gray-50 rounded-[20px] p-8 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all flex items-center justify-center"
            >
              <div className="text-center">
                <Building2 className="size-10 text-[#0066FF] mx-auto mb-2" strokeWidth={1.5} />
                <div className="font-bold text-sm text-[#0A0A0A]">{partner}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION 11 — Empanelment (3-column grid)
export function FinalEmpanelment() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const categories = [
    {
      icon: Building2,
      title: "OEMs",
      subtitle: "Original Equipment Manufacturers",
      points: [
        "Workforce development programs",
        "Specialized training modules",
        "Access to skilled talent pool",
      ],
    },
    {
      icon: Cog,
      title: "Auto Suppliers",
      subtitle: "Component Manufacturers",
      points: [
        "Technical skill training",
        "Competency development",
        "Quality assurance training",
      ],
    },
    {
      icon: ShoppingCart,
      title: "Retail Partners",
      subtitle: "Service Networks",
      points: [
        "Service technician training",
        "Customer service modules",
        "After-sales support",
      ],
    },
    {
      icon: Lightbulb,
      title: "Startups",
      subtitle: "Innovation Hubs",
      points: [
        "EV and new mobility training",
        "Technology integration",
        "R&D collaboration",
      ],
    },
  ];

  return (
    <section ref={ref} className="py-15 bg-gradient-to-b from-[#F8FAFB] to-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Empanelment Opportunities
          </h2>
          <p className="text-lg text-[#64748B] max-w-3xl mx-auto">
            Join our network of industry partners
          </p>
        </motion.div>

        {/* 2x2 Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-10">
          {categories.map((category, idx) => {
            const Icon = category.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="bg-white rounded-[20px] p-7 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-xl transition-all"
              >
                {/* Icon & Title */}
                <div className="flex items-start gap-4 mb-5">
                  <div className="size-14 bg-gradient-to-br from-[#0066FF] to-[#00BCD4] rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Icon className="size-7 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl text-[#0A0A0A]">{category.title}</h3>
                    <p className="text-sm text-[#64748B]">{category.subtitle}</p>
                  </div>
                </div>

                {/* Bullet Points */}
                <ul className="space-y-2 mb-5">
                  {category.points.map((point, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-[#475569]">
                      <CheckCircle className="size-4 text-[#0066FF] flex-shrink-0 mt-0.5" strokeWidth={2} />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <a
                  href="#empanelment"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[#0066FF] hover:gap-3 transition-all"
                >
                  <span>Apply Now</span>
                  <ArrowRight className="size-4" />
                </a>
              </motion.div>
            );
          })}
        </div>

        {/* Main CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#empanelment"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] text-white rounded-xl font-bold shadow-lg hover:shadow-xl hover:scale-105 transition-all"
          >
            <span>View All Opportunities</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 12 — HR Registration for Recruitment
export function FinalHRRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-15 bg-white">
      <div className="max-w-5xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="bg-gradient-to-br from-[#F0F9FF] to-[#F0FDFA] rounded-[24px] p-10 lg:p-12 border border-gray-100 shadow-lg"
        >
          <div className="grid lg:grid-cols-[60%_40%] gap-10 items-center">
            {/* Left — Text */}
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm mb-5">
                <UserPlus className="size-4 text-[#0066FF]" />
                <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Recruitment</span>
              </div>

              <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] mb-4">
                HR Registration for Recruitment
              </h2>

              <p className="text-base text-[#475569] leading-relaxed mb-6">
                Register your organization to access our pool of trained and certified automotive professionals.
              </p>

              <ul className="space-y-2">
                {[
                  "Access to 2500+ trained candidates",
                  "Industry-certified professionals",
                  "Streamlined recruitment process",
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-[#475569]">
                    <CheckCircle className="size-4 text-[#0066FF]" strokeWidth={2} />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Right — HR Illustration / CTA */}
            <div className="flex flex-col gap-3">
              <a
                href="#hr-register"
                className="px-7 py-4 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] text-white rounded-xl font-bold text-center shadow-lg hover:shadow-xl hover:scale-105 transition-all"
              >
                Register Now
              </a>
              <a
                href="#contact"
                className="px-7 py-4 bg-white border-2 border-[#0066FF] text-[#0066FF] rounded-xl font-bold text-center hover:bg-[#0066FF]/5 transition-all"
              >
                Contact Us
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 13 — CSR Projects
export function FinalCSRProjects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const projects = [
    {
      image: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=600&h=400&fit=crop",
      icon: Heart,
      title: "Community Skill Development",
      description: "Partner with us to provide free automotive training to underprivileged youth and create employment opportunities in rural Tamil Nadu.",
    },
    {
      image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=600&h=400&fit=crop",
      icon: GraduationCap,
      title: "Women in Automotive Initiative",
      description: "Support our program to train and empower women in automotive technology, breaking gender barriers in the industry.",
    },
  ];

  return (
    <section ref={ref} className="py-15 bg-gradient-to-b from-[#F8FAFB] to-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            CSR Projects
          </h2>
          <p className="text-lg text-[#64748B] max-w-3xl mx-auto">
            Collaborate with us on Corporate Social Responsibility initiatives
          </p>
        </motion.div>

        {/* Grid of CSR Initiatives */}
        <div className="grid md:grid-cols-2 gap-8 mb-10">
          {projects.map((project, idx) => {
            const Icon = project.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.2 }}
                whileHover={{ y: -6 }}
                className="group bg-white rounded-[24px] overflow-hidden border border-gray-100 hover:shadow-2xl transition-all"
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  {/* Icon */}
                  <div className="absolute top-6 left-6 size-14 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                    <Icon className="size-7 text-white" strokeWidth={2} />
                  </div>
                </div>

                {/* Content */}
                <div className="p-7">
                  <h3 className="text-2xl font-bold text-[#0A0A0A] mb-3">{project.title}</h3>
                  <p className="text-base text-[#475569] leading-relaxed">
                    {project.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#csr-register"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] text-white rounded-xl font-bold shadow-lg hover:shadow-xl hover:scale-105 transition-all"
          >
            <span>CSR Partnership Registration</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 14 — Academia & Alumni Support
export function FinalAcademiaAlumni() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const cards = [
    {
      icon: BookOpen,
      title: "Campus Support",
      description: "Curriculum co-development and faculty training",
    },
    {
      icon: Users,
      title: "Alumni Guidance",
      description: "Continuous upskilling and career advancement",
    },
    {
      icon: Briefcase,
      title: "Internship Pipelines",
      description: "Direct industry connections for students",
    },
    {
      icon: GraduationCap,
      title: "Placement Assistance",
      description: "100% placement support for graduates",
    },
  ];

  return (
    <section ref={ref} className="py-15 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Academia & Alumni Support
          </h2>
          <p className="text-lg text-[#64748B] max-w-3xl mx-auto">
            Bridging the gap between academic learning and industry requirements
          </p>
        </motion.div>

        {/* Compact Cards (2x2) */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {cards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="bg-gradient-to-br from-white to-gray-50 rounded-[20px] p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                <div className="size-12 bg-gradient-to-br from-[#0066FF] to-[#00BCD4] rounded-xl flex items-center justify-center mb-4 shadow-lg">
                  <Icon className="size-6 text-white" strokeWidth={2} />
                </div>
                <h3 className="font-bold text-lg text-[#0A0A0A] mb-2">{card.title}</h3>
                <p className="text-sm text-[#64748B]">{card.description}</p>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#academia"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] text-white rounded-xl font-bold shadow-lg hover:shadow-xl hover:scale-105 transition-all"
          >
            <span>Contact Academic Support</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 15 — Placement Registration
export function FinalPlacementRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-15 bg-gradient-to-b from-[#F8FAFB] to-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="bg-white rounded-[24px] p-10 lg:p-12 border border-gray-100 shadow-lg text-center"
        >
          <GraduationCap className="size-16 text-[#0066FF] mx-auto mb-6" strokeWidth={1.5} />

          <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] mb-4">
            Placement Registration
          </h2>

          <p className="text-base text-[#475569] leading-relaxed max-w-2xl mx-auto mb-8">
            Register your educational institution to enable your students to access placement opportunities with leading automotive companies through TN Auto Skills.
          </p>

          <a
            href="#placement-register"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] text-white rounded-xl font-bold shadow-lg hover:shadow-xl hover:scale-105 transition-all"
          >
            <span>Register Your Institution</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}