import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Zap, Cog, Bot, Smartphone, CheckCircle2 } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function PremiumCentreOfExcellence() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const labs = [
    {
      icon: Zap,
      title: "EV & Hybrid Simulation Labs",
      color: "from-blue-500/20 to-cyan-500/20",
      iconColor: "text-blue-500",
      glowColor: "group-hover:shadow-blue-500/20",
    },
    {
      icon: Cog,
      title: "BS6 Technology Lab",
      color: "from-emerald-500/20 to-teal-500/20",
      iconColor: "text-emerald-500",
      glowColor: "group-hover:shadow-emerald-500/20",
    },
    {
      icon: Bot,
      title: "Robotics & Automation Lab",
      color: "from-violet-500/20 to-purple-500/20",
      iconColor: "text-violet-500",
      glowColor: "group-hover:shadow-violet-500/20",
    },
    {
      icon: Smartphone,
      title: "Digital Mobility & Diagnostics Lab",
      color: "from-amber-500/20 to-orange-500/20",
      iconColor: "text-amber-500",
      glowColor: "group-hover:shadow-amber-500/20",
    },
  ];

  const capabilities = [
    "Real-time EV simulation",
    "Industry-aligned practical modules",
    "Hands-on diagnostics & testing",
    "OEM-supported training",
  ];

  return (
    <section ref={ref} className="relative py-20 bg-gradient-to-br from-gray-50 via-blue-50/30 to-white overflow-hidden">
      {/* Subtle Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 right-20 size-96 bg-blue-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 size-96 bg-violet-400/10 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Hero Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-[#0066FF]/10 rounded-full mb-4">
            <span className="text-sm font-semibold text-[#0066FF]">ADVANCED LEARNING</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Centre of Excellence (CoE)
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            End-to-end advanced learning labs for EV, BS6, Robotics, Automation & Mobility Tech.
          </p>
        </motion.div>

        {/* Horizontal Lab Cards - Frosted Glass Effect */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
          {labs.map((lab, idx) => {
            const Icon = lab.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className={`group relative bg-white/60 backdrop-blur-md border border-white/80 rounded-2xl p-6 hover:bg-gradient-to-br ${lab.color} hover:border-white hover:shadow-2xl ${lab.glowColor} hover:scale-105 transition-all duration-300 cursor-pointer`}
              >
                {/* Glassmorphism Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                <div className="relative">
                  {/* Icon */}
                  <div className="mb-4">
                    <div className="size-12 bg-gradient-to-br from-white to-gray-50 rounded-xl flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow duration-300">
                      <Icon className={`size-6 ${lab.iconColor}`} strokeWidth={2} />
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="font-semibold text-[15px] text-[#0A0A0A] leading-snug">
                    {lab.title}
                  </h3>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Split Layout: Image Left + Capabilities Right */}
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          {/* Left: Image Block */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl group">
              {/* Image Container */}
              <div className="aspect-[4/3] bg-gradient-to-br from-gray-100 to-gray-200">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80"
                  alt="EV and Robotics Lab"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>

              {/* Overlay Badge */}
              <div className="absolute bottom-6 left-6 right-6 bg-white/90 backdrop-blur-md rounded-2xl p-4 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="size-10 bg-[#0066FF]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Zap className="size-5 text-[#0066FF]" strokeWidth={2} />
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-[#0A0A0A]">
                      State-of-the-Art Facilities
                    </div>
                    <div className="text-xs text-[#64748B]">
                      Industry 4.0 Ready Infrastructure
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 size-24 bg-gradient-to-br from-blue-500/20 to-violet-500/20 rounded-full blur-2xl" />
            <div className="absolute -bottom-4 -left-4 size-24 bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 rounded-full blur-2xl" />
          </motion.div>

          {/* Right: Capabilities List */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="space-y-6"
          >
            <div>
              <h3 className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A] mb-3">
                Key Capabilities
              </h3>
              <p className="text-[15px] text-[#64748B] leading-relaxed">
                Our Centres of Excellence are equipped with cutting-edge technology and industry-standard equipment to provide world-class training.
              </p>
            </div>

            {/* Capability Cards */}
            <div className="space-y-3">
              {capabilities.map((capability, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.6 + idx * 0.1 }}
                  className="group flex items-start gap-4 bg-white/60 backdrop-blur-sm border border-gray-200/60 rounded-2xl p-4 hover:bg-gradient-to-r hover:from-blue-50/50 hover:to-transparent hover:border-blue-200/60 hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-300"
                >
                  <div className="flex-shrink-0 mt-0.5">
                    <div className="size-6 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <CheckCircle2 className="size-4 text-white" strokeWidth={2.5} />
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-[15px] text-[#0A0A0A] leading-relaxed">
                      {capability}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-4">
              <div className="bg-gradient-to-br from-blue-50 to-transparent rounded-xl p-4 border border-blue-100">
                <div className="text-2xl font-extrabold text-[#0066FF]">4</div>
                <div className="text-xs text-[#64748B] mt-1">Advanced Labs</div>
              </div>
              <div className="bg-gradient-to-br from-emerald-50 to-transparent rounded-xl p-4 border border-emerald-100">
                <div className="text-2xl font-extrabold text-emerald-600">1500+</div>
                <div className="text-xs text-[#64748B] mt-1">Students Trained</div>
              </div>
              <div className="bg-gradient-to-br from-violet-50 to-transparent rounded-xl p-4 border border-violet-100">
                <div className="text-2xl font-extrabold text-violet-600">100%</div>
                <div className="text-xs text-[#64748B] mt-1">Industry Ready</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
