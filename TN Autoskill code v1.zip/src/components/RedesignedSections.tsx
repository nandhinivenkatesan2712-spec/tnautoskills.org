import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import {
  ArrowRight,
  GraduationCap,
  Wrench,
  Briefcase,
  Users,
  TrendingUp,
  Handshake,
  CheckCircle,
  Zap,
  Cpu,
  Leaf,
  Layers,
  Shield,
  Target,
  Award,
  Quote,
  ChevronLeft,
  ChevronRight,
  Building2,
  Cog,
  ShoppingCart,
  Lightbulb,
  UserPlus,
  Heart,
  BookOpen,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useLanguage } from "../contexts/LanguageContext";

// SECTION 1 — Who We Are (What We Are Doing)
export function RedesignedWhoWeAre() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { t } = useLanguage();

  return (
    <section ref={ref} className="py-20 bg-white relative">
      {/* Subtle Section Divider Top */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left — Premium Hero Image */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="relative"
          >
            <div className="relative rounded-xl overflow-hidden shadow-2xl shadow-black/10">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1523789418650-303a4ce757f7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvbW90aXZlJTIwdHJhaW5pbmclMjBjZW50ZXIlMjBmYWNpbGl0eSUyMGJ1aWxkaW5nfGVufDF8fHx8MTc2MzYxOTA1Mnww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Who We Are - TN Auto Skills"
                className="w-full h-[480px] object-cover"
              />
              {/* Subtle Gradient Overlay - Top to Bottom */}
              <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/20" />
            </div>
          </motion.div>

          {/* Right — Premium Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.15 }}
            className="space-y-6"
          >
            {/* Title */}
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] tracking-tight"
            >
              {t("whoWeAre.title")}
            </motion.h2>

            {/* Paragraph Content */}
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-[17px] text-[#475569] leading-[1.6] max-w-[540px]"
            >
              {t("whoWeAre.description")}
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="flex flex-wrap gap-4 pt-2"
            >
              {/* Primary Button */}
              <a
                href="#about"
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#004ABB] text-white rounded-lg font-semibold text-[15px] shadow-lg shadow-[#004ABB]/25 hover:shadow-xl hover:shadow-[#004ABB]/30 hover:bg-[#003A99] transition-all duration-300"
              >
                <span>{t("whoWeAre.readMore")}</span>
                <ArrowRight className="size-4" />
              </a>

              {/* Secondary Button */}
              <a
                href="#programs"
                className="inline-flex items-center gap-2 px-6 py-3 bg-white border-2 border-[#004ABB] text-[#004ABB] rounded-lg font-semibold text-[15px] hover:bg-[#F3F6F9] transition-all duration-300"
              >
                <span>{t("whoWeAre.explorePrograms")}</span>
                <ArrowRight className="size-4" />
              </a>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Subtle Section Divider Bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />
    </section>
  );
}

// SECTION 2 — Explore What We Are Doing
export function RedesignedExploreServices() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const services = [
    {
      icon: GraduationCap,
      title: "Industry-Aligned Skill Training",
      description:
        "Structured, government-certified automotive training programs based on evolving industry standards.",
    },
    {
      icon: Wrench,
      title: "Hands-On Technical Workshops",
      description:
        "Practical sessions, advanced labs, and real-world automotive tools.",
    },
    {
      icon: Briefcase,
      title: "Career Guidance & Placement",
      description:
        "Placement support with leading automotive companies, counseling, interview prep.",
    },
    {
      icon: Users,
      title: "Internship & On-the-Job Training",
      description:
        "Internships and OJT opportunities to understand real workflows.",
    },
    {
      icon: TrendingUp,
      title: "Upskilling for Working Professionals",
      description: "Short-term enhancement courses to grow in the workplace.",
    },
    {
      icon: Handshake,
      title: "Industry Partnership & Collaboration",
      description:
        "Work with OEMs, suppliers, and institutions to build the future workforce.",
    },
  ];

  return (
    <section ref={ref} className="py-20 bg-gradient-to-b from-[#F3F6F9] to-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-2">
            Explore What We Are Doing
          </h2>
          <p className="text-[15px] text-[#64748B] max-w-3xl mx-auto">
            Comprehensive programs designed to develop automotive talent and
            bridge the industry skill gap
          </p>
        </motion.div>

        {/* 3-Column Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {services.map((service, idx) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.06 }}
                whileHover={{ y: -4 }}
                className="group bg-white rounded-xl p-5 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                {/* Icon */}
                <div className="size-11 bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/10 rounded-xl flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                  <Icon className="size-5 text-[#0066FF]" strokeWidth={2} />
                </div>

                {/* Title */}
                <h3 className="font-bold text-[16px] text-[#0A0A0A] mb-2 leading-tight">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-[14px] text-[#64748B] leading-relaxed line-clamp-2">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// SECTION 3 — Empowering Every Stakeholder
export function RedesignedStakeholders() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stakeholders = [
    {
      image:
        "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=400&fit=crop",
      title: "Candidates",
      description:
        "Access government-certified training, hands-on skills, and direct placement opportunities.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop",
      title: "Industry",
      description:
        "Partner with us to build a skilled workforce aligned with your technology needs.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1722573783625-eceb04251036?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwc3R1ZGVudHMlMjBlbmdpbmVlcmluZyUyMGNsYXNzcm9vbSUyMGxlYXJuaW5nfGVufDF8fHx8MTc2MzYxOTExMnww&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Academia",
      description:
        "Collaborate on curriculum development and provide students with industry exposure.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=600&h=400&fit=crop",
      title: "Trainers & Assessors",
      description:
        "Join our network of certified professionals delivering world-class training.",
    },
  ];

  return (
    <section ref={ref} className="py-20 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A]">
            Empowering Every Stakeholder
          </h2>
        </motion.div>

        {/* 2x2 Grid */}
        <div className="grid md:grid-cols-2 gap-4">
          {stakeholders.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="group relative rounded-2xl overflow-hidden h-[240px] cursor-pointer"
            >
              {/* Background Image */}
              <ImageWithFallback
                src={item.image}
                alt={item.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />

              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent group-hover:from-black/70 transition-colors" />

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
                <h3 className="text-xl font-bold mb-1.5">{item.title}</h3>
                <p className="text-sm text-white/90 mb-2 line-clamp-2">
                  {item.description}
                </p>
                <div className="inline-flex items-center gap-1.5 text-sm font-semibold">
                  <span>Learn More</span>
                  <ArrowRight className="size-3.5" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION 4 — Featured Training Programs
export function RedesignedFeaturedPrograms() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const scrollRef = useRef<HTMLDivElement>(null);

  const programs = [
    {
      image:
        "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=500&h=350&fit=crop",
      title: "Electric Vehicle Technology",
      duration: "6 Months",
      level: "Advanced",
    },
    {
      image:
        "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=500&h=350&fit=crop",
      title: "Automotive Service Technician",
      duration: "12 Months",
      level: "Beginner",
    },
    {
      image:
        "https://images.unsplash.com/photo-1760435107992-f4714801666b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25uZWN0ZWQlMjBjYXIlMjB0ZWNobm9sb2d5JTIwZGFzaGJvYXJkJTIwZGlzcGxheXxlbnwxfHx8fDE3NjM2MTkzNTd8MA&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Connected Vehicle Systems",
      duration: "4 Months",
      level: "Intermediate",
    },
    {
      image:
        "https://images.unsplash.com/photo-1485463611174-f302f6a5c1c9?w=500&h=350&fit=crop",
      title: "Hybrid Vehicle Maintenance",
      duration: "6 Months",
      level: "Advanced",
    },
  ];

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 350;
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  return (
    <section ref={ref} className="py-12 bg-gradient-to-b from-white to-[#F3F6F9]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-between mb-8"
        >
          <div>
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-1">
              Featured Training Programs
            </h2>
            <p className="text-[15px] text-[#64748B]">
              Industry-aligned certification programs
            </p>
          </div>

          {/* Scroll Arrows */}
          <div className="hidden lg:flex gap-2">
            <button
              onClick={() => scroll("left")}
              className="size-9 bg-white border border-gray-200 rounded-full flex items-center justify-center hover:bg-[#0066FF] hover:text-white hover:border-[#0066FF] transition-all"
            >
              <ChevronLeft className="size-4" />
            </button>
            <button
              onClick={() => scroll("right")}
              className="size-9 bg-white border border-gray-200 rounded-full flex items-center justify-center hover:bg-[#0066FF] hover:text-white hover:border-[#0066FF] transition-all"
            >
              <ChevronRight className="size-4" />
            </button>
          </div>
        </motion.div>

        {/* Horizontal Scrollable Cards */}
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-3 snap-x snap-mandatory scrollbar-hide -mx-6 px-6 lg:mx-0 lg:px-0"
        >
          {programs.map((program, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: 40 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              className="group min-w-[300px] bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all snap-start"
            >
              {/* Image */}
              <div className="relative h-40 overflow-hidden">
                <ImageWithFallback
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />

                {/* Level Badge */}
                <div className="absolute top-3 right-3 px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-bold text-[#0066FF]">
                  {program.level}
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="font-bold text-[16px] text-[#0A0A0A] mb-1.5">
                  {program.title}
                </h3>
                <p className="text-sm text-[#64748B] mb-3">
                  Duration: {program.duration}
                </p>
                <a
                  href="#programs"
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#0066FF] hover:gap-2 transition-all"
                >
                  <span>View Details</span>
                  <ArrowRight className="size-3.5" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION 7 — Zero Fatalities by 2030
export function RedesignedZeroFatalities() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const pillars = [
    {
      icon: Shield,
      title: "Advanced Safety Systems",
      description: "Training on vehicle safety technologies",
    },
    {
      icon: Target,
      title: "Driver Education",
      description: "Behavior and road safety programs",
    },
    {
      icon: Award,
      title: "Emergency Response",
      description: "First aid and crisis management",
    },
  ];

  return (
    <section
      ref={ref}
      className="py-12 bg-gradient-to-br from-[#0A1628] via-[#1E293B] to-[#0F172A] text-white relative overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] border-2 border-white/30 rounded-[30%_70%_70%_30%/30%_30%_70%_70%]" />
      </div>

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold mb-3">
            Zero Fatalities by 2030
          </h2>
          {/* Glow Line */}
          <div className="w-24 h-0.5 bg-gradient-to-r from-transparent via-[#0090FF] to-transparent mx-auto mb-4" />

          <p className="text-[15px] text-white/80 max-w-3xl mx-auto leading-relaxed">
            We are committed to achieving the UN's Sustainable Development Goal
            of reducing road traffic deaths and injuries through comprehensive
            safety training.
          </p>
        </motion.div>

        {/* Three Pillars */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          {pillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.1 + idx * 0.1 }}
                className="bg-white/10 backdrop-blur-md rounded-xl p-5 border border-white/20 hover:bg-white/15 transition-all"
              >
                <div className="size-10 bg-white/20 rounded-lg flex items-center justify-center mb-3">
                  <Icon className="size-5 text-white" strokeWidth={2} />
                </div>
                <h3 className="font-bold text-[16px] mb-1.5">{pillar.title}</h3>
                <p className="text-sm text-white/70">{pillar.description}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-4xl mx-auto"
        >
          {[
            { label: "Target Reduction", value: "50%" },
            { label: "Achievement Year", value: "2030" },
            { label: "Safety Trainees", value: "1000+" },
            { label: "Awareness Programs", value: "100+" },
          ].map((stat, idx) => (
            <div
              key={idx}
              className="bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10 text-center"
            >
              <div className="text-2xl font-extrabold mb-0.5">{stat.value}</div>
              <div className="text-xs text-white/70">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 8 — Our Milestones
export function RedesignedMilestones() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stats = [
    { icon: Users, value: "2500+", label: "Students Trained" },
    { icon: Award, value: "500+", label: "Certified Professionals" },
    { icon: Briefcase, value: "200+", label: "Placements" },
    { icon: Building2, value: "40+", label: "Industry Partners" },
    { icon: TrendingUp, value: "95%", label: "Success Rate" },
  ];

  return (
    <section
      ref={ref}
      className="py-12 bg-gradient-to-br from-[#0066FF] via-[#0055DD] to-[#0090FF]"
    >
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-8 text-white"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold mb-2">
            Our Milestones
          </h2>
          <p className="text-[15px] text-white/90">
            Transforming automotive education across Tamil Nadu
          </p>
        </motion.div>

        {/* 5-Card Stat Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.08 }}
                whileHover={{ scale: 1.05, y: -4 }}
                className="bg-white/15 backdrop-blur-md rounded-xl p-5 border border-white/25 text-center text-white hover:bg-white/20 transition-all"
              >
                {/* Icon */}
                <div className="size-10 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Icon className="size-5" strokeWidth={2} />
                </div>

                {/* Value */}
                <div className="text-3xl font-extrabold mb-1">{stat.value}</div>

                {/* Label */}
                <div className="text-xs text-white/80 font-medium uppercase tracking-wide">
                  {stat.label}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// SECTION 9 — Success Stories
export function RedesignedSuccessStories() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stories = [
    {
      image:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop",
      name: "Rajesh Kumar",
      role: "EV Technician",
      company: "Ather Energy",
      quote:
        "The hands-on training I received helped me secure my dream job in the EV industry.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&h=300&fit=crop",
      name: "Priya Sharma",
      role: "Automotive Engineer",
      company: "Hyundai",
      quote:
        "TN Auto Skills provided me with industry-relevant skills and direct placement support.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&h=300&fit=crop",
      name: "Arjun Patel",
      role: "Service Manager",
      company: "TVS Motors",
      quote:
        "The certification program opened doors to leadership roles in the automotive sector.",
    },
  ];

  return (
    <section ref={ref} className="py-12 bg-gradient-to-b from-white to-[#F3F6F9]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-2">
            Success Stories
          </h2>
          <p className="text-[15px] text-[#64748B]">Hear from our graduates</p>
        </motion.div>

        {/* 3-Column Story Cards */}
        <div className="grid md:grid-cols-3 gap-4">
          {stories.map((story, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              whileHover={{ y: -4 }}
              className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-lg transition-all"
            >
              {/* Photo */}
              <div className="size-16 rounded-full overflow-hidden border-3 border-[#0066FF]/20 shadow-md mb-3">
                <ImageWithFallback
                  src={story.image}
                  alt={story.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Quote */}
              <Quote className="size-6 text-[#0066FF]/30 mb-2" />
              <p className="text-sm text-[#475569] italic mb-3 leading-relaxed line-clamp-3">
                "{story.quote}"
              </p>

              {/* Info */}
              <div>
                <div className="font-bold text-[15px] text-[#0A0A0A]">
                  {story.name}
                </div>
                <div className="text-xs text-[#64748B]">{story.role}</div>
                <div className="text-xs text-[#0066FF] font-semibold">
                  {story.company}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION 10 — Our Partners
export function RedesignedPartners() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const partners = [
    "Hyundai",
    "Maruti Suzuki",
    "Tata Motors",
    "TVS Motors",
    "Ashok Leyland",
    "Royal Enfield",
    "Ather Energy",
    "Ola Electric",
  ];

  return (
    <section ref={ref} className="py-12 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-2">
            Our Partners
          </h2>
          <p className="text-[15px] text-[#64748B]">
            Trusted by leading automotive companies
          </p>
        </motion.div>

        {/* Clean Logo Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {partners.map((partner, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: idx * 0.05 }}
              whileHover={{ scale: 1.03 }}
              className="bg-[#F3F6F9] rounded-xl p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-md transition-all flex items-center justify-center"
            >
              <div className="text-center">
                <Building2
                  className="size-8 text-[#0066FF] mx-auto mb-2"
                  strokeWidth={1.5}
                />
                <div className="font-bold text-sm text-[#0A0A0A]">{partner}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION 11 — Empanelment
export function RedesignedEmpanelment() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isHovered, setIsHovered] = useState(false);

  const categories = [
    {
      icon: Building2,
      title: "OEMs",
      subtitle: "Original Equipment Manufacturers",
      points: [
        "Workforce development programs",
        "Specialized training modules",
        "Access to skilled talent pool",
      ],
      link: "#oems",
    },
    {
      icon: Cog,
      title: "Auto Suppliers",
      subtitle: "Component Manufacturers",
      points: [
        "Technical skill training",
        "Competency development",
        "Quality assurance training",
      ],
      link: "#auto-suppliers",
    },
    {
      icon: ShoppingCart,
      title: "Retail Partners",
      subtitle: "Service Networks",
      points: [
        "Service technician training",
        "Customer service modules",
        "After-sales support",
      ],
      link: "#retail-partners",
    },
    {
      icon: Lightbulb,
      title: "Startups",
      subtitle: "Innovation Hubs",
      points: [
        "EV & new mobility training",
        "Technology integration",
        "R&D collaboration",
      ],
      link: "#startups",
    },
  ];

  return (
    <section
      ref={ref}
      className="py-20 bg-gradient-to-b from-[#F8FAFC] via-[#F1F5F9] to-white relative overflow-hidden"
    >
      {/* Rotating Wheel Background Animation */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
        style={{
          animation: isHovered
            ? "wheelRotate 2.5s linear infinite"
            : "wheelRotate 3s linear infinite",
          transition: "animation-duration 0.3s ease",
        }}
      >
        {/* Car Wheel SVG */}
        <svg
          width="600"
          height="600"
          viewBox="0 0 200 200"
          className="opacity-[0.08]"
          aria-hidden="true"
        >
          {/* Outer Rim */}
          <circle
            cx="100"
            cy="100"
            r="90"
            fill="none"
            stroke="#0066FF"
            strokeWidth="8"
          />
          <circle
            cx="100"
            cy="100"
            r="85"
            fill="none"
            stroke="#0055DD"
            strokeWidth="2"
          />

          {/* Spokes */}
          {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => (
            <line
              key={i}
              x1="100"
              y1="100"
              x2={100 + 75 * Math.cos((angle * Math.PI) / 180)}
              y2={100 + 75 * Math.sin((angle * Math.PI) / 180)}
              stroke="#0066FF"
              strokeWidth="4"
              strokeLinecap="round"
            />
          ))}

          {/* Hub */}
          <circle cx="100" cy="100" r="25" fill="#0066FF" />
          <circle cx="100" cy="100" r="15" fill="#0055DD" />
          <circle cx="100" cy="100" r="8" fill="#004ABB" />

          {/* Decorative Circles on Rim */}
          {[0, 60, 120, 180, 240, 300].map((angle, i) => (
            <circle
              key={i}
              cx={100 + 90 * Math.cos((angle * Math.PI) / 180)}
              cy={100 + 90 * Math.sin((angle * Math.PI) / 180)}
              r="5"
              fill="#0090FF"
            />
          ))}
        </svg>
      </div>

      {/* CSS Animation Keyframes */}
      <style>{`
        @keyframes wheelRotate {
          from {
            transform: translate(-50%, -50%) rotate(0deg);
          }
          to {
            transform: translate(-50%, -50%) rotate(360deg);
          }
        }
      `}</style>

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Empanelment Opportunities
          </h2>
          <p className="text-[16px] text-[#475569] max-w-3xl mx-auto leading-relaxed">
            Partner with TN AutoSkills across OEMs, Auto Suppliers, Retail, and
            Startups.
          </p>
        </motion.div>

        {/* 2x2 Grid of Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-10">
          {categories.map((category, idx) => {
            const Icon = category.icon;
            return (
              <motion.a
                key={idx}
                href={category.link}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ scale: 1.03, y: -4 }}
                onHoverStart={() => setIsHovered(true)}
                onHoverEnd={() => setIsHovered(false)}
                className="group relative bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer border border-gray-100 hover:border-[#0066FF]/30"
                style={{
                  boxShadow:
                    "0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)",
                }}
              >
                {/* Pastel Glow on Hover */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#0066FF]/0 to-[#0090FF]/0 group-hover:from-[#0066FF]/5 group-hover:to-[#0090FF]/5 transition-all duration-300 pointer-events-none" />

                {/* Content */}
                <div className="relative z-10">
                  {/* Icon & Title */}
                  <div className="flex items-start gap-4 mb-5">
                    <div className="size-14 bg-gradient-to-br from-[#E0F2FE] to-[#DBEAFE] rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm group-hover:shadow-md group-hover:scale-105 transition-all duration-300">
                      <Icon
                        className="size-7 text-[#0066FF]"
                        strokeWidth={2}
                        aria-hidden="true"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-xl text-[#0A0A0A] mb-1">
                        {category.title}
                      </h3>
                      <p className="text-sm text-[#64748B]">
                        {category.subtitle}
                      </p>
                    </div>
                  </div>

                  {/* Bullet Points */}
                  <ul className="space-y-2.5 mb-5">
                    {category.points.map((point, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-2.5 text-[15px] text-[#475569]"
                      >
                        <CheckCircle
                          className="size-4 text-[#0066FF] flex-shrink-0 mt-0.5"
                          strokeWidth={2.5}
                          aria-hidden="true"
                        />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Link */}
                  <div className="inline-flex items-center gap-2 text-[15px] font-semibold text-[#0066FF] group-hover:gap-3 transition-all">
                    <span>Learn More</span>
                    <ArrowRight
                      className="size-4 group-hover:translate-x-0.5 transition-transform"
                      aria-hidden="true"
                    />
                  </div>
                </div>
              </motion.a>
            );
          })}
        </div>

        {/* Main CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#empanelment-details"
            className="inline-flex items-center gap-2.5 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-[15px] shadow-lg shadow-[#0066FF]/25 hover:shadow-xl hover:shadow-[#0066FF]/35 hover:scale-[1.02] transition-all duration-300"
          >
            <span>View All Empanelment Details</span>
            <ArrowRight className="size-5" aria-hidden="true" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 12 — HR Registration for Recruitment
export function RedesignedHRRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-12 bg-white">
      <div className="max-w-[1000px] mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-br from-[#F0F9FF] to-[#F0FDFA] rounded-2xl p-8 lg:p-10 border border-gray-100 shadow-md"
        >
          <div className="grid lg:grid-cols-[60%_40%] gap-8 items-center">
            {/* Left — Text */}
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white rounded-full shadow-sm mb-4">
                <UserPlus className="size-3.5 text-[#0066FF]" />
                <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">
                  Recruitment
                </span>
              </div>

              <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] mb-3">
                HR Registration for Recruitment
              </h2>

              <p className="text-[15px] text-[#475569] leading-relaxed mb-5">
                Register your organization to access our pool of trained and
                certified automotive professionals.
              </p>

              <ul className="space-y-2">
                {[
                  "Access to 2500+ trained candidates",
                  "Industry-certified professionals",
                  "Streamlined recruitment process",
                ].map((item, i) => (
                  <li
                    key={i}
                    className="flex items-center gap-2 text-sm text-[#475569]"
                  >
                    <CheckCircle
                      className="size-4 text-[#0066FF]"
                      strokeWidth={2}
                    />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Right — CTA */}
            <div className="flex flex-col gap-2.5">
              <a
                href="#hr-register"
                className="px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-sm text-center shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
              >
                Register Now
              </a>
              <a
                href="#contact"
                className="px-6 py-3 bg-white border-2 border-[#0066FF] text-[#0066FF] rounded-xl font-bold text-sm text-center hover:bg-[#0066FF]/5 transition-all"
              >
                Contact Us
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 13 — CSR Projects
export function RedesignedCSRProjects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const projects = [
    {
      image:
        "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=600&h=400&fit=crop",
      icon: Heart,
      title: "Community Skill Development",
      description:
        "Partner with us to provide free automotive training to underprivileged youth and create employment opportunities in rural Tamil Nadu.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=600&h=400&fit=crop",
      icon: GraduationCap,
      title: "Women in Automotive Initiative",
      description:
        "Support our program to train and empower women in automotive technology, breaking gender barriers in the industry.",
    },
  ];

  return (
    <section ref={ref} className="py-12 bg-gradient-to-b from-[#F3F6F9] to-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-2">
            CSR Projects
          </h2>
          <p className="text-[15px] text-[#64748B] max-w-3xl mx-auto">
            Collaborate with us on Corporate Social Responsibility initiatives
          </p>
        </motion.div>

        {/* Grid of CSR Initiatives */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {projects.map((project, idx) => {
            const Icon = project.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.15 }}
                whileHover={{ y: -4 }}
                className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-lg transition-all"
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <ImageWithFallback
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />

                  {/* Icon */}
                  <div className="absolute top-5 left-5 size-12 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center">
                    <Icon className="size-6 text-white" strokeWidth={2} />
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-[#0A0A0A] mb-2">
                    {project.title}
                  </h3>
                  <p className="text-[15px] text-[#475569] leading-relaxed">
                    {project.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center"
        >
          <a
            href="#csr-register"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-sm shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            <span>CSR Partnership Registration</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 14 — Academia & Alumni Support
export function RedesignedAcademiaAlumni() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const cards = [
    {
      icon: BookOpen,
      title: "Campus Support",
      description: "Curriculum co-development and faculty training",
    },
    {
      icon: Users,
      title: "Alumni Guidance",
      description: "Continuous upskilling and career advancement",
    },
    {
      icon: Briefcase,
      title: "Internship Pipelines",
      description: "Direct industry connections for students",
    },
    {
      icon: GraduationCap,
      title: "Placement Assistance",
      description: "100% placement support for graduates",
    },
  ];

  return (
    <section ref={ref} className="py-12 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-2">
            Academia & Alumni Support
          </h2>
          <p className="text-[15px] text-[#64748B] max-w-3xl mx-auto">
            Bridging the gap between academic learning and industry requirements
          </p>
        </motion.div>

        {/* Compact 4-Column Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {cards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.08 }}
                whileHover={{ y: -4 }}
                className="bg-gradient-to-br from-white to-[#F3F6F9] rounded-xl p-5 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-md transition-all"
              >
                <div className="size-10 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-lg flex items-center justify-center mb-3 shadow-md">
                  <Icon className="size-5 text-white" strokeWidth={2} />
                </div>
                <h3 className="font-bold text-[15px] text-[#0A0A0A] mb-1.5">
                  {card.title}
                </h3>
                <p className="text-sm text-[#64748B]">{card.description}</p>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center"
        >
          <a
            href="#academia"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-sm shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            <span>Contact Academic Support</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION 15 — Placement Registration
export function RedesignedPlacementRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-12 bg-gradient-to-b from-[#F3F6F9] to-white">
      <div className="max-w-[900px] mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="bg-white rounded-2xl p-8 lg:p-10 border border-gray-100 shadow-md text-center"
        >
          <GraduationCap
            className="size-14 text-[#0066FF] mx-auto mb-5"
            strokeWidth={1.5}
          />

          <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] mb-3">
            Placement Registration
          </h2>

          <p className="text-[15px] text-[#475569] leading-relaxed max-w-2xl mx-auto mb-6">
            Register your educational institution to enable your students to
            access placement opportunities with leading automotive companies
            through TN Auto Skills.
          </p>

          <a
            href="#placement-register"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-sm shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            <span>Register Your Institution</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}