import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import { Send, ArrowLeft, CheckCircle2, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Label } from "./ui/label";
import { SuccessMessage } from "./SuccessMessage";

interface FormErrors {
  [key: string]: string;
}

export function HRRegistrationPage() {
  const formRef = useRef(null);
  const formInView = useInView(formRef, { once: true, margin: "-50px" });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    companyName: "",
    industryType: "",
    companyAddress: "",
    designation: "",
    mobileNumber: "",
    email: "",
    jobRole: "",
    jobDescription: "",
    requiredSkills: "",
    experienceRequired: "",
    salary: "",
    workLocation: "",
    employmentType: "",
    manpowerNeeded: "",
    remarks: "",
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<{ [key: string]: boolean }>({});

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validateMobileNumber = (mobile: string): boolean => {
    const mobileRegex = /^[0-9]{10}$/;
    return mobileRegex.test(mobile.replace(/\s/g, ""));
  };

  const validateField = (field: string, value: string): string => {
    if (field === "email" && value) {
      return validateEmail(value) ? "" : "Please enter a valid email address";
    }
    if (field === "mobileNumber" && value) {
      return validateMobileNumber(value) ? "" : "Please enter a valid 10-digit mobile number";
    }
    if (["companyName", "companyAddress", "designation", "email", "mobileNumber", "jobRole", "jobDescription", "requiredSkills", "experienceRequired", "salary", "workLocation", "manpowerNeeded"].includes(field)) {
      return value.trim() === "" ? "This field is required" : "";
    }
    if (["industryType", "employmentType"].includes(field)) {
      return value === "" ? "Please select an option" : "";
    }
    return "";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate all fields
    const newErrors: FormErrors = {};
    Object.keys(formData).forEach((field) => {
      const error = validateField(field, formData[field as keyof typeof formData]);
      if (error) newErrors[field] = error;
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      // Mark all fields as touched
      const allTouched: { [key: string]: boolean } = {};
      Object.keys(formData).forEach((field) => {
        allTouched[field] = true;
      });
      setTouched(allTouched);
      return;
    }

    console.log("Form submitted:", formData);
    setIsSubmitted(true);
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    
    // Validate on change if field was touched
    if (touched[field]) {
      const error = validateField(field, value);
      setErrors((prev) => ({
        ...prev,
        [field]: error,
      }));
    }
  };

  const handleBlur = (field: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
    const error = validateField(field, formData[field as keyof typeof formData]);
    setErrors((prev) => ({
      ...prev,
      [field]: error,
    }));
  };

  const isFieldValid = (field: string): boolean => {
    return touched[field] && !errors[field] && formData[field as keyof typeof formData] !== "";
  };

  const isFieldInvalid = (field: string): boolean => {
    return touched[field] && !!errors[field];
  };

  const handleBackToHome = () => {
    window.location.hash = "";
  };

  const handleSubmitAnother = () => {
    setIsSubmitted(false);
    setFormData({
      companyName: "",
      industryType: "",
      companyAddress: "",
      designation: "",
      mobileNumber: "",
      email: "",
      jobRole: "",
      jobDescription: "",
      requiredSkills: "",
      experienceRequired: "",
      salary: "",
      workLocation: "",
      employmentType: "",
      manpowerNeeded: "",
      remarks: "",
    });
    setErrors({});
    setTouched({});
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // If submitted, show success message
  if (isSubmitted) {
    return <SuccessMessage onBackToHome={handleBackToHome} onSubmitAnother={handleSubmitAnother} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F8FAFB] via-white to-[#F8FAFB]">
      {/* Compact Header Section */}
      <section className="py-12 bg-white border-b border-gray-100">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-3xl lg:text-[42px] font-extrabold text-[#0A1628] leading-tight mb-3">
              HR Registration for Recruitments
            </h1>
            <p className="text-base lg:text-[18px] text-[#64748B] font-medium leading-relaxed max-w-3xl mx-auto">
              Register job openings and collaborate with TN AutoSkills for skilled talent.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Form Section */}
      <section ref={formRef} className="py-12 relative overflow-hidden">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
          {/* Form Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={formInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 lg:p-10"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Stakeholder Badge */}
              <div className="pb-4 border-b border-gray-100">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#00BCD4]/10 rounded-lg border border-[#0066FF]/20">
                  <div className="size-2 bg-[#0066FF] rounded-full" />
                  <span className="text-sm font-semibold text-[#0066FF]">
                    Industry Registration for Candidate Recruitment
                  </span>
                </div>
              </div>

              {/* Company Information Section */}
              <div className="space-y-5">
                <h3 className="text-lg font-bold text-[#0A1628] flex items-center gap-2">
                  <div className="size-1.5 bg-[#0066FF] rounded-full" />
                  Company Information
                </h3>
                
                <div className="grid lg:grid-cols-2 gap-5">
                  {/* Industry / Company Name */}
                  <div className="space-y-2">
                    <Label htmlFor="companyName" className="text-sm font-semibold text-[#0A1628]">
                      Industry / Company Name <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="companyName"
                        placeholder="Enter your company name"
                        value={formData.companyName}
                        onChange={(e) => handleChange("companyName", e.target.value)}
                        onBlur={() => handleBlur("companyName")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("companyName")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("companyName")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("companyName") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("companyName") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("companyName") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.companyName}
                      </p>
                    )}
                  </div>

                  {/* Industry Type */}
                  <div className="space-y-2">
                    <Label htmlFor="industryType" className="text-sm font-semibold text-[#0A1628]">
                      Industry Type <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.industryType}
                      onValueChange={(value) => {
                        handleChange("industryType", value);
                        handleBlur("industryType");
                      }}
                    >
                      <SelectTrigger
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("industryType")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("industryType")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      >
                        <SelectValue placeholder="Select industry type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="manufacturing">Manufacturing</SelectItem>
                        <SelectItem value="automotive">Automotive</SelectItem>
                        <SelectItem value="service">Service</SelectItem>
                        <SelectItem value="it">IT</SelectItem>
                        <SelectItem value="others">Others</SelectItem>
                      </SelectContent>
                    </Select>
                    {isFieldInvalid("industryType") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.industryType}
                      </p>
                    )}
                  </div>
                </div>

                {/* Company Address */}
                <div className="space-y-2">
                  <Label htmlFor="companyAddress" className="text-sm font-semibold text-[#0A1628]">
                    Company Address <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="companyAddress"
                    placeholder="Enter complete company address"
                    value={formData.companyAddress}
                    onChange={(e) => handleChange("companyAddress", e.target.value)}
                    onBlur={() => handleBlur("companyAddress")}
                    rows={2}
                    className={`text-sm resize-none transition-all ${
                      isFieldInvalid("companyAddress")
                        ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                        : isFieldValid("companyAddress")
                        ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                        : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                    }`}
                  />
                  {isFieldInvalid("companyAddress") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.companyAddress}
                    </p>
                  )}
                </div>
              </div>

              {/* Contact Person Details Section */}
              <div className="space-y-5 pt-4 border-t border-gray-100">
                <h3 className="text-lg font-bold text-[#0A1628] flex items-center gap-2">
                  <div className="size-1.5 bg-[#0066FF] rounded-full" />
                  Contact Person Details
                </h3>

                <div className="grid lg:grid-cols-2 gap-5">
                  {/* Designation */}
                  <div className="space-y-2">
                    <Label htmlFor="designation" className="text-sm font-semibold text-[#0A1628]">
                      Designation <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="designation"
                        placeholder="Your designation"
                        value={formData.designation}
                        onChange={(e) => handleChange("designation", e.target.value)}
                        onBlur={() => handleBlur("designation")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("designation")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("designation")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("designation") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("designation") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("designation") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.designation}
                      </p>
                    )}
                  </div>

                  {/* Mobile Number */}
                  <div className="space-y-2">
                    <Label htmlFor="mobileNumber" className="text-sm font-semibold text-[#0A1628]">
                      Mobile Number <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="mobileNumber"
                        type="tel"
                        placeholder="+91 XXXXX XXXXX"
                        value={formData.mobileNumber}
                        onChange={(e) => handleChange("mobileNumber", e.target.value)}
                        onBlur={() => handleBlur("mobileNumber")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("mobileNumber")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("mobileNumber")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("mobileNumber") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("mobileNumber") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("mobileNumber") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.mobileNumber}
                      </p>
                    )}
                  </div>
                </div>

                {/* Email ID */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-semibold text-[#0A1628]">
                    Email ID <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <Input
                      id="email"
                      type="email"
                      placeholder="your.email@company.com"
                      value={formData.email}
                      onChange={(e) => handleChange("email", e.target.value)}
                      onBlur={() => handleBlur("email")}
                      className={`h-11 text-sm transition-all ${
                        isFieldInvalid("email")
                          ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                          : isFieldValid("email")
                          ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                          : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                      }`}
                    />
                    {isFieldValid("email") && (
                      <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                    )}
                    {isFieldInvalid("email") && (
                      <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                    )}
                  </div>
                  {isFieldInvalid("email") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.email}
                    </p>
                  )}
                </div>
              </div>

              {/* Job Requirements Section */}
              <div className="space-y-5 pt-4 border-t border-gray-100">
                <h3 className="text-lg font-bold text-[#0A1628] flex items-center gap-2">
                  <div className="size-1.5 bg-[#0066FF] rounded-full" />
                  Job Requirements
                </h3>

                {/* Job Role */}
                <div className="space-y-2">
                  <Label htmlFor="jobRole" className="text-sm font-semibold text-[#0A1628]">
                    Job Role / Position Required <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <Input
                      id="jobRole"
                      placeholder="E.g., Automotive Technician, Quality Inspector"
                      value={formData.jobRole}
                      onChange={(e) => handleChange("jobRole", e.target.value)}
                      onBlur={() => handleBlur("jobRole")}
                      className={`h-11 text-sm transition-all ${
                        isFieldInvalid("jobRole")
                          ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                          : isFieldValid("jobRole")
                          ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                          : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                      }`}
                    />
                    {isFieldValid("jobRole") && (
                      <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                    )}
                    {isFieldInvalid("jobRole") && (
                      <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                    )}
                  </div>
                  {isFieldInvalid("jobRole") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.jobRole}
                    </p>
                  )}
                </div>

                {/* Job Description */}
                <div className="space-y-2">
                  <Label htmlFor="jobDescription" className="text-sm font-semibold text-[#0A1628]">
                    Job Description <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="jobDescription"
                    placeholder="Describe the job responsibilities and requirements"
                    value={formData.jobDescription}
                    onChange={(e) => handleChange("jobDescription", e.target.value)}
                    onBlur={() => handleBlur("jobDescription")}
                    rows={3}
                    className={`text-sm resize-none transition-all ${
                      isFieldInvalid("jobDescription")
                        ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                        : isFieldValid("jobDescription")
                        ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                        : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                    }`}
                  />
                  {isFieldInvalid("jobDescription") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.jobDescription}
                    </p>
                  )}
                </div>

                {/* Required Skills */}
                <div className="space-y-2">
                  <Label htmlFor="requiredSkills" className="text-sm font-semibold text-[#0A1628]">
                    Required Skills / Qualifications <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="requiredSkills"
                    placeholder="List the key skills and qualifications needed"
                    value={formData.requiredSkills}
                    onChange={(e) => handleChange("requiredSkills", e.target.value)}
                    onBlur={() => handleBlur("requiredSkills")}
                    rows={3}
                    className={`text-sm resize-none transition-all ${
                      isFieldInvalid("requiredSkills")
                        ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                        : isFieldValid("requiredSkills")
                        ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                        : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                    }`}
                  />
                  {isFieldInvalid("requiredSkills") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.requiredSkills}
                    </p>
                  )}
                </div>

                <div className="grid lg:grid-cols-2 gap-5">
                  {/* Experience Required */}
                  <div className="space-y-2">
                    <Label htmlFor="experienceRequired" className="text-sm font-semibold text-[#0A1628]">
                      Experience Required <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="experienceRequired"
                        placeholder="E.g., 2-5 years"
                        value={formData.experienceRequired}
                        onChange={(e) => handleChange("experienceRequired", e.target.value)}
                        onBlur={() => handleBlur("experienceRequired")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("experienceRequired")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("experienceRequired")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("experienceRequired") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("experienceRequired") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("experienceRequired") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.experienceRequired}
                      </p>
                    )}
                  </div>

                  {/* Salary */}
                  <div className="space-y-2">
                    <Label htmlFor="salary" className="text-sm font-semibold text-[#0A1628]">
                      Salary <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="salary"
                        placeholder="E.g., ₹3-5 LPA"
                        value={formData.salary}
                        onChange={(e) => handleChange("salary", e.target.value)}
                        onBlur={() => handleBlur("salary")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("salary")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("salary")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("salary") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("salary") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("salary") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.salary}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid lg:grid-cols-2 gap-5">
                  {/* Work Location */}
                  <div className="space-y-2">
                    <Label htmlFor="workLocation" className="text-sm font-semibold text-[#0A1628]">
                      Work Location <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="workLocation"
                        placeholder="City, State"
                        value={formData.workLocation}
                        onChange={(e) => handleChange("workLocation", e.target.value)}
                        onBlur={() => handleBlur("workLocation")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("workLocation")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("workLocation")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("workLocation") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("workLocation") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("workLocation") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.workLocation}
                      </p>
                    )}
                  </div>

                  {/* Employment Type */}
                  <div className="space-y-2">
                    <Label htmlFor="employmentType" className="text-sm font-semibold text-[#0A1628]">
                      Employment Type <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.employmentType}
                      onValueChange={(value) => {
                        handleChange("employmentType", value);
                        handleBlur("employmentType");
                      }}
                    >
                      <SelectTrigger
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("employmentType")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("employmentType")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      >
                        <SelectValue placeholder="Select employment type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fulltime">Full-time</SelectItem>
                        <SelectItem value="parttime">Part-time</SelectItem>
                        <SelectItem value="apprenticeship">Apprenticeship</SelectItem>
                        <SelectItem value="internship">Internship</SelectItem>
                      </SelectContent>
                    </Select>
                    {isFieldInvalid("employmentType") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.employmentType}
                      </p>
                    )}
                  </div>
                </div>

                {/* How many manpower needed */}
                <div className="space-y-2">
                  <Label htmlFor="manpowerNeeded" className="text-sm font-semibold text-[#0A1628]">
                    How many manpower needed <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <Input
                      id="manpowerNeeded"
                      type="number"
                      placeholder="Number of positions"
                      value={formData.manpowerNeeded}
                      onChange={(e) => handleChange("manpowerNeeded", e.target.value)}
                      onBlur={() => handleBlur("manpowerNeeded")}
                      min="1"
                      className={`h-11 text-sm transition-all ${
                        isFieldInvalid("manpowerNeeded")
                          ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                          : isFieldValid("manpowerNeeded")
                          ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                          : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                      }`}
                    />
                    {isFieldValid("manpowerNeeded") && (
                      <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                    )}
                    {isFieldInvalid("manpowerNeeded") && (
                      <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                    )}
                  </div>
                  {isFieldInvalid("manpowerNeeded") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.manpowerNeeded}
                    </p>
                  )}
                </div>

                {/* Remarks */}
                <div className="space-y-2">
                  <Label htmlFor="remarks" className="text-sm font-semibold text-[#0A1628]">
                    Remarks <span className="text-gray-400 text-xs">(Optional)</span>
                  </Label>
                  <Textarea
                    id="remarks"
                    placeholder="Any additional information or special requirements"
                    value={formData.remarks}
                    onChange={(e) => handleChange("remarks", e.target.value)}
                    rows={2}
                    className="text-sm resize-none border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="pt-6 border-t border-gray-100">
                <div className="flex flex-col items-center gap-4">
                  <Button
                    type="submit"
                    className="w-full lg:w-auto px-12 h-12 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] hover:from-[#0055DD] hover:to-[#00ACC4] text-white font-semibold shadow-lg hover:shadow-xl transition-all text-base"
                  >
                    <Send className="size-5 mr-2" />
                    Submit Registration
                  </Button>
                  
                  <p className="text-sm text-[#64748B] text-center">
                    We will contact you within <span className="font-semibold text-[#0066FF]">48 hours</span>
                  </p>

                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => (window.location.hash = "")}
                    className="text-[#64748B] hover:text-[#0066FF] hover:bg-[#0066FF]/5 text-sm"
                  >
                    <ArrowLeft className="size-4 mr-1.5" />
                    Back to Home
                  </Button>
                </div>
              </div>
            </form>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={formInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-8 text-center"
          >
            <p className="text-sm text-[#64748B]">
              Need assistance? Contact us at{" "}
              <a
                href="mailto:hr@tnautoskills.in"
                className="text-[#0066FF] font-semibold hover:underline"
              >
                hr@tnautoskills.in
              </a>{" "}
              or call{" "}
              <a
                href="tel:+911234567890"
                className="text-[#0066FF] font-semibold hover:underline"
              >
                +91 123 456 7890
              </a>
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}