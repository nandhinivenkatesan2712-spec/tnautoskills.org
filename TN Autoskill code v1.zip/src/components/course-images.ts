// Course image URLs mapped by course ID
export const courseImages: Record<number, string> = {
  1: "https://images.unsplash.com/photo-1564912139097-6e35a037c77f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ix id=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvbW90aXZlJTIwZWxlY3RyaWNhbCUyMHdpcmluZyUyMGRpYWdub3N0aWMlMjB0b29sc3xlbnwxfHx8fDE3NjM4OTE2Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080",
  2: "https://images.unsplash.com/photo-1701448149957-b96dbd1926ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDTkMlMjBtYWNoaW5lJTIwbGF0aGUlMjBtYW51ZmFjdHVyaW5nfGVufDF8fHx8MTc2Mzg5MTYyOHww&ixlib=rb-4.1.0&q=80&w=1080",
  3: "https://images.unsplash.com/photo-1694889648476-3777d917b91c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpYyUyMHZlaGljbGUlMjBiYXR0ZXJ5JTIwcGFja3xlbnwxfHx8fDE3NjM4OTE2Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080",
  4: "https://images.unsplash.com/photo-1726220230389-cd363f6a52eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDTkMlMjBtaWxsaW5nJTIwbWFjaGluZSUyMHdvcmtzaG9wfGVufDF8fHx8MTc2Mzg5MTYyOXww&ixlib=rb-4.1.0&q=80&w=1080",
  5: "https://images.unsplash.com/photo-1673201159941-68fcdbbb4fa1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWxkaW5nJTIwZmFicmljYXRpb24lMjB3b3Jrc2hvcCUyMG1ldGFsfGVufDF8fHx8MTc2Mzg5MTYyOXww&ixlib=rb-4.1.0&q=80&w=1080",
  6: "https://images.unsplash.com/photo-1730584476053-35289e6b1575?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb2JvdGljJTIwd2VsZGluZyUyMGFybSUyMGluZHVzdHJpYWx8ZW58MXx8fHwxNzYzODkxNjI5fDA&ixlib=rb-4.1.0&q=80&w=1080",
  7: "https://images.unsplash.com/photo-1636761358783-209512dccd98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3RvcmN5Y2xlJTIwbWVjaGFuaWMlMjBzZXJ2aWNlJTIwd29ya3Nob3B8ZW58MXx8fHwxNzYzODkxNjMwfDA&ixlib=rb-4.1.0&q=80&w=1080",
  8: "https://images.unsplash.com/photo-1694344500115-d2dcbc1ea38f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkcml2aW5nJTIwc2Nob29sJTIwY2FyJTIwc3RlZXJpbmd8ZW58MXx8fHwxNzYzODkxNjMwfDA&ixlib=rb-4.1.0&q=80&w=1080",
  9: "https://images.unsplash.com/photo-1582186484574-5f740083b07e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvJTIwcmlja3NoYXclMjBkcml2ZXIlMjBpbmRpYXxlbnwxfHx8fDE3NjM4OTE2MzF8MA&ixlib=rb-4.1.0&q=80&w=1080",
};
