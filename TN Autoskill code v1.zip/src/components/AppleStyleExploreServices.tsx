import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { GraduationCap, Wrench, Briefcase, Users, TrendingUp, Handshake, ArrowRight } from "lucide-react";

export function AppleStyleExploreServices() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const services = [
    {
      icon: GraduationCap,
      title: "Industry-Aligned Skill Training",
      description: "Structured, government-certified automotive training programs aligned with evolving industry standards.",
      gradient: "from-blue-500/10 to-cyan-500/10",
      iconGradient: "from-blue-500 to-cyan-500",
      hoverColor: "group-hover:shadow-blue-500/10",
    },
    {
      icon: Wrench,
      title: "Hands-On Technical Workshops",
      description: "Practical learning through real-time workshops, modern lab tools, and exposure to the latest automotive technologies.",
      gradient: "from-teal-500/10 to-emerald-500/10",
      iconGradient: "from-teal-500 to-emerald-500",
      hoverColor: "group-hover:shadow-teal-500/10",
    },
    {
      icon: Briefcase,
      title: "Career Guidance & Placement Support",
      description: "Connecting candidates with leading companies through career counseling, interview preparation, and placement opportunities.",
      gradient: "from-violet-500/10 to-purple-500/10",
      iconGradient: "from-violet-500 to-purple-500",
      hoverColor: "group-hover:shadow-violet-500/10",
    },
    {
      icon: Users,
      title: "Internship & On-the-Job Training",
      description: "Industry internships and OJT programs that prepare students for real-world workflows and boost employability.",
      gradient: "from-indigo-500/10 to-blue-500/10",
      iconGradient: "from-indigo-500 to-blue-500",
      hoverColor: "group-hover:shadow-indigo-500/10",
    },
    {
      icon: TrendingUp,
      title: "Upskilling Programs for Professionals",
      description: "Advanced and short-term enhancement programs to help working professionals stay competitive.",
      gradient: "from-cyan-500/10 to-teal-500/10",
      iconGradient: "from-cyan-500 to-teal-500",
      hoverColor: "group-hover:shadow-cyan-500/10",
    },
    {
      icon: Handshake,
      title: "Industry Partnership & Collaboration",
      description: "Collaborations with OEMs and auto suppliers to deliver high-quality training, industry exposure, and workforce development.",
      gradient: "from-purple-500/10 to-pink-500/10",
      iconGradient: "from-purple-500 to-pink-500",
      hoverColor: "group-hover:shadow-purple-500/10",
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-white">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4 tracking-tight">
            Explore What We Are Doing
          </h2>
          <p className="text-lg text-[#86868B] max-w-2xl mx-auto font-normal">
            Comprehensive programs designed to shape the future of automotive skills in Tamil Nadu.
          </p>
        </motion.div>

        {/* Card Grid - Apple Style */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, idx) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.08 }}
                className={`group bg-white border border-[#D2D2D7]/60 rounded-[18px] p-8 hover:scale-[1.02] hover:shadow-2xl ${service.hoverColor} transition-all duration-400 cursor-pointer`}
              >
                {/* Icon Container */}
                <div className={`inline-flex items-center justify-center size-14 rounded-2xl bg-gradient-to-br ${service.gradient} mb-6`}>
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${service.iconGradient}`}>
                    <Icon className="size-6 text-white" strokeWidth={1.5} />
                  </div>
                </div>

                {/* Content */}
                <h3 className="font-semibold text-[21px] text-[#1D1D1F] mb-3 tracking-tight">
                  {service.title}
                </h3>
                <p className="text-[15px] text-[#86868B] leading-relaxed mb-6 font-normal">
                  {service.description}
                </p>

                {/* CTA Link Button */}
                <button className="inline-flex items-center gap-1.5 text-[15px] font-medium text-[#0066FF] hover:text-[#0052CC] transition-colors duration-200">
                  <span>Learn More</span>
                  <ArrowRight className="size-4 transition-transform duration-200 group-hover:translate-x-1" strokeWidth={2} />
                </button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}