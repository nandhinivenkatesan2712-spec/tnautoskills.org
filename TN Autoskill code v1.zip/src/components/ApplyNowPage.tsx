import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import { 
  Search,
  ArrowRight,
  Upload,
  CheckCircle2,
  AlertCircle,
  Clock,
  Award,
  Calendar,
  DollarSign,
  Phone,
  Mail,
  FileText,
  User,
  MapPin,
  Zap,
  Wrench,
  Settings,
  Briefcase,
  Car,
  Factory,
  Shield,
  X,
  Check
} from "lucide-react";

// Program data with clean line icons
const programs = [
  { 
    id: 1, 
    name: "Battery Electric Vehicle Training", 
    duration: "3 Months", 
    level: "Advanced",
    category: "EV Technology",
    fees: "₹25,000",
    nextBatch: "15 Dec 2024",
    icon: Zap,
    description: "Master EV technology, battery systems, and charging infrastructure"
  },
  { 
    id: 2, 
    name: "Automotive Service Technician", 
    duration: "6 Months", 
    level: "Intermediate",
    category: "Service & Repair",
    fees: "₹35,000",
    nextBatch: "1 Jan 2025",
    icon: Wrench,
    description: "Comprehensive training in vehicle diagnostics and repair"
  },
  { 
    id: 3, 
    name: "CNC Operating", 
    duration: "2 Months", 
    level: "Intermediate",
    category: "Manufacturing",
    fees: "₹20,000",
    nextBatch: "10 Dec 2024",
    icon: Settings,
    description: "Learn CNC machine operation and advanced manufacturing"
  },
  { 
    id: 4, 
    name: "Automotive Sales Consultant", 
    duration: "1 Month", 
    level: "Beginner",
    category: "Sales & Marketing",
    fees: "₹15,000",
    nextBatch: "20 Dec 2024",
    icon: Briefcase,
    description: "Develop skills in automotive sales and customer relations"
  },
  { 
    id: 5, 
    name: "LMV / HMV Driving", 
    duration: "2 Weeks", 
    level: "Beginner",
    category: "Driving",
    fees: "₹10,000",
    nextBatch: "5 Dec 2024",
    icon: Car,
    description: "Professional driving training with license preparation"
  },
  { 
    id: 6, 
    name: "Advanced Manufacturing Technology", 
    duration: "4 Months", 
    level: "Advanced",
    category: "Manufacturing",
    fees: "₹30,000",
    nextBatch: "25 Dec 2024",
    icon: Factory,
    description: "Industry 4.0 manufacturing techniques and automation"
  },
];

const categories = ["All Programs", "EV Technology", "Service & Repair", "Manufacturing", "Sales & Marketing", "Driving"];

const districts = [
  "Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli",
  "Tiruppur", "Ranipet", "Nagercoil", "Thanjavur", "Vellore", "Kancheepuram",
  "Erode", "Tiruvannamalai", "Karur", "Other"
];

export function ApplyNowPage() {
  const bannerRef = useRef(null);
  const stepsRef = useRef(null);
  const formRef = useRef(null);
  
  const isBannerInView = useInView(bannerRef, { once: true, margin: "-100px" });
  const isStepsInView = useInView(stepsRef, { once: true, margin: "-100px" });
  const isFormInView = useInView(formRef, { once: true, margin: "-100px" });

  // Form state
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Programs");
  const [selectedProgram, setSelectedProgram] = useState<typeof programs[0] | null>(null);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    mobile: "",
    district: "",
    education: "",
    preferredBatch: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Filter programs
  const filteredPrograms = programs.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All Programs" || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  // Validate step 2
  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.fullName.trim()) newErrors.fullName = "Full name is required";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email";
    }
    if (!formData.mobile.trim()) {
      newErrors.mobile = "Mobile number is required";
    } else if (!/^[0-9]{10}$/.test(formData.mobile.replace(/\s/g, ""))) {
      newErrors.mobile = "Please enter a valid 10-digit mobile number";
    }
    if (!formData.district) newErrors.district = "District is required";
    if (!formData.education) newErrors.education = "Education qualification is required";
    if (!formData.preferredBatch) newErrors.preferredBatch = "Preferred batch is required";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle next step
  const handleNext = () => {
    if (currentStep === 1 && !selectedProgram) {
      alert("Please select a program");
      return;
    }
    if (currentStep === 2 && !validateStep2()) {
      return;
    }
    
    if (currentStep < 3) {
      setCurrentStep((prev) => (prev + 1) as 1 | 2 | 3);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Modern Banner Section */}
      <section ref={bannerRef} className="relative bg-gradient-to-br from-[#0066FF] via-[#0066FF] to-[#0090FF] overflow-hidden">
        {/* Animated Background Shapes */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            animate={{
              rotate: [0, 360],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute -top-20 -right-20 w-96 h-96 bg-white/5 rounded-full blur-3xl"
          />
          <motion.div
            animate={{
              rotate: [360, 0],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute -bottom-20 -left-20 w-96 h-96 bg-white/5 rounded-full blur-3xl"
          />
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:4rem_4rem]" />
        </div>

        <div className="relative max-w-[1440px] mx-auto px-8 py-24 lg:py-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isBannerInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isBannerInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-flex items-center gap-2 px-6 py-3 bg-white/20 backdrop-blur-md rounded-full border border-white/30 mb-8"
            >
              <div className="size-2 bg-white rounded-full animate-pulse" />
              <span className="text-sm font-semibold text-white">
                Admissions Open — Batch Starting Soon
              </span>
            </motion.div>

            {/* Title */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={isBannerInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-5xl lg:text-7xl font-extrabold text-white mb-6 leading-tight"
            >
              Apply Now
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isBannerInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-xl lg:text-2xl text-white/90 leading-relaxed"
            >
              Begin your journey with future-ready automotive training programs
            </motion.p>
          </motion.div>
        </div>

        {/* Bottom Wave */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto">
            <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="white"/>
          </svg>
        </div>
      </section>

      {/* Main Content */}
      <section ref={stepsRef} className="py-16 bg-white">
        <div className="max-w-[1200px] mx-auto px-8">
          {/* Success Screen */}
          {formSubmitted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <div className="max-w-2xl mx-auto bg-white rounded-3xl border-2 border-gray-100 shadow-2xl p-12">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", duration: 0.6, delay: 0.2 }}
                  className="size-24 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-lg"
                >
                  <CheckCircle2 className="size-12 text-white" />
                </motion.div>

                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-4xl font-extrabold text-[#0A0A0A] mb-4"
                >
                  Application Submitted Successfully!
                </motion.h2>

                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-lg text-[#475569] mb-8"
                >
                  Thank you for applying to <strong className="text-[#0066FF]">{selectedProgram?.name}</strong>. We'll review your application and get back to you within 3-5 working days.
                </motion.p>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="inline-flex items-center gap-3 px-6 py-3 bg-[#F3F6F9] rounded-2xl mb-10"
                >
                  <FileText className="size-5 text-[#0066FF]" />
                  <div className="text-left">
                    <p className="text-xs text-[#64748b]">Application ID</p>
                    <p className="font-mono font-bold text-[#0A0A0A]">TNA{Date.now().toString().slice(-6)}</p>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 mb-8"
                >
                  <h3 className="font-bold text-[#0A0A0A] mb-3">What happens next?</h3>
                  <ul className="space-y-2 text-left text-sm text-[#475569]">
                    <li className="flex items-start gap-3">
                      <Check className="size-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>You'll receive a confirmation email within 24 hours</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <Check className="size-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Our team will review your application within 3-5 working days</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <Check className="size-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>We'll contact you via phone/email for the next steps</span>
                    </li>
                  </ul>
                </motion.div>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <motion.a
                    href="#home"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 bg-[#0066FF] text-white rounded-xl font-semibold shadow-lg hover:bg-[#0090FF] transition-all"
                  >
                    Back to Home
                  </motion.a>
                  <motion.button
                    onClick={() => {
                      setFormSubmitted(false);
                      setCurrentStep(1);
                      setSelectedProgram(null);
                      setFormData({
                        fullName: "",
                        email: "",
                        mobile: "",
                        district: "",
                        education: "",
                        preferredBatch: "",
                      });
                    }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 bg-white text-[#0066FF] border-2 border-[#0066FF] rounded-xl font-semibold hover:bg-blue-50 transition-all"
                  >
                    Submit Another Application
                  </motion.button>
                </div>
              </div>
            </motion.div>
          )}

          {/* Application Form */}
          {!formSubmitted && (
            <>
              {/* Modern Stepper */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={isStepsInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6 }}
                className="mb-12"
              >
                <div className="flex items-center justify-between max-w-3xl mx-auto relative">
                  {/* Progress Line */}
                  <div className="absolute left-0 right-0 top-6 h-1 bg-gray-200 -z-10" />
                  <div 
                    className="absolute left-0 top-6 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] -z-10 transition-all duration-500"
                    style={{ width: `${((currentStep - 1) / 2) * 100}%` }}
                  />

                  {/* Steps */}
                  {[
                    { num: 1, label: "Choose Program", icon: FileText },
                    { num: 2, label: "Enter Details", icon: User },
                    { num: 3, label: "Submit Application", icon: CheckCircle2 }
                  ].map((step, index) => {
                    const StepIcon = step.icon;
                    const isActive = currentStep === step.num;
                    const isCompleted = currentStep > step.num;
                    
                    return (
                      <div key={step.num} className="flex flex-col items-center flex-1 relative">
                        <motion.div
                          whileHover={{ scale: isActive ? 1.1 : 1 }}
                          className={`size-12 rounded-full flex items-center justify-center font-bold text-lg mb-3 border-4 transition-all shadow-lg ${
                            isCompleted
                              ? "bg-green-500 border-green-500 text-white"
                              : isActive
                              ? "bg-[#0066FF] border-[#0066FF] text-white"
                              : "bg-white border-gray-300 text-gray-400"
                          }`}
                        >
                          {isCompleted ? (
                            <Check className="size-6" />
                          ) : (
                            <StepIcon className="size-6" />
                          )}
                        </motion.div>
                        <span 
                          className={`text-sm font-semibold text-center ${
                            isActive ? "text-[#0066FF]" : isCompleted ? "text-green-600" : "text-gray-400"
                          }`}
                        >
                          {step.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </motion.div>

              {/* Step Content */}
              <div ref={formRef}>
                {/* Step 1: Choose Program */}
                {currentStep === 1 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={isFormInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.5 }}
                  >
                    {/* Search & Filter */}
                    <div className="mb-8 space-y-4">
                      {/* Search Bar */}
                      <div className="relative max-w-xl mx-auto">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#64748b]" />
                        <input
                          type="text"
                          placeholder="Search programs by name..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-full pl-12 pr-4 py-4 bg-white border-2 border-gray-200 rounded-xl text-base focus:outline-none focus:border-[#0066FF] transition-all shadow-sm"
                        />
                      </div>

                      {/* Category Pills */}
                      <div className="flex flex-wrap gap-3 justify-center">
                        {categories.map((category) => (
                          <motion.button
                            key={category}
                            onClick={() => setSelectedCategory(category)}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className={`px-5 py-2.5 rounded-full font-semibold text-sm transition-all shadow-sm ${
                              selectedCategory === category
                                ? "bg-[#0066FF] text-white shadow-lg"
                                : "bg-white text-[#475569] border-2 border-gray-200 hover:border-[#0066FF]"
                            }`}
                          >
                            {category}
                          </motion.button>
                        ))}
                      </div>
                    </div>

                    {/* Program Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                      {filteredPrograms.map((program, index) => {
                        const IconComponent = program.icon;
                        const isSelected = selectedProgram?.id === program.id;
                        
                        return (
                          <motion.button
                            key={program.id}
                            onClick={() => setSelectedProgram(program)}
                            initial={{ opacity: 0, y: 20 }}
                            animate={isFormInView ? { opacity: 1, y: 0 } : {}}
                            transition={{ duration: 0.5, delay: index * 0.1 }}
                            whileHover={{ scale: 1.02, y: -5 }}
                            whileTap={{ scale: 0.98 }}
                            className={`relative text-left p-6 rounded-2xl border-2 transition-all shadow-lg hover:shadow-2xl ${
                              isSelected
                                ? "border-[#0066FF] bg-gradient-to-br from-blue-50 to-indigo-50"
                                : "border-gray-200 bg-white hover:border-gray-300"
                            }`}
                          >
                            {/* Selection Indicator */}
                            {isSelected && (
                              <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="absolute -top-3 -right-3 size-8 bg-[#0066FF] rounded-full flex items-center justify-center shadow-lg"
                              >
                                <Check className="size-5 text-white" />
                              </motion.div>
                            )}

                            {/* Icon */}
                            <div className="size-14 rounded-xl bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/10 flex items-center justify-center mb-4">
                              <IconComponent className="size-7 text-[#0066FF]" strokeWidth={1.5} />
                            </div>

                            {/* Content */}
                            <h3 className="font-bold text-[#0A0A0A] mb-2 leading-tight">
                              {program.name}
                            </h3>
                            
                            <p className="text-sm text-[#64748b] mb-4 line-clamp-2">
                              {program.description}
                            </p>

                            {/* Meta Info */}
                            <div className="space-y-2">
                              <div className="flex items-center gap-2 text-sm text-[#475569]">
                                <Clock className="size-4 text-[#0066FF]" />
                                <span>{program.duration}</span>
                              </div>
                              
                              <div className="flex items-center justify-between">
                                <span className={`inline-flex px-3 py-1 rounded-full text-xs font-semibold ${
                                  program.level === "Advanced" 
                                    ? "bg-red-100 text-red-700"
                                    : program.level === "Intermediate"
                                    ? "bg-yellow-100 text-yellow-700"
                                    : "bg-green-100 text-green-700"
                                }`}>
                                  {program.level}
                                </span>
                                <span className="text-sm font-bold text-[#0066FF]">
                                  {program.fees}
                                </span>
                              </div>
                            </div>
                          </motion.button>
                        );
                      })}
                    </div>

                    {/* No Results */}
                    {filteredPrograms.length === 0 && (
                      <div className="text-center py-16">
                        <div className="size-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Search className="size-8 text-gray-400" />
                        </div>
                        <h3 className="font-bold text-[#0A0A0A] mb-2">No programs found</h3>
                        <p className="text-[#64748b]">Try adjusting your search or filters</p>
                      </div>
                    )}

                    {/* Continue Button */}
                    {selectedProgram && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="max-w-2xl mx-auto"
                      >
                        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 mb-6 border-2 border-[#0066FF]/20">
                          <div className="flex items-start gap-4">
                            <div className="size-12 rounded-xl bg-[#0066FF]/10 flex items-center justify-center flex-shrink-0">
                              <selectedProgram.icon className="size-6 text-[#0066FF]" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-bold text-[#0A0A0A] mb-1">Selected Program</h4>
                              <p className="text-[#475569]">{selectedProgram.name}</p>
                            </div>
                            <button
                              onClick={() => setSelectedProgram(null)}
                              className="size-8 rounded-lg bg-white hover:bg-gray-100 flex items-center justify-center transition-colors"
                            >
                              <X className="size-4 text-gray-600" />
                            </button>
                          </div>
                        </div>

                        <motion.button
                          onClick={handleNext}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className="w-full px-8 py-5 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-lg shadow-xl hover:shadow-2xl transition-all flex items-center justify-center gap-3"
                        >
                          <span>Continue to Details</span>
                          <ArrowRight className="size-6" />
                        </motion.button>
                      </motion.div>
                    )}
                  </motion.div>
                )}

                {/* Step 2: Enter Details */}
                {currentStep === 2 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5 }}
                    className="max-w-3xl mx-auto"
                  >
                    <div className="bg-white rounded-2xl border-2 border-gray-100 shadow-lg p-8 lg:p-10">
                      <h2 className="text-3xl font-extrabold text-[#0A0A0A] mb-2">
                        Your Details
                      </h2>
                      <p className="text-[#64748b] mb-8">
                        Please provide accurate information for application processing
                      </p>

                      <form className="space-y-6">
                        {/* Full Name */}
                        <div>
                          <label htmlFor="fullName" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                            Full Name <span className="text-red-500">*</span>
                          </label>
                          <div className="relative">
                            <User className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#64748b]" />
                            <input
                              type="text"
                              id="fullName"
                              name="fullName"
                              value={formData.fullName}
                              onChange={handleChange}
                              className={`w-full pl-12 pr-4 py-4 bg-white border-2 rounded-xl text-base focus:outline-none transition-all ${
                                errors.fullName ? "border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                              }`}
                              placeholder="Enter your full name"
                            />
                          </div>
                          {errors.fullName && (
                            <p className="mt-2 text-sm text-red-600 flex items-center gap-2">
                              <AlertCircle className="size-4" />
                              {errors.fullName}
                            </p>
                          )}
                        </div>

                        {/* Email & Mobile */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <label htmlFor="email" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                              Email Address <span className="text-red-500">*</span>
                            </label>
                            <div className="relative">
                              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#64748b]" />
                              <input
                                type="email"
                                id="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                className={`w-full pl-12 pr-4 py-4 bg-white border-2 rounded-xl text-base focus:outline-none transition-all ${
                                  errors.email ? "border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                                }`}
                                placeholder="your.email@example.com"
                              />
                            </div>
                            {errors.email && (
                              <p className="mt-2 text-sm text-red-600 flex items-center gap-2">
                                <AlertCircle className="size-4" />
                                {errors.email}
                              </p>
                            )}
                          </div>

                          <div>
                            <label htmlFor="mobile" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                              Mobile Number <span className="text-red-500">*</span>
                            </label>
                            <div className="relative">
                              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#64748b]" />
                              <input
                                type="tel"
                                id="mobile"
                                name="mobile"
                                value={formData.mobile}
                                onChange={handleChange}
                                className={`w-full pl-12 pr-4 py-4 bg-white border-2 rounded-xl text-base focus:outline-none transition-all ${
                                  errors.mobile ? "border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                                }`}
                                placeholder="10-digit mobile number"
                              />
                            </div>
                            {errors.mobile && (
                              <p className="mt-2 text-sm text-red-600 flex items-center gap-2">
                                <AlertCircle className="size-4" />
                                {errors.mobile}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* District & Education */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <label htmlFor="district" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                              District <span className="text-red-500">*</span>
                            </label>
                            <div className="relative">
                              <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#64748b]" />
                              <select
                                id="district"
                                name="district"
                                value={formData.district}
                                onChange={handleChange}
                                className={`w-full pl-12 pr-4 py-4 bg-white border-2 rounded-xl text-base focus:outline-none transition-all appearance-none ${
                                  errors.district ? "border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                                }`}
                              >
                                <option value="">Select District</option>
                                {districts.map((district) => (
                                  <option key={district} value={district}>
                                    {district}
                                  </option>
                                ))}
                              </select>
                            </div>
                            {errors.district && (
                              <p className="mt-2 text-sm text-red-600 flex items-center gap-2">
                                <AlertCircle className="size-4" />
                                {errors.district}
                              </p>
                            )}
                          </div>

                          <div>
                            <label htmlFor="education" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                              Education Level <span className="text-red-500">*</span>
                            </label>
                            <div className="relative">
                              <Award className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#64748b]" />
                              <select
                                id="education"
                                name="education"
                                value={formData.education}
                                onChange={handleChange}
                                className={`w-full pl-12 pr-4 py-4 bg-white border-2 rounded-xl text-base focus:outline-none transition-all appearance-none ${
                                  errors.education ? "border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                                }`}
                              >
                                <option value="">Select Qualification</option>
                                <option value="10th">10th Standard</option>
                                <option value="12th">12th Standard</option>
                                <option value="iti">ITI</option>
                                <option value="diploma">Diploma</option>
                                <option value="graduate">Graduate</option>
                                <option value="postgraduate">Post Graduate</option>
                              </select>
                            </div>
                            {errors.education && (
                              <p className="mt-2 text-sm text-red-600 flex items-center gap-2">
                                <AlertCircle className="size-4" />
                                {errors.education}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Preferred Batch */}
                        <div>
                          <label htmlFor="preferredBatch" className="block text-sm font-bold text-[#0A0A0A] mb-2">
                            Preferred Batch <span className="text-red-500">*</span>
                          </label>
                          <div className="relative">
                            <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#64748b]" />
                            <select
                              id="preferredBatch"
                              name="preferredBatch"
                              value={formData.preferredBatch}
                              onChange={handleChange}
                              className={`w-full pl-12 pr-4 py-4 bg-white border-2 rounded-xl text-base focus:outline-none transition-all appearance-none ${
                                errors.preferredBatch ? "border-red-500" : "border-gray-200 focus:border-[#0066FF]"
                              }`}
                            >
                              <option value="">Select Batch</option>
                              <option value="december-2024">December 2024</option>
                              <option value="january-2025">January 2025</option>
                              <option value="february-2025">February 2025</option>
                              <option value="march-2025">March 2025</option>
                            </select>
                          </div>
                          {errors.preferredBatch && (
                            <p className="mt-2 text-sm text-red-600 flex items-center gap-2">
                              <AlertCircle className="size-4" />
                              {errors.preferredBatch}
                            </p>
                          )}
                        </div>
                      </form>

                      {/* Navigation */}
                      <div className="flex gap-4 mt-10">
                        <motion.button
                          onClick={() => setCurrentStep(1)}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className="flex-1 px-8 py-4 bg-gray-100 text-[#0A0A0A] rounded-xl font-semibold hover:bg-gray-200 transition-all"
                        >
                          Back
                        </motion.button>
                        <motion.button
                          onClick={handleNext}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className="flex-1 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold shadow-xl hover:shadow-2xl transition-all flex items-center justify-center gap-3"
                        >
                          <span>Continue</span>
                          <ArrowRight className="size-5" />
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Step 3: Review & Submit */}
                {currentStep === 3 && selectedProgram && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5 }}
                    className="max-w-3xl mx-auto"
                  >
                    <div className="bg-white rounded-2xl border-2 border-gray-100 shadow-lg p-8 lg:p-10">
                      <h2 className="text-3xl font-extrabold text-[#0A0A0A] mb-2">
                        Your Application Is Ready to Submit
                      </h2>
                      <p className="text-[#64748b] mb-8">
                        Please review your details before submitting
                      </p>

                      {/* Summary Card */}
                      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 mb-8 border-2 border-[#0066FF]/20">
                        <div className="flex items-start gap-4 mb-6">
                          <div className="size-14 rounded-xl bg-[#0066FF]/10 flex items-center justify-center flex-shrink-0">
                            <selectedProgram.icon className="size-7 text-[#0066FF]" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-bold text-[#0A0A0A] mb-1">{selectedProgram.name}</h3>
                            <p className="text-sm text-[#64748b]">{selectedProgram.category}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Duration</p>
                            <p className="font-semibold text-[#0A0A0A]">{selectedProgram.duration}</p>
                          </div>
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Level</p>
                            <p className="font-semibold text-[#0A0A0A]">{selectedProgram.level}</p>
                          </div>
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Fees</p>
                            <p className="font-semibold text-[#0A0A0A]">{selectedProgram.fees}</p>
                          </div>
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Next Batch</p>
                            <p className="font-semibold text-[#0A0A0A]">{selectedProgram.nextBatch}</p>
                          </div>
                        </div>
                      </div>

                      {/* Personal Details */}
                      <div className="bg-white rounded-2xl border-2 border-gray-200 p-6 mb-8">
                        <h4 className="font-bold text-[#0A0A0A] mb-4 flex items-center gap-2">
                          <User className="size-5 text-[#0066FF]" />
                          Personal Information
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Full Name</p>
                            <p className="font-semibold text-[#0A0A0A]">{formData.fullName}</p>
                          </div>
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Email</p>
                            <p className="font-semibold text-[#0A0A0A]">{formData.email}</p>
                          </div>
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Mobile</p>
                            <p className="font-semibold text-[#0A0A0A]">{formData.mobile}</p>
                          </div>
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">District</p>
                            <p className="font-semibold text-[#0A0A0A]">{formData.district}</p>
                          </div>
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Education</p>
                            <p className="font-semibold text-[#0A0A0A]">{formData.education}</p>
                          </div>
                          <div>
                            <p className="text-xs text-[#64748b] mb-1">Preferred Batch</p>
                            <p className="font-semibold text-[#0A0A0A]">{formData.preferredBatch}</p>
                          </div>
                        </div>
                      </div>

                      {/* Terms */}
                      <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4 mb-8">
                        <div className="flex items-start gap-3">
                          <Shield className="size-5 text-amber-600 flex-shrink-0 mt-0.5" />
                          <div className="text-sm text-amber-900">
                            By submitting this application, you agree to our Terms of Service and Privacy Policy. Your information will be used only for application processing and communication purposes.
                          </div>
                        </div>
                      </div>

                      {/* Navigation */}
                      <div className="flex gap-4">
                        <motion.button
                          onClick={() => setCurrentStep(2)}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className="flex-1 px-8 py-4 bg-gray-100 text-[#0A0A0A] rounded-xl font-semibold hover:bg-gray-200 transition-all"
                        >
                          Back
                        </motion.button>
                        <motion.button
                          onClick={handleSubmit}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className="flex-1 px-8 py-4 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-xl font-bold shadow-xl hover:shadow-2xl transition-all flex items-center justify-center gap-3"
                        >
                          <CheckCircle2 className="size-5" />
                          <span>Submit Application</span>
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            </>
          )}
        </div>
      </section>

      {/* Contact Support Section */}
      {!formSubmitted && (
        <section className="py-16 bg-[#F3F6F9]">
          <div className="max-w-[1200px] mx-auto px-8">
            <div className="bg-white rounded-2xl border-2 border-gray-100 shadow-lg p-8 lg:p-10">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-extrabold text-[#0A0A0A] mb-2">
                  Need Assistance?
                </h3>
                <p className="text-[#64748b]">
                  Our admissions team is ready to help you
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                <motion.a
                  href="tel:+91XXXXXXXXXX"
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-4 bg-gradient-to-br from-blue-50 to-indigo-50 p-5 rounded-xl border-2 border-[#0066FF]/20 hover:border-[#0066FF]/40 transition-all"
                >
                  <div className="size-12 bg-[#0066FF] rounded-xl flex items-center justify-center flex-shrink-0">
                    <Phone className="size-6 text-white" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-[#64748b] mb-1">Call Us</p>
                    <p className="font-bold text-[#0A0A0A]">+91 XXXXX XXXXX</p>
                  </div>
                </motion.a>

                <motion.a
                  href="mailto:admissions@tnautoskills.org"
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-4 bg-gradient-to-br from-blue-50 to-indigo-50 p-5 rounded-xl border-2 border-[#0066FF]/20 hover:border-[#0066FF]/40 transition-all"
                >
                  <div className="size-12 bg-[#0066FF] rounded-xl flex items-center justify-center flex-shrink-0">
                    <Mail className="size-6 text-white" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-[#64748b] mb-1">Email Us</p>
                    <p className="font-bold text-[#0A0A0A] text-sm">admissions@tnautoskills.org</p>
                  </div>
                </motion.a>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
