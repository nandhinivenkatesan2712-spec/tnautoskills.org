import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function ModernHero() {
  return (
    <section className="relative py-16 lg:py-20 bg-gradient-to-b from-white to-[#F8FAFB] overflow-hidden">
      {/* Subtle Floating Shapes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ y: [0, -20, 0], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-20 right-[15%] w-64 h-64 bg-gradient-to-br from-[#0066FF]/10 to-transparent rounded-full blur-3xl"
        />
        <motion.div
          animate={{ y: [0, 30, 0], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute bottom-20 left-[10%] w-48 h-48 bg-gradient-to-tr from-[#0090FF]/10 to-transparent rounded-full blur-3xl"
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-[58%_42%] gap-12 items-center">
          
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#0066FF]/8 rounded-full"
            >
              <div className="size-1.5 bg-[#0066FF] rounded-full animate-pulse" />
              <span className="text-sm font-semibold text-[#0066FF]">Learn. Skill. Grow.</span>
            </motion.div>

            {/* English Title */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] leading-[1.1]"
            >
              Transforming Automotive
              <br />
              Talent for the Future
            </motion.h1>

            {/* Tamil Title */}
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-2xl lg:text-4xl font-bold text-[#0A0A0A]/75 leading-tight"
            >
              ஆட்டோமொபைல் திறன் மேம்பாட்டின் புதிய எதிர்காலத்தை உருவாக்குகிறோம்
            </motion.h2>

            {/* Subheading */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-base lg:text-lg text-[#475569] leading-relaxed max-w-xl"
            >
              A Government initiative empowering next-generation automotive workforce across OEMs, suppliers, retail networks, and mobility startups.
            </motion.p>

            {/* Tagline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="text-sm lg:text-base text-[#0066FF] font-semibold"
            >
              Your Journey to an Automotive Career Starts Here.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex flex-wrap gap-4 pt-2"
            >
              <a
                href="#programs"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#0066FF] text-white rounded-lg font-semibold text-sm shadow-md hover:shadow-lg hover:bg-[#0055DD] transition-all"
              >
                <span>Explore Programs</span>
                <ArrowRight className="size-4" />
              </a>
              <a
                href="#apply"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-white text-[#0066FF] border-2 border-[#0066FF] rounded-lg font-semibold text-sm hover:bg-[#0066FF]/5 transition-all"
              >
                <span>Apply Now</span>
                <ArrowRight className="size-4" />
              </a>
            </motion.div>

            {/* Impact Stats */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.7 }}
              className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-6"
            >
              {[
                { value: "2500+", label: "Trained" },
                { value: "500+", label: "Assessed" },
                { value: "200+", label: "Placed" },
                { value: "40+", label: "Industry Partners" },
              ].map((stat, idx) => (
                <div key={idx} className="text-center lg:text-left">
                  <div className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A]">{stat.value}</div>
                  <div className="text-xs text-[#64748B] font-medium">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right Image Block */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="relative hidden lg:block"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-gray-100">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1690356107486-0796de806f63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvbW90aXZlJTIwdHJhaW5pbmclMjBzdHVkZW50cyUyMG1lY2hhbmljJTIwd29ya3Nob3B8ZW58MXx8fHwxNzYzNjE4OTExfDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Empowering the Future of Automotive Skills"
                className="w-full h-[480px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0066FF]/20 to-transparent" />
            </div>

            {/* Floating Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.9 }}
              className="absolute -bottom-6 -left-6 bg-white rounded-xl p-5 shadow-lg border border-gray-100 max-w-[200px]"
            >
              <div className="text-sm font-medium text-[#64748B] mb-1">Success Rate</div>
              <div className="text-3xl font-extrabold text-[#0066FF]">95%</div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}