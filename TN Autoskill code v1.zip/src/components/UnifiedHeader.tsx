import { motion } from "motion/react";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import imgLogo1 from "figma:asset/14f8e66972ba1a8006cc1445bbada7a653c5bac0.png";
import { CTAButton } from "./CTAButton";

const navItems = [
  { label: "Home", href: "#home" },
  { label: "Programs", href: "#programs" },
  { label: "Courses", href: "#courses" },
  { label: "Success Stories", href: "#success-stories" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export function UnifiedHeader() {
  const [activeItem, setActiveItem] = useState("Home");
  const [language, setLanguage] = useState<"EN" | "தமிழ்">("EN");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (label: string, href: string) => {
    setActiveItem(label);
    setMobileMenuOpen(false);
    
    // Handle navigation
    if (href === "#home") {
      window.location.hash = "";
    } else {
      window.location.hash = href;
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white shadow-md">
      {/* Slim Top Bar - Tamil & English Tagline */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 border-b border-blue-800">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-1 sm:py-1.5">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-2 text-center">
            <span
              className="text-white text-[9px] sm:text-[10px] lg:text-[11px] font-medium tracking-wide"
              style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
            >
              தமிழ்நாடு உயர்திறன் மேம்பாட்டு மையம் - ஆட்டோமொபைல்
            </span>
            <span className="hidden sm:inline text-white/60 text-xs">•</span>
            <span className="text-white/90 text-[9px] sm:text-[10px] lg:text-[11px] font-medium tracking-wider uppercase">
              Tamil Nadu Apex Skill Development Centre for Automobile
            </span>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-12 sm:h-14">
            {/* Left - Logo & Title */}
            <div className="flex items-center gap-2 sm:gap-3">
              <a
                href="#home"
                onClick={() => handleNavClick("Home", "#home")}
                className="flex items-center gap-2 sm:gap-3 cursor-pointer"
              >
                <img
                  src={imgLogo1}
                  alt="TN AutoSkills"
                  className="h-7 sm:h-8 lg:h-9 w-auto flex-shrink-0"
                />
                <div className="flex flex-col">
                  <span className="text-[#0b1220] font-bold text-xs sm:text-sm lg:text-[15px] leading-tight">
                    TN AutoSkills
                  </span>
                  <span className="hidden sm:block text-[#64748b] text-[10px] lg:text-[11px] leading-tight">
                    Skill Development Centre
                  </span>
                </div>
              </a>
            </div>

            {/* Center - Navigation Menu (Desktop) */}
            <nav className="hidden lg:flex items-center gap-0.5">
              {navItems.map((item) => (
                <motion.a
                  key={item.label}
                  href={item.href}
                  onClick={() => handleNavClick(item.label, item.href)}
                  whileHover={{ y: -1 }}
                  className={`relative px-3.5 py-1.5 rounded-lg text-[13px] font-medium transition-all ${
                    activeItem === item.label
                      ? "text-[#0066FF]"
                      : "text-[#475569] hover:text-[#0b1220]"
                  }`}
                >
                  {item.label}
                  {activeItem === item.label && (
                    <motion.div
                      layoutId="activeNav"
                      className="absolute bottom-0 left-2 right-2 h-0.5 bg-[#0066FF] rounded-full"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                </motion.a>
              ))}
            </nav>

            {/* Right - Language Toggle & Apply Button */}
            <div className="hidden lg:flex items-center gap-4">
              {/* Language Toggle - EN | தமிழ் */}
              <div className="flex items-center gap-1 px-3 py-1.5 bg-gray-50 rounded-lg border border-gray-200">
                <button
                  onClick={() => setLanguage("EN")}
                  className={`relative px-3 py-1.5 rounded-md text-[13px] font-semibold transition-all ${
                    language === "EN"
                      ? "text-[#0066FF]"
                      : "text-[#64748b] hover:text-[#0A0A0A]"
                  }`}
                >
                  EN
                  {language === "EN" && (
                    <motion.div
                      layoutId="languageIndicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0066FF] rounded-full"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
                <span className="text-gray-300">|</span>
                <button
                  onClick={() => setLanguage("தமிழ்")}
                  className={`relative px-3 py-1.5 rounded-md text-[13px] font-semibold transition-all ${
                    language === "தமிழ்"
                      ? "text-[#0066FF]"
                      : "text-[#64748b] hover:text-[#0A0A0A]"
                  }`}
                  style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
                >
                  தமிழ்
                  {language === "தமிழ்" && (
                    <motion.div
                      layoutId="languageIndicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0066FF] rounded-full"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
              </div>

              {/* CTA Button */}
              <CTAButton href="#apply" variant="primary" size="sm" className="hidden sm:flex">
                Apply Now
              </CTAButton>
            </div>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#475569] hover:text-[#0b1220] transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? (
                <X className="size-6" />
              ) : (
                <Menu className="size-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-gray-200 bg-white"
          >
            <nav className="px-4 py-4 space-y-1">
              {navItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={() => handleNavClick(item.label, item.href)}
                  className={`block px-4 py-3 rounded-lg text-sm font-medium transition-colors min-h-[44px] flex items-center ${
                    activeItem === item.label
                      ? "bg-blue-50 text-[#0066FF]"
                      : "text-[#475569] hover:bg-gray-50 hover:text-[#0b1220]"
                  }`}
                >
                  {item.label}
                </a>
              ))}

              {/* Mobile Language Toggle */}
              <div className="pt-2 pb-1">
                <div className="flex items-center gap-1 px-3 py-2 bg-gray-50 rounded-lg border border-gray-200">
                  <button
                    onClick={() => setLanguage("EN")}
                    className={`flex-1 relative px-3 py-2.5 rounded-md text-sm font-semibold transition-all min-h-[44px] flex items-center justify-center ${
                      language === "EN"
                        ? "text-[#0066FF] bg-white shadow-sm"
                        : "text-[#64748b]"
                    }`}
                  >
                    EN
                  </button>
                  <span className="text-gray-300">|</span>
                  <button
                    onClick={() => setLanguage("தமிழ்")}
                    className={`flex-1 relative px-3 py-2.5 rounded-md text-sm font-semibold transition-all min-h-[44px] flex items-center justify-center ${
                      language === "தமிழ்"
                        ? "text-[#0066FF] bg-white shadow-sm"
                        : "text-[#64748b]"
                    }`}
                    style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
                  >
                    தமிழ்
                  </button>
                </div>
              </div>

              <CTAButton href="#apply" onClick={() => setMobileMenuOpen(false)} variant="primary" size="md" className="w-full">
                Apply Now
              </CTAButton>
            </nav>
          </motion.div>
        )}
      </div>
    </header>
  );
}