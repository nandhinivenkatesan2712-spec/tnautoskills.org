import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import { 
  ArrowRight, 
  Clock, 
  Award, 
  Battery, 
  Wrench, 
  Settings,
  Zap,
  Users,
  Cog,
  Sparkles,
  Cpu,
  CircuitBoard,
  Truck,
  Hammer,
  Cable
} from "lucide-react";

// Course data with exact details as specified
const courses = [
  {
    id: 1,
    title: "Auto Electrical Maintenance — Junior Technician",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "ITI (Electrician / Auto Electrical / Electronics) OR Diploma/BE (EEE / Mechanical / Mechatronics)",
    description: "Comprehensive training in automotive electrical systems, diagnostics, and maintenance for modern vehicles.",
    icon: Battery,
    pastelColor: "from-[#FFE5F1] to-[#FFF0F8]", // Pastel pink
    pastelIconColor: "text-[#FF6B9D]",
    topics: [
      "Electrical system diagnostics",
      "Battery management systems",
      "Wiring and circuit analysis",
      "Automotive lighting systems",
      "Alternator and starter motor maintenance"
    ],
    skills: [
      "Electrical troubleshooting",
      "Circuit testing and repair",
      "Component replacement",
      "Safety protocols",
      "Digital multimeter operation"
    ],
    jobRoles: [
      "Auto Electrician",
      "Junior Electrical Technician",
      "Battery Maintenance Specialist",
      "Vehicle Electrical Repair Technician"
    ]
  },
  {
    id: 2,
    title: "Automotive CNC Operator (Machining Technician)",
    duration: "360 hours",
    nsqfLevel: "NSQF Level 4",
    eligibility: "ITI (Machinist / Turner / Fitter) OR Diploma (Mechanical / Production Engineering)",
    description: "Training in CNC machine operation, precision machining, and manufacturing of automotive components.",
    icon: Settings,
    pastelColor: "from-[#E0F2FE] to-[#F0F9FF]", // Pastel sky blue
    pastelIconColor: "text-[#38BDF8]",
    topics: [
      "CNC machine operations",
      "G-code and M-code programming",
      "Tool selection and setup",
      "Precision measurement",
      "Quality control procedures"
    ],
    skills: [
      "CNC machine operation",
      "Blueprint reading",
      "Precision machining",
      "Quality inspection",
      "Machine maintenance"
    ],
    jobRoles: [
      "CNC Operator",
      "Machining Technician",
      "Production Operator",
      "Quality Inspector"
    ]
  },
  {
    id: 3,
    title: "Battery Electric Vehicle (BEV) Technician — Jr. Technician",
    duration: "420 hours",
    nsqfLevel: "NSQF Level 4",
    eligibility: "ITI (Electrician / Electronics / Auto Electrical) OR Diploma/BE (EEE / Mechanical / Automobile)",
    description: "Specialized training in battery electric vehicle technology, maintenance, and high-voltage systems.",
    icon: Zap,
    pastelColor: "from-[#FEF3C7] to-[#FEF9E7]", // Pastel yellow
    pastelIconColor: "text-[#FBBF24]",
    topics: [
      "BEV architecture and components",
      "High-voltage safety protocols",
      "Battery pack diagnostics",
      "Electric motor systems",
      "Charging infrastructure"
    ],
    skills: [
      "EV diagnostics",
      "High-voltage safety",
      "Battery management",
      "Motor controller testing",
      "Charging system maintenance"
    ],
    jobRoles: [
      "EV Technician",
      "Battery Systems Specialist",
      "EV Service Advisor",
      "Charging Infrastructure Technician"
    ]
  },
  {
    id: 4,
    title: "CNC Programmer-cum-Setter — Milling & Turning",
    duration: "480 hours",
    nsqfLevel: "NSQF Level 5",
    eligibility: "ITI (Machinist / Turner) OR Diploma (Mechanical / Production / Manufacturing Engineering)",
    description: "Advanced CNC programming, machine setup, and precision manufacturing for milling and turning operations.",
    icon: Cpu,
    pastelColor: "from-[#DDD6FE] to-[#EDE9FE]", // Pastel purple
    pastelIconColor: "text-[#A78BFA]",
    topics: [
      "Advanced CNC programming",
      "CAD/CAM integration",
      "Machine setup and calibration",
      "Multi-axis machining",
      "Process optimization"
    ],
    skills: [
      "CNC programming",
      "CAD/CAM software",
      "Machine setup",
      "Tool path optimization",
      "Quality assurance"
    ],
    jobRoles: [
      "CNC Programmer",
      "CNC Setter",
      "Manufacturing Engineer",
      "Production Supervisor"
    ]
  },
  {
    id: 5,
    title: "Fitter — Fabrication",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "ITI (Fitter / Welder / Fabrication) OR 10th + 2 years experience",
    description: "Training in metal fabrication, fitting, assembly, and structural work for automotive applications.",
    icon: Wrench,
    pastelColor: "from-[#FFEDD5] to-[#FEF3E2]", // Pastel orange
    pastelIconColor: "text-[#FB923C]",
    topics: [
      "Metal cutting and shaping",
      "Welding techniques",
      "Blueprint interpretation",
      "Assembly procedures",
      "Quality standards"
    ],
    skills: [
      "Metal fabrication",
      "Welding and joining",
      "Precision fitting",
      "Hand and power tools",
      "Safety compliance"
    ],
    jobRoles: [
      "Fabrication Fitter",
      "Assembly Technician",
      "Structural Fitter",
      "Workshop Supervisor"
    ]
  },
  {
    id: 6,
    title: "Robot Operator & Programmer — Arc Welding",
    duration: "360 hours",
    nsqfLevel: "NSQF Level 4",
    eligibility: "ITI (Welder / Fitter / Electronics) OR Diploma (Mechanical / Electronics / Mechatronics)",
    description: "Specialized training in robotic arc welding systems, programming, and automated manufacturing.",
    icon: CircuitBoard,
    pastelColor: "from-[#CCFBF1] to-[#E0F2FE]", // Pastel teal
    pastelIconColor: "text-[#14B8A6]",
    topics: [
      "Robot programming fundamentals",
      "Arc welding processes",
      "Robot teach pendant operation",
      "Path planning and optimization",
      "Safety and maintenance"
    ],
    skills: [
      "Robot programming",
      "Welding parameter setup",
      "Path optimization",
      "Troubleshooting",
      "Quality control"
    ],
    jobRoles: [
      "Robot Operator",
      "Welding Programmer",
      "Automation Technician",
      "Production Engineer"
    ]
  },
  {
    id: 7,
    title: "Technician — Automotive Service (2 & 3 Wheelers)",
    duration: "300 hours",
    nsqfLevel: "NSQF Level 3",
    eligibility: "ITI (Mechanic / Auto Electrical / Electronics) OR 10th + interest in automotive",
    description: "Comprehensive service and maintenance training for two-wheeler and three-wheeler vehicles.",
    icon: Cog,
    pastelColor: "from-[#D1FAE5] to-[#ECFDF5]", // Pastel green
    pastelIconColor: "text-[#10B981]",
    topics: [
      "Engine diagnostics and repair",
      "Electrical system troubleshooting",
      "Brake and suspension systems",
      "Periodic maintenance",
      "Customer service basics"
    ],
    skills: [
      "Vehicle diagnostics",
      "Repair and maintenance",
      "Tool operation",
      "Customer communication",
      "Safety protocols"
    ],
    jobRoles: [
      "Two-Wheeler Technician",
      "Service Advisor",
      "Workshop Mechanic",
      "Auto Service Specialist"
    ]
  },
  {
    id: 8,
    title: "Light Motor Vehicle (LMV) Driving",
    duration: "120 hours",
    nsqfLevel: "NSQF Level 2",
    eligibility: "8th pass + Valid Learner's License",
    description: "Professional driving training for light motor vehicles with focus on safety and road regulations.",
    icon: Truck,
    pastelColor: "from-[#FCE7F3] to-[#FDF2F8]", // Pastel rose
    pastelIconColor: "text-[#F472B6]",
    topics: [
      "Vehicle controls and operations",
      "Traffic rules and regulations",
      "Defensive driving techniques",
      "Road safety awareness",
      "Practical driving sessions"
    ],
    skills: [
      "Safe driving",
      "Traffic awareness",
      "Vehicle handling",
      "Emergency response",
      "Road discipline"
    ],
    jobRoles: [
      "Professional Driver",
      "Cab Driver",
      "Delivery Driver",
      "Personal Chauffeur"
    ]
  },
  {
    id: 9,
    title: "Driving Enhancement Training — Women Auto Drivers (Pink Auto & E-Auto)",
    duration: "150 hours",
    nsqfLevel: "NSQF Level 2",
    eligibility: "Women candidates + Valid DL for two-wheeler OR Learner's License for auto",
    description: "Specialized driving training for women auto drivers focusing on safety, confidence, and entrepreneurship.",
    icon: Users,
    pastelColor: "from-[#E9D5FF] to-[#F3E8FF]", // Pastel lavender
    pastelIconColor: "text-[#C084FC]",
    topics: [
      "Auto rickshaw operations",
      "Electric auto technology",
      "Safety and self-defense",
      "Customer service",
      "Business management basics"
    ],
    skills: [
      "Auto driving proficiency",
      "Route planning",
      "Customer interaction",
      "Safety awareness",
      "Basic entrepreneurship"
    ],
    jobRoles: [
      "Pink Auto Driver",
      "E-Auto Operator",
      "Self-Employed Driver",
      "Women Mobility Entrepreneur"
    ]
  }
];

// Course Card Component with proper hover handling
function CourseCard({ course, index, isInView }: { course: typeof courses[0]; index: number; isInView: boolean }) {
  const [isHovered, setIsHovered] = useState(false);
  
  // Convert pastel gradient classes to actual colors
  const pastelGradients: Record<number, { from: string; to: string; iconColor: string }> = {
    1: { from: '#FFE5F1', to: '#FFF0F8', iconColor: '#FF6B9D' }, // Pastel pink
    2: { from: '#E0F2FE', to: '#F0F9FF', iconColor: '#38BDF8' }, // Pastel sky blue
    3: { from: '#FEF3C7', to: '#FEF9E7', iconColor: '#FBBF24' }, // Pastel yellow
    4: { from: '#DDD6FE', to: '#EDE9FE', iconColor: '#A78BFA' }, // Pastel purple
    5: { from: '#FFEDD5', to: '#FEF3E2', iconColor: '#FB923C' }, // Pastel orange
    6: { from: '#CCFBF1', to: '#E0F2FE', iconColor: '#14B8A6' }, // Pastel teal
    7: { from: '#D1FAE5', to: '#ECFDF5', iconColor: '#10B981' }, // Pastel green
    8: { from: '#FCE7F3', to: '#FDF2F8', iconColor: '#F472B6' }, // Pastel rose
    9: { from: '#E9D5FF', to: '#F3E8FF', iconColor: '#C084FC' }, // Pastel lavender
  };

  const pastel = pastelGradients[course.id];
  const IconComponent = course.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <a
        href={`#course/${course.id}`}
        className="group block h-full"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="h-full bg-white rounded-2xl border-2 border-[#E2E8F0] hover:border-[#0066FF]/20 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-[#0066FF]/10 p-8 flex flex-col">
          {/* Icon with Pastel Color by Default - CoE Style */}
          <div 
            className="p-4 rounded-xl w-fit mb-6 transition-all duration-300 shadow-sm"
            style={{
              background: `linear-gradient(to bottom right, ${pastel.from}, ${pastel.to})`
            }}
          >
            <IconComponent 
              className="size-7 transition-all duration-300" 
              strokeWidth={2}
              style={{
                color: pastel.iconColor
              }}
            />
          </div>

          {/* Title */}
          <h3 className="text-xl lg:text-2xl font-extrabold text-[#0A0A0A] mb-3 leading-tight">
            {course.title}
          </h3>

          {/* Duration & Level */}
          <div className="flex flex-wrap gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#EEF5FF] text-[#0066FF] rounded-lg text-xs font-semibold">
              <Clock className="size-3.5" />
              {course.duration}
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#F0FDF4] text-[#16A34A] rounded-lg text-xs font-semibold">
              <Award className="size-3.5" />
              {course.nsqfLevel}
            </span>
          </div>

          {/* Eligibility */}
          <div className="mb-4">
            <p className="text-xs text-[#64748B] font-medium mb-1">Eligibility:</p>
            <p className="text-[13px] text-[#475569] leading-[1.5]">
              {course.eligibility}
            </p>
          </div>

          {/* Description */}
          <p className="text-[15px] text-[#475569] leading-[1.6] mb-6 flex-grow">
            {course.description}
          </p>

          {/* View Details Button */}
          <button className="w-full px-5 py-3 bg-[#0066FF] text-white rounded-xl font-semibold text-sm hover:bg-[#0055DD] transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 min-h-[44px] group-hover:gap-3">
            <span>View Details</span>
            <ArrowRight className="size-4 transition-transform" />
          </button>
        </div>
      </a>
    </motion.div>
  );
}

export function CoursesPage() {
  const heroRef = useRef(null);
  const gridRef = useRef(null);
  const isHeroInView = useInView(heroRef, { once: true, margin: "-100px" });
  const isGridInView = useInView(gridRef, { once: true, margin: "-100px" });

  return (
    <div className="min-h-screen bg-white">
      {/* Main Courses Section - Courses are the immediate focus */}
      <section className="py-[120px] bg-white relative">
        {/* Subtle Section Divider Top */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />

        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          {/* Compact Section Header - Similar to About Page */}
          <motion.div
            ref={heroRef}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16 space-y-4"
          >
            <h1 className="text-5xl lg:text-6xl font-extrabold text-[#0066FF] tracking-tight">
              Courses
            </h1>
            <p className="text-lg lg:text-xl text-[#475569] leading-[1.6] max-w-3xl mx-auto">
              Explore Industry-Ready Training Programs
            </p>
          </motion.div>

          {/* Courses Grid */}
          <div ref={gridRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, index) => (
              <CourseCard key={course.id} course={course} index={index} isInView={isGridInView} />
            ))}

            {/* Coming Soon Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isGridInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: courses.length * 0.1 }}
            >
              <div className="h-full bg-gradient-to-br from-[#F3F6F9] to-[#EEF5FF] rounded-2xl border-2 border-dashed border-[#0066FF]/30 p-6 flex flex-col items-center justify-center text-center min-h-[400px]">
                <div className="size-16 bg-white rounded-2xl flex items-center justify-center mb-4 shadow-sm">
                  <Sparkles className="size-8 text-[#0066FF]" strokeWidth={2} />
                </div>
                
                <h3 className="text-xl font-bold text-[#0A0A0A] mb-2">
                  More Courses Coming Soon
                </h3>
                
                <p className="text-sm text-[#64748B] max-w-xs">
                  We're continuously adding new industry-aligned programs to meet evolving automotive sector needs
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-[#0066FF] to-[#0090FF] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-[1200px] mx-auto px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl lg:text-5xl font-extrabold text-white mb-6">
              Ready to Start Your Journey?
            </h2>
            
            <p className="text-lg lg:text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join TN AutoSkills and transform your career with industry-leading automotive training
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="#apply"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white text-[#0066FF] rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl transition-all min-h-[44px] inline-flex items-center justify-center gap-2"
              >
                <span>Apply Now</span>
                <ArrowRight className="size-5" />
              </motion.a>

              <motion.a
                href="#contact"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white/20 backdrop-blur-md border-2 border-white text-white rounded-2xl font-semibold text-base hover:bg-white hover:text-[#0066FF] transition-all shadow-lg min-h-[44px] inline-flex items-center justify-center gap-2"
              >
                <span>Contact Us</span>
                <ArrowRight className="size-5" />
              </motion.a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

// Export course data for use in detail pages
export { courses };