import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { GraduationCap, Handshake, Lightbulb } from "lucide-react";
import { SectionIndicator } from "./SectionIndicator";

const services = [
  {
    icon: GraduationCap,
    title: "Skill Development",
    description:
      "Comprehensive training programs designed to equip learners with industry-relevant automotive skills and certifications.",
    color: "from-blue-500 to-blue-600",
    bgColor: "bg-blue-50",
    iconColor: "text-blue-600",
  },
  {
    icon: Handshake,
    title: "Industry Partnerships",
    description:
      "Strategic collaborations with leading automotive companies to ensure curriculum alignment and placement opportunities.",
    color: "from-purple-500 to-purple-600",
    bgColor: "bg-purple-50",
    iconColor: "text-purple-600",
  },
  {
    icon: Lightbulb,
    title: "Innovation & R&D",
    description:
      "Cutting-edge research and development initiatives focused on emerging automotive technologies and sustainable mobility.",
    color: "from-green-500 to-green-600",
    bgColor: "bg-green-50",
    iconColor: "text-green-600",
  },
];

export function WhatWeDo() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="pt-20 pb-14 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-[1440px] mx-auto px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <SectionIndicator isInView={isInView} />
          <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
            What We Do
          </h2>
          <p className="text-lg xl:text-xl text-[#475569] max-w-3xl mx-auto">
            Our comprehensive approach to automotive skill development
          </p>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group relative bg-white rounded-2xl sm:rounded-3xl p-6 sm:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.12)] hover:shadow-[0_20px_60px_rgba(0,102,255,0.25)] transition-all duration-300 border border-gray-100"
              >
                {/* Gradient Glow on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-5 rounded-3xl transition-opacity duration-300`} />
                
                {/* Icon Container */}
                <div className={`relative w-16 h-16 ${service.bgColor} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className={`size-8 ${service.iconColor}`} strokeWidth={2} />
                </div>

                {/* Content */}
                <div className="relative space-y-4">
                  <h3 className="text-[#0b1220] text-2xl font-bold group-hover:text-[#0066FF] transition-colors duration-300">
                    {service.title}
                  </h3>
                  <p className="text-[#64748b] text-base leading-relaxed">
                    {service.description}
                  </p>
                </div>

                {/* Bottom Accent Line */}
                <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${service.color} rounded-b-3xl scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left`} />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}