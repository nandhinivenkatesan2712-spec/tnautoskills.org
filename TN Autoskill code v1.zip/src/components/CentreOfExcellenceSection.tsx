import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight, Zap, Microscope, Monitor, Wrench } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "EV & BS6 Centre of Excellence",
    description: "State-of-the-art facility for electric vehicle and BS6 technology training",
  },
  {
    icon: Microscope,
    title: "Advanced Labs",
    description: "Fully equipped laboratories with modern automotive diagnostic tools",
  },
  {
    icon: Monitor,
    title: "Simulation Tools",
    description: "Industry-standard simulation software for virtual training and testing",
  },
  {
    icon: Wrench,
    title: "Hands-On Infrastructure",
    description: "Real-world automotive equipment and vehicles for practical learning",
  },
];

export function CentreOfExcellenceSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
              <div className="size-2 bg-[#0066FF] rounded-full animate-pulse" />
              <span className="text-sm font-semibold text-[#0066FF]">
                Facilities
              </span>
            </div>

            <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
              Centre of Excellence
            </h2>

            <p className="text-lg lg:text-xl text-[#64748b] mb-8 leading-relaxed">
              Our world-class Centre of Excellence is equipped with cutting-edge technology and infrastructure to provide comprehensive automotive training.
            </p>

            {/* Features List */}
            <div className="space-y-4 mb-8">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, x: -20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                    className="flex items-start gap-4 p-4 bg-gradient-to-r from-gray-50 to-transparent rounded-xl hover:from-blue-50 transition-all"
                  >
                    <div className="size-12 bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <IconComponent className="size-6 text-[#0066FF]" />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#0A0A0A] mb-1">
                        {feature.title}
                      </h3>
                      <p className="text-sm text-[#64748b]">
                        {feature.description}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* CTA Button */}
            <motion.a
              href="#facilities"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-base shadow-xl hover:shadow-2xl transition-all"
            >
              <span>Explore Facilities</span>
              <ArrowRight className="size-5" />
            </motion.a>
          </motion.div>

          {/* Right: Visual Element */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            {/* Decorative Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#0066FF]/5 to-[#0090FF]/5 rounded-3xl" />
            
            {/* Grid of Feature Cards */}
            <div className="relative grid grid-cols-2 gap-4 p-8">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                    whileHover={{ scale: 1.05, rotate: 2 }}
                    className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100"
                  >
                    <div className="size-12 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl flex items-center justify-center mb-3">
                      <IconComponent className="size-6 text-white" />
                    </div>
                    <h4 className="font-bold text-[#0A0A0A] text-sm leading-tight">
                      {feature.title.split(' ').slice(0, 2).join(' ')}
                    </h4>
                  </motion.div>
                );
              })}
            </div>

            {/* Decorative Elements */}
            <motion.div
              animate={{
                rotate: [0, 360],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 20,
                repeat: Infinity,
                ease: "linear",
              }}
              className="absolute -bottom-10 -right-10 size-40 bg-[#0066FF]/5 rounded-full blur-3xl -z-10"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
