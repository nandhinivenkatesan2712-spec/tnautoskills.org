import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Target,
  Award,
  TrendingUp,
  Users,
  GraduationCap,
  Wrench,
  Briefcase,
  Handshake,
  Building2,
  BookOpen,
  Zap,
  Leaf,
  Cpu,
  Layers,
  Shield,
  CheckCircle,
  ChevronRight,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// 2. WHO WE ARE
export function ModernWhoWeAre() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section ref={ref} className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="space-y-5"
          >
            <div className="inline-block px-4 py-1.5 bg-[#0066FF]/8 rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide">
              About Us
            </div>

            <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A]">
              Who We Are
            </h2>

            <p className="text-base text-[#475569] leading-relaxed">
              <strong className="text-[#0A0A0A]">TN Auto Skills</strong> is a government initiative focused on developing industry-ready automotive talent across Tamil Nadu.
            </p>

            <div className="space-y-3">
              {[
                "Advanced, job-oriented training programs aligned with modern automobile technologies",
                "Bridge the skill gap and empower youth with hands-on learning",
                "Strong industry partnerships for career opportunities",
                "Continuous upskilling and real-world expertise",
              ].map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.1 + idx * 0.1 }}
                  className="flex items-start gap-3"
                >
                  <CheckCircle className="size-5 text-[#0066FF] flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-[#475569]">{item}</span>
                </motion.div>
              ))}
            </div>

            <a
              href="#about"
              className="inline-flex items-center gap-2 text-[#0066FF] font-semibold text-sm hover:gap-3 transition-all"
            >
              <span>Read More</span>
              <ChevronRight className="size-4" />
            </a>
          </motion.div>

          {/* Right Image */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=700&h=450&fit=crop"
                alt="Automotive training"
                className="w-full h-[380px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0066FF]/10 to-transparent" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// 3. EXPLORE WHAT WE ARE DOING
export function ModernExploreServices() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const services = [
    {
      icon: GraduationCap,
      title: "Industry-Aligned Training",
      description: "Government-certified automotive programs based on evolving industry standards.",
      gradient: "from-blue-500 to-indigo-500",
    },
    {
      icon: Wrench,
      title: "Hands-On Workshops",
      description: "Practical sessions with advanced labs and real-world automotive tools.",
      gradient: "from-indigo-500 to-purple-500",
    },
    {
      icon: Briefcase,
      title: "Career & Placement",
      description: "Placement support with leading companies, counseling, and interview prep.",
      gradient: "from-purple-500 to-pink-500",
    },
    {
      icon: Handshake,
      title: "Industry Partnerships",
      description: "Collaborate with OEMs, suppliers, and institutions to build workforce.",
      gradient: "from-pink-500 to-rose-500",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-[#F8FAFB]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-white rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4 shadow-sm">
            Our Services
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Explore What We Are Doing
          </h2>
          <p className="text-base text-[#64748B] max-w-2xl mx-auto">
            Comprehensive programs designed to develop automotive talent and bridge the industry skill gap
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, idx) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -6, scale: 1.02 }}
                className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-xl transition-all border border-gray-100"
              >
                <div className={`size-12 bg-gradient-to-br ${service.gradient} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="size-6 text-white" />
                </div>
                <h3 className="font-bold text-[#0A0A0A] mb-2">{service.title}</h3>
                <p className="text-sm text-[#64748B] leading-relaxed">{service.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 4. EMPOWERING STAKEHOLDERS
export function ModernStakeholders() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const stakeholders = [
    {
      icon: Users,
      title: "Candidates",
      description: "Access government-certified training, hands-on skills, and direct placement opportunities.",
      color: "bg-blue-500",
    },
    {
      icon: Building2,
      title: "Industry",
      description: "Partner with us to build a skilled workforce aligned with your technology needs.",
      color: "bg-indigo-500",
    },
    {
      icon: BookOpen,
      title: "Academia",
      description: "Collaborate on curriculum development and provide students with industry exposure.",
      color: "bg-purple-500",
    },
    {
      icon: Award,
      title: "Trainers & Assessors",
      description: "Join our network of certified professionals delivering world-class training.",
      color: "bg-pink-500",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-[#0066FF]/8 rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4">
            Stakeholders
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A]">
            Empowering Every Stakeholder
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stakeholders.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all border border-gray-100 cursor-pointer"
              >
                <div className={`size-12 ${item.color} rounded-lg flex items-center justify-center mb-4`}>
                  <Icon className="size-6 text-white" />
                </div>
                <h3 className="font-bold text-[#0A0A0A] mb-2">{item.title}</h3>
                <p className="text-sm text-[#64748B] leading-relaxed">{item.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 5. FEATURED TRAINING PROGRAMS
export function ModernFeaturedPrograms() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const programs = [
    {
      image: "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=500&h=300&fit=crop",
      badge: "EV Technology",
      title: "Electric Vehicle Systems",
      description: "Learn EV systems, battery technology, and charging infrastructure.",
    },
    {
      image: "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=500&h=300&fit=crop",
      badge: "Core Program",
      title: "Automotive Service Technician",
      description: "Master vehicle diagnostics, repair, and maintenance techniques.",
    },
    {
      image: "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d6?w=500&h=300&fit=crop",
      badge: "Advanced",
      title: "Connected Vehicle Systems",
      description: "Explore IoT, telematics, and smart vehicle technology.",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-[#F8FAFB]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-white rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4 shadow-sm">
            Programs
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Featured Training Programs
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {programs.map((program, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              whileHover={{ y: -6 }}
              className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all"
            >
              <div className="relative h-48">
                <ImageWithFallback
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute top-4 left-4 px-3 py-1 bg-white/90 backdrop-blur-sm text-xs font-bold text-[#0066FF] rounded-full">
                  {program.badge}
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-bold text-[#0A0A0A] mb-2">{program.title}</h3>
                <p className="text-sm text-[#64748B] mb-4">{program.description}</p>
                <a
                  href="#programs"
                  className="inline-flex items-center gap-1 text-sm font-semibold text-[#0066FF] hover:gap-2 transition-all"
                >
                  <span>Learn More</span>
                  <ChevronRight className="size-4" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center"
        >
          <a
            href="#programs"
            className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#0066FF] text-white rounded-lg font-semibold text-sm shadow-md hover:shadow-lg hover:bg-[#0055DD] transition-all"
          >
            <span>View All Programs</span>
            <ChevronRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 6. CENTRE OF EXCELLENCE
export function ModernCentreOfExcellence() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const features = [
    { icon: Zap, title: "EV & Hybrid Labs", description: "State-of-the-art electric vehicle training facilities" },
    { icon: Cpu, title: "Smart Connected Vehicles", description: "IoT and telematics technology workshops" },
    { icon: Shield, title: "BS6 Compliance", description: "Latest emission standards training" },
    { icon: Award, title: "Industry Certification", description: "Government-recognized credentials" },
  ];

  return (
    <section ref={ref} className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-[#0066FF]/8 rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4">
            Facilities
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Centre of Excellence
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            State-of-the-art training facilities equipped with modern automotive technologies and industry-standard equipment
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="bg-gradient-to-br from-[#0066FF] to-[#0090FF] text-white rounded-xl p-6 shadow-lg hover:shadow-2xl transition-all"
              >
                <div className="size-12 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center mb-4">
                  <Icon className="size-6 text-white" />
                </div>
                <h3 className="font-bold mb-2">{feature.title}</h3>
                <p className="text-sm text-white/80">{feature.description}</p>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-10"
        >
          <a
            href="#facilities"
            className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#0066FF] text-white rounded-lg font-semibold text-sm shadow-md hover:shadow-lg hover:bg-[#0055DD] transition-all"
          >
            <span>Explore Facilities</span>
            <ChevronRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 7. GLOBAL CURRICULUM
export function ModernGlobalCurriculum() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const frameworks = [
    { icon: Zap, title: "EV Framework", description: "Electric vehicle training modules", color: "from-yellow-400 to-orange-500" },
    { icon: Leaf, title: "Green/Flexi Fuel", description: "Sustainable automotive technologies", color: "from-green-400 to-emerald-500" },
    { icon: Cpu, title: "SDV Framework", description: "Software-defined vehicle systems", color: "from-blue-400 to-indigo-500" },
    { icon: Layers, title: "Vehicle Architecture", description: "Modern automotive design principles", color: "from-purple-400 to-pink-500" },
  ];

  return (
    <section ref={ref} className="py-16 bg-[#F8FAFB]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1.5 bg-white rounded-full text-xs font-semibold text-[#0066FF] uppercase tracking-wide mb-4 shadow-sm">
            Curriculum
          </div>
          <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
            Global Automotive Curriculum Framework
          </h2>
          <p className="text-base text-[#64748B] max-w-3xl mx-auto">
            Our training programs are based on internationally recognized automotive curriculum standards
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {frameworks.map((framework, idx) => {
            const Icon = framework.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all border border-gray-100"
              >
                <div className={`size-12 bg-gradient-to-br ${framework.color} rounded-lg flex items-center justify-center mb-4`}>
                  <Icon className="size-6 text-white" />
                </div>
                <h3 className="font-bold text-[#0A0A0A] mb-2">{framework.title}</h3>
                <p className="text-sm text-[#64748B]">{framework.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
