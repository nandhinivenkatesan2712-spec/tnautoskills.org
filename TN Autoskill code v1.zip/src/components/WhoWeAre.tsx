import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Target, Users, Award, TrendingUp } from "lucide-react";
import { CTAButton } from "./CTAButton";

export function WhoWeAre() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
            <div className="size-2 bg-[#0066FF] rounded-full" />
            <span className="text-sm font-semibold text-[#0066FF]">About Us</span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
            Who We Are
          </h2>

          <div className="max-w-4xl mx-auto space-y-6 text-lg lg:text-xl text-[#475569] leading-relaxed">
            <p>
              <strong className="text-[#0A0A0A]">TN Auto Skills</strong> is a government initiative focused on developing industry-ready automotive talent across Tamil Nadu.
            </p>
            <p>
              We offer advanced, job-oriented training programs aligned with modern automobile technologies and industry standards.
            </p>
            <p>
              Our mission is to bridge the skill gap and empower youth with hands-on learning and real-world expertise.
            </p>
            <p>
              Through strong industry partnerships, we provide career opportunities, internships, and continuous upskilling.
            </p>
          </div>

          <CTAButton href="#about" variant="primary" size="lg" className="mt-10">
            Read More
          </CTAButton>
        </motion.div>

        {/* Key Highlights Grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16"
        >
          {[
            {
              icon: Target,
              title: "Industry-Aligned",
              description: "Training programs designed with industry standards",
            },
            {
              icon: Users,
              title: "Expert Trainers",
              description: "Learn from experienced automotive professionals",
            },
            {
              icon: Award,
              title: "Certified Programs",
              description: "Government-recognized certifications",
            },
            {
              icon: TrendingUp,
              title: "Career Growth",
              description: "Placement support and career guidance",
            },
          ].map((item, index) => {
            const IconComponent = item.icon;
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                whileHover={{ y: -5, scale: 1.02 }}
                className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-100 shadow-sm hover:shadow-lg transition-all"
              >
                <div className="size-14 bg-gradient-to-br from-[#004ABB] to-[#0055DD] rounded-xl flex items-center justify-center mb-4 shadow-lg">
                  <IconComponent className="size-7 text-white" strokeWidth={2} />
                </div>
                <h3 className="text-lg font-bold text-[#0A0A0A] mb-2">
                  {item.title}
                </h3>
                <p className="text-sm text-[#64748b]">{item.description}</p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}