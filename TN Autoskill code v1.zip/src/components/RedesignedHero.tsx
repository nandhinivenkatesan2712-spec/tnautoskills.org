import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { ArrowRight, Users, Award, Briefcase, Building2 } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function RedesignedHero() {
  const ref = useRef(null);
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  // Subtle parallax for image
  const imageY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0.9]);

  return (
    <section
      ref={ref}
      className="relative min-h-[75vh] lg:min-h-[80vh] flex items-center overflow-hidden bg-gradient-to-br from-[#F8FAFF] via-white to-[#F3F8FF]"
    >
      {/* Minimal Floating Shapes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Soft Blue Gradient Blob - Top Right */}
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.4, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute -top-32 -right-32 w-96 h-96 bg-gradient-to-br from-[#0066FF]/20 to-[#0090FF]/10 rounded-full blur-3xl"
        />

        {/* Soft Blue Gradient Blob - Bottom Left */}
        <motion.div
          animate={{
            scale: [1, 1.15, 1],
            opacity: [0.2, 0.3, 0.2],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute -bottom-32 -left-32 w-80 h-80 bg-gradient-to-tr from-[#0090FF]/15 to-transparent rounded-full blur-3xl"
        />

        {/* Small Glass Shape - Floating */}
        <motion.div
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-1/4 right-[30%] w-32 h-32 bg-white/40 backdrop-blur-md rounded-3xl shadow-lg border border-white/60"
          style={{ transform: "rotate(-15deg)" }}
        />

        {/* Tiny Accent Circle */}
        <motion.div
          animate={{
            y: [0, 15, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute bottom-1/3 right-[25%] w-16 h-16 bg-[#0066FF]/10 rounded-full blur-xl"
        />
      </div>

      {/* Main Content Container */}
      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-12 py-12 lg:py-16 w-full z-10">
        <div className="grid lg:grid-cols-[60%_40%] gap-8 lg:gap-12 items-center">
          
          {/* LEFT SECTION - Text Block */}
          <motion.div
            style={{ opacity }}
            className="space-y-6 lg:space-y-7"
          >
            {/* Tagline Badge */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="inline-flex items-center gap-2 px-5 py-2 bg-[#0066FF]/5 rounded-full border border-[#0066FF]/10"
            >
              <div className="size-1.5 bg-[#0066FF] rounded-full" />
              <span className="text-sm font-semibold text-[#0066FF]">
                Learn. Skill. Grow.
              </span>
            </motion.div>

            {/* Main Title - English */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] leading-[1.15] tracking-tight"
            >
              Empowering the Future
              <br />
              of Automotive Skills
            </motion.h1>

            {/* Main Title - Tamil */}
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-xl sm:text-2xl lg:text-3xl font-bold text-[#0A0A0A]/80 leading-snug"
              style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
            >
              ஆட்டோமொபைல் திறன் மேம்பாட்டின் புதிய எதிர்காலத்தை உருவாக்குகிறோம்
            </motion.h2>

            {/* Subheading */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-base lg:text-lg text-[#0A0A0A]/70 leading-relaxed max-w-2xl font-medium"
            >
              Government-certified training programs designed to uplift youth and strengthen the automotive workforce across Tamil Nadu.
            </motion.p>

            {/* Secondary Tagline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="text-sm lg:text-base text-[#0066FF] font-semibold"
            >
              Your Journey to an Automotive Career Starts Here.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 pt-2"
            >
              {/* Primary CTA */}
              <motion.a
                href="#programs"
                whileHover={{ scale: 1.03, y: -1 }}
                whileTap={{ scale: 0.98 }}
                className="group px-7 py-3.5 bg-[#0066FF] text-white rounded-xl font-bold text-base shadow-lg hover:shadow-xl hover:bg-[#0055EE] transition-all flex items-center justify-center gap-2 min-w-[200px]"
              >
                <span>Explore Programs</span>
                <ArrowRight className="size-5 group-hover:translate-x-1 transition-transform" />
              </motion.a>

              {/* Secondary CTA */}
              <motion.a
                href="#apply"
                whileHover={{ scale: 1.03, y: -1 }}
                whileTap={{ scale: 0.98 }}
                className="group px-7 py-3.5 bg-white text-[#0066FF] border-2 border-[#0066FF] rounded-xl font-bold text-base hover:bg-[#0066FF]/5 transition-all flex items-center justify-center gap-2 min-w-[200px]"
              >
                <span>Apply Now</span>
                <ArrowRight className="size-5 group-hover:translate-x-1 transition-transform" />
              </motion.a>
            </motion.div>

            {/* Compact Stats Row */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.7 }}
              className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-4"
            >
              {[
                { icon: Users, value: "2500+", label: "Trained" },
                { icon: Award, value: "500+", label: "Assessed" },
                { icon: Briefcase, value: "200+", label: "Placed" },
                { icon: Building2, value: "40+", label: "Industry Partners" },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.8 + index * 0.05 }}
                  className="flex flex-col items-start gap-1"
                >
                  <div className="flex items-center gap-2">
                    <div className="size-8 bg-[#0066FF]/10 rounded-lg flex items-center justify-center">
                      <stat.icon className="size-4 text-[#0066FF]" />
                    </div>
                    <div className="text-2xl font-extrabold text-[#0A0A0A]">
                      {stat.value}
                    </div>
                  </div>
                  <div className="text-xs text-[#0A0A0A]/60 font-semibold">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* RIGHT SECTION - Small Image Frame */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="relative hidden lg:flex justify-end"
          >
            {/* Subtle Glow Behind Image */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/5 rounded-2xl blur-2xl scale-105" />

            {/* Image Container */}
            <motion.div
              style={{ y: imageY }}
              className="relative w-full max-w-[420px] h-[420px] rounded-2xl overflow-hidden shadow-xl border border-[#0066FF]/10 bg-white"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=600&h=600&fit=crop"
                alt="Automotive training workshop with students"
                className="w-full h-full object-cover"
              />
              
              {/* Subtle Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0066FF]/20 to-transparent" />

              {/* Minimal Corner Badge */}
              <div className="absolute top-4 right-4 size-12 bg-white/95 backdrop-blur-sm rounded-xl shadow-lg flex items-center justify-center border border-white/60">
                <Award className="size-6 text-[#0066FF]" />
              </div>

              {/* Small Info Card */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1 }}
                className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md rounded-xl p-4 shadow-lg border border-white/60"
              >
                <div className="flex items-center gap-3">
                  <div className="size-10 bg-[#0066FF] rounded-lg flex items-center justify-center flex-shrink-0">
                    <Users className="size-5 text-white" />
                  </div>
                  <div>
                    <div className="text-xl font-extrabold text-[#0066FF]">2500+</div>
                    <div className="text-xs font-semibold text-[#0A0A0A]/60">Students Trained</div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Subtle Bottom Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white/80 to-transparent pointer-events-none" />
    </section>
  );
}
