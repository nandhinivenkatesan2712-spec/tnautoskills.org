import { motion, useInView } from "motion/react";
import { useRef, useState, useEffect } from "react";
import { Factory, Settings, Store, Zap } from "lucide-react";
import svgPaths from "../imports/svg-q2wila3vzz";

export function EmploymentOpportunities() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [showCar, setShowCar] = useState(true);

  // Continuous loop animation - alternate between car and "Open"
  useEffect(() => {
    if (!isInView) return;

    const interval = setInterval(() => {
      setShowCar((prev) => !prev);
    }, 2000); // Switch every 2 seconds

    return () => clearInterval(interval);
  }, [isInView]);

  const opportunities = [
    {
      icon: Factory,
      title: "OEMs",
      description: "Innovation & skill development with manufacturers",
      position: "top",
    },
    {
      icon: Settings,
      title: "Auto Suppliers",
      description: "Tier-1 & Tier-2 automotive component partners",
      position: "right",
    },
    {
      icon: Store,
      title: "Retail Partners",
      description: "Dealership & mobility retail networks",
      position: "bottom",
    },
    {
      icon: Zap,
      title: "Startups",
      description: "Innovation and mobility startups for talent development",
      position: "left",
    },
  ];

  return (
    <section ref={ref} className="py-20 bg-white relative overflow-hidden">
      {/* Subtle Background Accent */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-[#0066FF]/5 to-transparent rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
        {/* Header - With Balanced Spacing */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-52"
        >
          <h2 className="text-4xl lg:text-[52px] font-extrabold text-[#0A1628] leading-tight mb-4">
            Employment
          </h2>
          <p className="text-xl lg:text-[22px] text-[#475569] font-medium leading-relaxed max-w-4xl mx-auto">
            Partner With TN AutoSkills Across OEMs, Auto Suppliers, Retail, And Startups
          </p>
        </motion.div>

        {/* Circular Hub Container - Centered with Proper Spacing */}
        <div className="relative max-w-[600px] mx-auto" style={{ height: "380px" }}>
          {/* Center Circle - Filled with Car Icon or "Open" Text */}
          <motion.div
            key={showCar ? "car" : "open"} // Key change triggers animation
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            transition={{ 
              duration: 0.4, 
              type: "spring", 
              stiffness: 200,
              damping: 15 
            }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full flex items-center justify-center z-10"
            style={{
              width: "64px",
              height: "64px",
              background: "linear-gradient(135deg, #004ABB 0%, #0055DD 100%)",
              boxShadow: "0 8px 24px -6px rgba(0, 74, 187, 0.35)",
            }}
          >
            {showCar ? (
              <motion.svg 
                width="32" 
                height="32" 
                fill="none" 
                viewBox="0 0 45 45"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <g>
                  <path
                    d={svgPaths.p1c831900}
                    stroke="white"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  />
                  <path
                    d={svgPaths.p26aab900}
                    stroke="white"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  />
                  <path
                    d="M16.7344 31.6094H27.8906"
                    stroke="white"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  />
                  <path
                    d={svgPaths.p32a83e80}
                    stroke="white"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  />
                </g>
              </motion.svg>
            ) : (
              <motion.p 
                className="text-white font-bold text-sm"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                Open
              </motion.p>
            )}
          </motion.div>

          {/* Inner Dashed Circle */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={
              isInView
                ? { scale: 1, opacity: 1, rotate: -360 }
                : { scale: 0.8, opacity: 0 }
            }
            transition={{
              scale: { duration: 0.7, delay: 0.2 },
              opacity: { duration: 0.7, delay: 0.2 },
              rotate: {
                duration: 20,
                repeat: Infinity,
                ease: "linear",
              },
            }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
            style={{ width: "160px", height: "160px" }}
          >
            <svg width="160" height="160" className="w-full h-full">
              <defs>
                <linearGradient id="innerCircle" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0066FF" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#0090FF" stopOpacity="0.2" />
                </linearGradient>
              </defs>
              <circle
                cx="80"
                cy="80"
                r="78"
                fill="none"
                stroke="url(#innerCircle)"
                strokeWidth="1.5"
                strokeDasharray="5 5"
                strokeLinecap="round"
              />
            </svg>
          </motion.div>

          {/* Outer Dashed Circle */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={
              isInView
                ? { scale: 1, opacity: 1, rotate: 360 }
                : { scale: 0.8, opacity: 0 }
            }
            transition={{
              scale: { duration: 0.7, delay: 0.1 },
              opacity: { duration: 0.7, delay: 0.1 },
              rotate: {
                duration: 30,
                repeat: Infinity,
                ease: "linear",
              },
            }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
            style={{ width: "240px", height: "240px" }}
          >
            <svg width="240" height="240" className="w-full h-full">
              <defs>
                <linearGradient id="outerCircle" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0066FF" stopOpacity="0.2" />
                  <stop offset="100%" stopColor="#0090FF" stopOpacity="0.15" />
                </linearGradient>
              </defs>
              <circle
                cx="120"
                cy="120"
                r="118"
                fill="none"
                stroke="url(#outerCircle)"
                strokeWidth="1.5"
                strokeDasharray="5 5"
                strokeLinecap="round"
              />
            </svg>
          </motion.div>

          {/* TOP - OEMs */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center text-center"
            style={{ top: "-90px", width: "160px" }}
          >
            <div className="size-11 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-xl flex items-center justify-center mb-2.5 shadow-sm">
              <Factory className="size-5 text-[#0066FF]" strokeWidth={2} />
            </div>
            <h3 className="font-bold text-[15px] text-[#0A1628] leading-tight mb-1">
              OEMs
            </h3>
            <p className="text-[13px] text-[#64748B] leading-snug">
              Innovation & skill development with manufacturers
            </p>
          </motion.div>

          {/* RIGHT - Auto Suppliers */}
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="absolute top-1/2 right-0 translate-x-1/2 -translate-y-1/2 flex flex-col items-center text-center"
            style={{ marginRight: "8px", width: "160px" }}
          >
            <div className="size-11 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-xl flex items-center justify-center mb-2.5 shadow-sm">
              <Settings className="size-5 text-[#0066FF]" strokeWidth={2} />
            </div>
            <h3 className="font-bold text-[15px] text-[#0A1628] leading-tight mb-1">
              Auto Suppliers
            </h3>
            <p className="text-[13px] text-[#64748B] leading-snug">
              Tier-1 & Tier-2 automotive component partners
            </p>
          </motion.div>

          {/* BOTTOM - Retail Partners */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center text-center"
            style={{ bottom: "-90px", width: "160px" }}
          >
            <div className="size-11 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-xl flex items-center justify-center mb-2.5 shadow-sm">
              <Store className="size-5 text-[#0066FF]" strokeWidth={2} />
            </div>
            <h3 className="font-bold text-[15px] text-[#0A1628] leading-tight mb-1">
              Retail Partners
            </h3>
            <p className="text-[13px] text-[#64748B] leading-snug">
              Dealership & mobility retail networks
            </p>
          </motion.div>

          {/* LEFT - Startups */}
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="absolute top-1/2 left-0 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center text-center"
            style={{ marginLeft: "8px", width: "160px" }}
          >
            <div className="size-11 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-xl flex items-center justify-center mb-2.5 shadow-sm">
              <Zap className="size-5 text-[#0066FF]" strokeWidth={2} />
            </div>
            <h3 className="font-bold text-[15px] text-[#0A1628] leading-tight mb-1">
              Startups
            </h3>
            <p className="text-[13px] text-[#64748B] leading-snug">
              Innovation and mobility startups for talent development
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}