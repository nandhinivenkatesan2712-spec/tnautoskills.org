import { motion } from "motion/react";

export function TamilBanner() {
  const tamilText = "தமிழ்நாடு உயர்திறன் மேம்பாட்டு மையம் - ஆட்டோமொபைல்";

  return (
    <div className="bg-white h-11 border-b border-gray-200 overflow-hidden">
      <motion.div
        animate={{ x: ["0%", "-50%"] }}
        transition={{
          duration: 40,
          repeat: Infinity,
          ease: "linear"
        }}
        className="flex items-center h-full gap-32 whitespace-nowrap"
        style={{ width: "fit-content" }}
      >
        {[...Array(20)].map((_, i) => (
          <span
            key={i}
            className="text-[#0f73f7] text-[15px]"
            style={{
              fontFamily: "'Noto Sans Tamil', sans-serif",
              fontVariationSettings: "'wdth' 100"
            }}
          >
            {tamilText}
          </span>
        ))}
      </motion.div>
    </div>
  );
}
