import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Users,
  Award,
  Briefcase,
  Building2,
  Target,
  TrendingUp,
  Quote,
  Star,
  ArrowRight,
  Heart,
  GraduationCap,
  UserPlus,
  CheckCircle,
  Cog,
  ShoppingCart,
  Lightbulb,
  BookOpen,
  Handshake,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// 8. OUR MILESTONES - Enhanced Stats Section
export function EnhancedMilestones() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stats = [
    { icon: Users, value: "2500+", label: "Students Trained", color: "from-blue-400 to-blue-600" },
    { icon: Award, value: "500+", label: "Certified Professionals", color: "from-indigo-400 to-indigo-600" },
    { icon: Briefcase, value: "200+", label: "Placements", color: "from-purple-400 to-purple-600" },
    { icon: Building2, value: "40+", label: "Industry Partners", color: "from-pink-400 to-pink-600" },
    { icon: Target, value: "95%", label: "Success Rate", color: "from-rose-400 to-rose-600" },
    { icon: TrendingUp, value: "10+", label: "Training Centers", color: "from-orange-400 to-orange-600" },
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-br from-[#0066FF] via-[#0055DD] to-[#0090FF] relative overflow-hidden">
      {/* Animated Background Patterns */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-white rounded-full blur-3xl" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14 text-white"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-md rounded-full border border-white/30 mb-5">
            <Star className="size-3.5 text-white" />
            <span className="text-xs font-bold uppercase tracking-wider">Achievements</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold mb-4 leading-[1.1] tracking-tight">
            Our Milestones
          </h2>

          <p className="text-lg text-white/90 max-w-2xl mx-auto leading-relaxed">
            Transforming automotive education across Tamil Nadu
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-5">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.8, y: 30 }}
                animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ scale: 1.08, y: -8 }}
                className="group relative"
              >
                {/* Card */}
                <div className="bg-white/15 backdrop-blur-md rounded-2xl p-6 border border-white/25 hover:bg-white/25 hover:border-white/40 transition-all text-center text-white">
                  {/* Icon with Gradient */}
                  <div className={`inline-flex items-center justify-center size-14 bg-gradient-to-br ${stat.color} rounded-xl mb-4 shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all`}>
                    <Icon className="size-7 text-white" strokeWidth={2.5} />
                  </div>

                  {/* Value */}
                  <div className="text-4xl font-extrabold mb-2">{stat.value}</div>

                  {/* Label */}
                  <div className="text-xs text-white/80 font-medium uppercase tracking-wide leading-tight">
                    {stat.label}
                  </div>
                </div>

                {/* Glow Effect */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-20 blur-xl transition-opacity -z-10 rounded-2xl`} />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 9. SUCCESS STORIES - Enhanced Testimonials
export function EnhancedSuccessStories() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stories = [
    {
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop",
      name: "Rajesh Kumar",
      role: "EV Technician",
      company: "Ather Energy",
      quote: "The hands-on training I received helped me secure my dream job in the EV industry.",
      rating: 5,
    },
    {
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&h=300&fit=crop",
      name: "Priya Sharma",
      role: "Automotive Engineer",
      company: "Hyundai",
      quote: "TN Auto Skills provided me with industry-relevant skills and direct placement support.",
      rating: 5,
    },
    {
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&h=300&fit=crop",
      name: "Arjun Patel",
      role: "Service Manager",
      company: "TVS Motors",
      quote: "The certification program opened doors to leadership roles in the automotive sector.",
      rating: 5,
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-br from-[#0066FF]/10 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#0090FF]/10 rounded-full border border-[#0066FF]/20 mb-5">
            <Quote className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Testimonials</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] leading-[1.1] tracking-tight">
            Success Stories
          </h2>
        </motion.div>

        {/* Stories Slider */}
        <div className="flex gap-7 overflow-x-auto pb-6 snap-x snap-mandatory scrollbar-hide -mx-6 px-6 lg:mx-0 lg:px-0">
          {stories.map((story, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: 50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              className="group min-w-[340px] lg:min-w-[380px] bg-gradient-to-br from-white to-gray-50 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all border border-gray-100 snap-start"
            >
              {/* Quote Icon */}
              <div className="size-12 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all">
                <Quote className="size-6 text-white" />
              </div>

              {/* Stars */}
              <div className="flex gap-1 mb-5">
                {[...Array(story.rating)].map((_, i) => (
                  <Star key={i} className="size-5 text-yellow-400 fill-yellow-400" />
                ))}
              </div>

              {/* Quote */}
              <p className="text-base text-[#475569] italic mb-8 leading-relaxed">
                "{story.quote}"
              </p>

              {/* Profile */}
              <div className="flex items-center gap-4 pt-6 border-t border-gray-200">
                <div className="size-16 rounded-full overflow-hidden border-3 border-[#0066FF]/20 shadow-md flex-shrink-0">
                  <ImageWithFallback
                    src={story.image}
                    alt={story.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="font-bold text-[#0A0A0A] text-lg">{story.name}</div>
                  <div className="text-sm text-[#64748B]">{story.role}</div>
                  <div className="text-sm text-[#0066FF] font-semibold">{story.company}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Navigation Hint */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-10"
        >
          <p className="text-sm text-[#64748B] mb-4">Scroll to see more success stories</p>
          <a
            href="#success-stories"
            className="inline-flex items-center gap-2 text-[#0066FF] font-semibold text-sm hover:gap-3 transition-all"
          >
            <span>View All Stories</span>
            <ArrowRight className="size-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 10. OUR PARTNERS - Enhanced Logo Grid
export function EnhancedPartners() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const partners = [
    "Hyundai", "Maruti Suzuki", "Tata Motors", "TVS Motors",
    "Ashok Leyland", "Royal Enfield", "Ather Energy", "Ola Electric"
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-b from-[#F8FAFB] to-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-gray-100 mb-5">
            <Building2 className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Partnerships</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] mb-4 leading-[1.1] tracking-tight">
            Our Partners
          </h2>

          <p className="text-lg text-[#64748B] max-w-2xl mx-auto leading-relaxed">
            Trusted by leading automotive companies across India
          </p>
        </motion.div>

        {/* Partners Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
          {partners.map((partner, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              whileHover={{ y: -6, scale: 1.05 }}
              className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all border border-gray-100 flex items-center justify-center relative overflow-hidden"
            >
              {/* Gradient Overlay on Hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#0066FF]/5 to-[#0090FF]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              
              <div className="text-center relative z-10">
                <div className="size-14 bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/10 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 group-hover:rotate-6 transition-all">
                  <Building2 className="size-7 text-[#0066FF]" />
                </div>
                <div className="font-bold text-[#0A0A0A] text-base">{partner}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// 11. EMPANELMENT - Enhanced Categories
export function EnhancedEmpanelment() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const categories = [
    {
      icon: Building2,
      title: "OEMs (Original Equipment Manufacturers)",
      points: [
        "Partner for workforce development programs",
        "Co-create specialized training modules",
        "Access to skilled talent pool",
        "Industry-aligned certification programs",
      ],
      gradient: "from-blue-500 to-indigo-600",
    },
    {
      icon: Cog,
      title: "Automotive Suppliers & Component Manufacturers",
      points: [
        "Collaborate on technical skill training",
        "Supplier-specific competency development",
        "Quality assurance and testing training",
        "Supply chain integration programs",
      ],
      gradient: "from-indigo-500 to-purple-600",
    },
    {
      icon: ShoppingCart,
      title: "Retail & Service Networks",
      points: [
        "Service technician training programs",
        "Customer service excellence modules",
        "After-sales support training",
        "Dealership management programs",
      ],
      gradient: "from-purple-500 to-pink-600",
    },
    {
      icon: Lightbulb,
      title: "Automotive Startups & Innovation Hubs",
      points: [
        "EV and new mobility solutions training",
        "Technology integration programs",
        "Innovation and R&D collaboration",
        "Emerging technology skill development",
      ],
      gradient: "from-pink-500 to-rose-600",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#0066FF]/5 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-[#0090FF]/5 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#0090FF]/10 rounded-full border border-[#0066FF]/20 mb-5">
            <Handshake className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Industry Partners</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] mb-5 leading-[1.1] tracking-tight">
            Empanelment Opportunities
          </h2>

          <p className="text-lg text-[#64748B] max-w-3xl mx-auto leading-relaxed">
            Join our network of industry partners to build a skilled automotive workforce
          </p>
        </motion.div>

        {/* Categories Grid */}
        <div className="grid md:grid-cols-2 gap-7 mb-12">
          {categories.map((category, idx) => {
            const Icon = category.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.15 }}
                whileHover={{ y: -6 }}
                className="group bg-gradient-to-br from-white to-gray-50 rounded-2xl p-8 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all relative overflow-hidden"
              >
                {/* Gradient Border on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${category.gradient} opacity-0 group-hover:opacity-100 transition-opacity`} style={{ padding: '2px', borderRadius: '16px' }}>
                  <div className="w-full h-full bg-white rounded-2xl" />
                </div>

                <div className="relative z-10">
                  {/* Icon & Title */}
                  <div className="flex items-start gap-5 mb-6">
                    <div className={`size-16 bg-gradient-to-br ${category.gradient} rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all`}>
                      <Icon className="size-8 text-white" strokeWidth={2.5} />
                    </div>
                    <h3 className="font-bold text-[#0A0A0A] text-xl leading-tight pt-2">
                      {category.title}
                    </h3>
                  </div>

                  {/* Points */}
                  <ul className="space-y-3">
                    {category.points.map((point, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle className="size-5 text-[#0066FF] flex-shrink-0 mt-0.5" />
                        <span className="text-[15px] text-[#64748B]">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center"
        >
          <a
            href="#empanelment"
            className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-[15px] shadow-lg hover:shadow-2xl hover:scale-105 transition-all"
          >
            <span>Apply for Empanelment</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}