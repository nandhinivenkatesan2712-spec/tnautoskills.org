import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Battery, Cpu, Leaf, Box } from "lucide-react";

const frameworks = [
  {
    icon: Battery,
    title: "EV Framework",
    description: "Comprehensive electric vehicle technology and battery management systems",
    gradient: "from-green-500 to-green-600",
    bgGradient: "from-green-50 to-green-100",
  },
  {
    icon: Cpu,
    title: "Software-Defined Vehicle Framework",
    description: "Next-gen automotive software architecture and autonomous systems",
    gradient: "from-blue-500 to-blue-600",
    bgGradient: "from-blue-50 to-blue-100",
  },
  {
    icon: Leaf,
    title: "Green & Flexi Fuel Framework",
    description: "Sustainable mobility solutions and alternative fuel technologies",
    gradient: "from-emerald-500 to-emerald-600",
    bgGradient: "from-emerald-50 to-emerald-100",
  },
  {
    icon: Box,
    title: "Vehicle Architecture Framework",
    description: "Modern vehicle platform design and modular architecture principles",
    gradient: "from-purple-500 to-purple-600",
    bgGradient: "from-purple-50 to-purple-100",
  },
];

const partners = [
  "HYUNDAI",
  "BOSCH",
  "NVIDIA",
  "TESLA",
  "BMW",
  "MERCEDES",
  "VOLKSWAGEN",
  "TOYOTA",
];

export function GlobalCurriculum() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="pt-20 pb-14 bg-[#0A0A0A] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M54.627 0l.83.828-1.415 1.415L51.8 0h2.827zM5.373 0l-.83.828L5.96 2.243 8.2 0H5.374zM48.97 0l3.657 3.657-1.414 1.414L46.143 0h2.828zM11.03 0L7.372 3.657 8.787 5.07 13.857 0H11.03zm32.284 0L49.8 6.485 48.384 7.9l-7.9-7.9h2.83zM16.686 0L10.2 6.485 11.616 7.9l7.9-7.9h-2.83zm20.97 0l9.315 9.314-1.414 1.414L34.828 0h2.83zM22.344 0L13.03 9.314l1.414 1.414L25.172 0h-2.83zM32 0l12.142 12.142-1.414 1.414L30 .828 17.272 13.556 15.858 12.14 28 0zm6.86 0l16.97 16.97-1.414 1.414L38.86 0h.002zM25.142 0l-22.627 22.627 1.414 1.414L26.556 1.414 25.142 0z' fill='%23ffffff' fill-opacity='1' fill-rule='evenodd'/%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative max-w-[1440px] mx-auto px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-8" />
          <h2 className="text-5xl lg:text-6xl font-extrabold text-white mb-4">
            Global Automotive Curriculum Framework
          </h2>
          <p className="text-lg xl:text-xl text-gray-400 max-w-3xl mx-auto">
            Industry-aligned training frameworks recognized worldwide
          </p>
        </motion.div>

        {/* Framework Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 mb-10">
          {frameworks.map((framework, index) => {
            const Icon = framework.icon;
            
            return (
              <motion.div
                key={framework.title}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group relative bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100 overflow-hidden"
              >
                {/* Background Gradient */}
                <div className={`absolute inset-0 bg-gradient-to-br ${framework.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                
                {/* Content */}
                <div className="relative z-10 space-y-6">
                  {/* Icon */}
                  <div className={`size-16 bg-gradient-to-br ${framework.gradient} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-500 shadow-lg`}>
                    <Icon className="size-8 text-white" strokeWidth={2} />
                  </div>

                  {/* Title */}
                  <h3 className="text-[#0b1220] text-2xl font-bold leading-tight group-hover:text-[#0066FF] transition-colors">
                    {framework.title}
                  </h3>

                  {/* Description */}
                  <p className="text-[#64748b] text-base leading-relaxed">
                    {framework.description}
                  </p>
                </div>

                {/* Bottom Accent */}
                <div className={`absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r ${framework.gradient} scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left rounded-b-3xl`} />
              </motion.div>
            );
          })}
        </div>

        {/* Partner Logos Slider */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-16"
        >
          <p className="text-center text-[#64748b] text-sm uppercase tracking-wider mb-8">
            Trusted by Industry Leaders
          </p>
          
          <div className="relative overflow-hidden">
            {/* Gradient Fade Edges */}
            <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-white to-transparent z-10" />
            <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-white to-transparent z-10" />
            
            {/* Scrolling Container */}
            <motion.div
              animate={{
                x: [0, -1000],
              }}
              transition={{
                x: {
                  repeat: Infinity,
                  repeatType: "loop",
                  duration: 20,
                  ease: "linear",
                },
              }}
              className="flex gap-12 items-center whitespace-nowrap py-4"
            >
              {[...partners, ...partners, ...partners].map((partner, i) => (
                <div
                  key={i}
                  className="flex-shrink-0 px-8 py-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-[#0066FF]/50 hover:bg-white transition-all"
                >
                  <span className="text-[#0b1220] text-lg font-bold tracking-wider">
                    {partner}
                  </span>
                </div>
              ))}
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}