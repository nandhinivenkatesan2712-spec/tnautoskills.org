import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  GraduationCap,
  Wrench,
  Briefcase,
  Users,
  TrendingUp,
  Handshake,
} from "lucide-react";

const services = [
  {
    icon: GraduationCap,
    title: "Industry-Aligned Skill Training",
    description:
      "Structured, government-certified automotive training programs based on evolving industry standards.",
  },
  {
    icon: Wrench,
    title: "Hands-On Technical Workshops",
    description:
      "Practical sessions, advanced labs, and real-world automotive tools.",
  },
  {
    icon: Briefcase,
    title: "Career Guidance & Placement",
    description:
      "Placement support with leading automotive companies, counseling, interview prep.",
  },
  {
    icon: Users,
    title: "Internship & On-the-Job Training",
    description:
      "Internships and OJT opportunities to understand real workflows.",
  },
  {
    icon: TrendingUp,
    title: "Upskilling for Working Professionals",
    description:
      "Short-term enhancement courses to grow in the workplace.",
  },
  {
    icon: Handshake,
    title: "Industry Partnership & Collaboration",
    description:
      "Work with OEMs, suppliers, and institutions to build the future workforce.",
  },
];

export function ExploreWhatWeDo() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 rounded-full mb-6">
            <div className="size-2 bg-[#0066FF] rounded-full animate-pulse" />
            <span className="text-sm font-semibold text-[#0066FF]">Our Services</span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
            Explore What We Are Doing
          </h2>

          <p className="text-lg lg:text-xl text-[#64748b] max-w-3xl mx-auto">
            Comprehensive programs designed to develop automotive talent and bridge the industry skill gap
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group bg-white rounded-2xl p-8 border-2 border-gray-100 hover:border-[#0066FF]/30 shadow-sm hover:shadow-2xl transition-all"
              >
                {/* Icon */}
                <div className="relative mb-6">
                  <div className="size-16 bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <IconComponent className="size-8 text-[#0066FF]" strokeWidth={2} />
                  </div>
                  {/* Decorative Element */}
                  <div className="absolute -top-2 -right-2 size-6 bg-[#0066FF] rounded-lg opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-[#0A0A0A] mb-3 group-hover:text-[#0066FF] transition-colors">
                  {service.title}
                </h3>
                <p className="text-base text-[#64748b] leading-relaxed">
                  {service.description}
                </p>

                {/* Hover Effect Arrow */}
                <motion.div
                  initial={{ x: -10, opacity: 0 }}
                  whileHover={{ x: 0, opacity: 1 }}
                  className="mt-4 flex items-center gap-2 text-sm font-semibold text-[#0066FF]"
                >
                  <span>Learn more</span>
                  <motion.svg
                    className="size-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5l7 7-7 7"
                    />
                  </motion.svg>
                </motion.div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
