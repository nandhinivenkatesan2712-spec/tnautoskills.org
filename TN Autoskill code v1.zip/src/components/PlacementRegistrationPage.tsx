import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import { Send, CheckCircle2, AlertCircle, ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Checkbox } from "./ui/checkbox";

interface FormErrors {
  [key: string]: string;
}

export function PlacementRegistrationPage() {
  const formRef = useRef(null);
  const formInView = useInView(formRef, { once: true, margin: "-50px" });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    collegeName: "",
    collegeAddress: "",
    affiliation: "",
    contactPersonName: "",
    designation: "",
    email: "",
    phoneNumber: "",
    coursesOffered: "",
    numberOfStudents: "",
    placementSupport: [] as string[],
    otherSupport: "",
    placementStats: "",
    specialRequests: "",
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<{ [key: string]: boolean }>({});

  const placementSupportOptions = [
    { id: "campusDrives", label: "Campus Drives" },
    { id: "internships", label: "Internship Opportunities" },
    { id: "expertSessions", label: "Industry Expert Sessions" },
    { id: "softSkills", label: "Soft Skills Training" },
    { id: "technicalTraining", label: "Technical Training" },
    { id: "other", label: "Other" },
  ];

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePhoneNumber = (phone: string): boolean => {
    const phoneRegex = /^[0-9]{10}$/;
    return phoneRegex.test(phone.replace(/\s/g, ""));
  };

  const validateField = (field: string, value: string | string[]): string => {
    if (field === "email" && value) {
      return validateEmail(value as string) ? "" : "Please enter a valid email address";
    }
    if (field === "phoneNumber" && value) {
      return validatePhoneNumber(value as string) ? "" : "Please enter a valid 10-digit phone number";
    }
    if (field === "placementSupport") {
      return (value as string[]).length === 0 ? "Please select at least one option" : "";
    }
    if (["collegeName", "collegeAddress", "affiliation", "contactPersonName", "designation", "email", "phoneNumber", "coursesOffered", "numberOfStudents"].includes(field)) {
      return (value as string).trim() === "" ? "This field is required" : "";
    }
    return "";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate all fields
    const newErrors: FormErrors = {};
    Object.keys(formData).forEach((field) => {
      if (field !== "otherSupport" && field !== "placementStats" && field !== "specialRequests") {
        const error = validateField(field, formData[field as keyof typeof formData]);
        if (error) newErrors[field] = error;
      }
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      const allTouched: { [key: string]: boolean } = {};
      Object.keys(formData).forEach((field) => {
        allTouched[field] = true;
      });
      setTouched(allTouched);
      return;
    }

    console.log("Form submitted:", formData);
    setIsSubmitted(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleChange = (field: string, value: string | string[]) => {
    setFormData((prev) => ({ ...prev, [field]: value }));

    if (touched[field]) {
      const error = validateField(field, value);
      setErrors((prev) => ({
        ...prev,
        [field]: error,
      }));
    }
  };

  const handleBlur = (field: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
    const error = validateField(field, formData[field as keyof typeof formData]);
    setErrors((prev) => ({
      ...prev,
      [field]: error,
    }));
  };

  const handleCheckboxChange = (optionId: string) => {
    const currentSupport = formData.placementSupport;
    const newSupport = currentSupport.includes(optionId)
      ? currentSupport.filter((id) => id !== optionId)
      : [...currentSupport, optionId];

    handleChange("placementSupport", newSupport);
  };

  const isFieldValid = (field: string): boolean => {
    return touched[field] && !errors[field] && formData[field as keyof typeof formData] !== "";
  };

  const isFieldInvalid = (field: string): boolean => {
    return touched[field] && !!errors[field];
  };

  const handleBackToHome = () => {
    window.location.hash = "";
  };

  const handleSubmitAnother = () => {
    setIsSubmitted(false);
    setFormData({
      collegeName: "",
      collegeAddress: "",
      affiliation: "",
      contactPersonName: "",
      designation: "",
      email: "",
      phoneNumber: "",
      coursesOffered: "",
      numberOfStudents: "",
      placementSupport: [],
      otherSupport: "",
      placementStats: "",
      specialRequests: "",
    });
    setErrors({});
    setTouched({});
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F8FAFB] via-white to-[#F8FAFB]">
      {/* Compact Header Section */}
      <section className="py-12 bg-white border-b border-gray-100">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-3xl lg:text-[42px] font-extrabold text-[#0A1628] leading-tight mb-3">
              Placement Registration for Colleges
            </h1>
            <p className="text-base lg:text-[18px] text-[#64748B] font-medium leading-relaxed max-w-3xl mx-auto">
              Register your institution and collaborate with TN AutoSkills for placement support and training opportunities.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Form Section */}
      <section ref={formRef} className="py-12 relative overflow-hidden">
        <div className="max-w-[900px] mx-auto px-6 lg:px-8 relative z-10">
          {/* Success Message - Inline */}
          {isSubmitted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-2xl shadow-xl border border-green-100 p-8 mb-8"
            >
              {/* Animated Checkmark */}
              <div className="flex justify-center mb-4">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{
                    type: "spring",
                    stiffness: 200,
                    damping: 15,
                    delay: 0.1,
                  }}
                  className="relative"
                >
                  <div className="size-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                    <CheckCircle2 className="size-10 text-white" strokeWidth={2.5} />
                  </div>
                </motion.div>
              </div>

              {/* Success Message */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="text-center space-y-3"
              >
                <h2 className="text-2xl lg:text-[28px] font-extrabold text-[#0A1628] leading-tight">
                  Registration Submitted Successfully
                </h2>
                <p className="text-base text-[#64748B] leading-relaxed max-w-lg mx-auto">
                  Thanks! Our placement team will get in touch with your institution soon.
                </p>
              </motion.div>

              {/* Action Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
                className="mt-6 flex flex-col sm:flex-row gap-3 items-center justify-center"
              >
                <Button
                  onClick={handleBackToHome}
                  className="w-full sm:w-auto px-8 h-11 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] hover:from-[#0055DD] hover:to-[#00ACC4] text-white font-semibold shadow-md hover:shadow-lg transition-all"
                >
                  Back to Home
                </Button>

                <button
                  onClick={handleSubmitAnother}
                  className="text-[#0066FF] font-semibold hover:underline transition-all"
                >
                  Submit Another Request
                </button>
              </motion.div>
            </motion.div>
          )}

          {/* Form Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={formInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 lg:p-10"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Badge */}
              <div className="pb-4 border-b border-gray-100">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#00BCD4]/10 rounded-lg border border-[#0066FF]/20">
                  <div className="size-2 bg-[#0066FF] rounded-full" />
                  <span className="text-sm font-semibold text-[#0066FF]">
                    College/Institution Placement Registration
                  </span>
                </div>
              </div>

              {/* Institution Information */}
              <div className="space-y-5">
                <h3 className="text-lg font-bold text-[#0A1628] flex items-center gap-2">
                  <div className="size-1.5 bg-[#0066FF] rounded-full" />
                  Institution Information
                </h3>

                {/* College Name */}
                <div className="space-y-2">
                  <Label htmlFor="collegeName" className="text-sm font-semibold text-[#0A1628]">
                    College Name <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <Input
                      id="collegeName"
                      placeholder="Enter college/institution name"
                      value={formData.collegeName}
                      onChange={(e) => handleChange("collegeName", e.target.value)}
                      onBlur={() => handleBlur("collegeName")}
                      className={`h-11 text-sm transition-all ${
                        isFieldInvalid("collegeName")
                          ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                          : isFieldValid("collegeName")
                          ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                          : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                      }`}
                    />
                    {isFieldValid("collegeName") && (
                      <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                    )}
                    {isFieldInvalid("collegeName") && (
                      <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                    )}
                  </div>
                  {isFieldInvalid("collegeName") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.collegeName}
                    </p>
                  )}
                </div>

                {/* College Address */}
                <div className="space-y-2">
                  <Label htmlFor="collegeAddress" className="text-sm font-semibold text-[#0A1628]">
                    College Address <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="collegeAddress"
                    placeholder="Enter complete college address"
                    value={formData.collegeAddress}
                    onChange={(e) => handleChange("collegeAddress", e.target.value)}
                    onBlur={() => handleBlur("collegeAddress")}
                    rows={2}
                    className={`text-sm resize-none transition-all ${
                      isFieldInvalid("collegeAddress")
                        ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                        : isFieldValid("collegeAddress")
                        ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                        : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                    }`}
                  />
                  {isFieldInvalid("collegeAddress") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.collegeAddress}
                    </p>
                  )}
                </div>

                {/* College Affiliation */}
                <div className="space-y-2">
                  <Label htmlFor="affiliation" className="text-sm font-semibold text-[#0A1628]">
                    College Affiliation / University <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <Input
                      id="affiliation"
                      placeholder="E.g., Anna University, AICTE, UGC"
                      value={formData.affiliation}
                      onChange={(e) => handleChange("affiliation", e.target.value)}
                      onBlur={() => handleBlur("affiliation")}
                      className={`h-11 text-sm transition-all ${
                        isFieldInvalid("affiliation")
                          ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                          : isFieldValid("affiliation")
                          ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                          : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                      }`}
                    />
                    {isFieldValid("affiliation") && (
                      <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                    )}
                    {isFieldInvalid("affiliation") && (
                      <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                    )}
                  </div>
                  {isFieldInvalid("affiliation") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.affiliation}
                    </p>
                  )}
                </div>
              </div>

              {/* Contact Person Details */}
              <div className="space-y-5 pt-4 border-t border-gray-100">
                <h3 className="text-lg font-bold text-[#0A1628] flex items-center gap-2">
                  <div className="size-1.5 bg-[#0066FF] rounded-full" />
                  Contact Person Details
                </h3>

                <div className="grid lg:grid-cols-2 gap-5">
                  {/* Contact Person Name */}
                  <div className="space-y-2">
                    <Label htmlFor="contactPersonName" className="text-sm font-semibold text-[#0A1628]">
                      Contact Person Name <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="contactPersonName"
                        placeholder="Enter full name"
                        value={formData.contactPersonName}
                        onChange={(e) => handleChange("contactPersonName", e.target.value)}
                        onBlur={() => handleBlur("contactPersonName")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("contactPersonName")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("contactPersonName")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("contactPersonName") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("contactPersonName") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("contactPersonName") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.contactPersonName}
                      </p>
                    )}
                  </div>

                  {/* Designation */}
                  <div className="space-y-2">
                    <Label htmlFor="designation" className="text-sm font-semibold text-[#0A1628]">
                      Contact Person Designation <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="designation"
                        placeholder="E.g., Placement Officer, Head - T&P"
                        value={formData.designation}
                        onChange={(e) => handleChange("designation", e.target.value)}
                        onBlur={() => handleBlur("designation")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("designation")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("designation")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("designation") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("designation") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("designation") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.designation}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid lg:grid-cols-2 gap-5">
                  {/* Email */}
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm font-semibold text-[#0A1628]">
                      Contact Person Email Address <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="email"
                        type="email"
                        placeholder="email@college.edu"
                        value={formData.email}
                        onChange={(e) => handleChange("email", e.target.value)}
                        onBlur={() => handleBlur("email")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("email")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("email")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("email") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("email") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("email") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.email}
                      </p>
                    )}
                  </div>

                  {/* Phone Number */}
                  <div className="space-y-2">
                    <Label htmlFor="phoneNumber" className="text-sm font-semibold text-[#0A1628]">
                      Contact Person Phone Number <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="phoneNumber"
                        type="tel"
                        placeholder="+91 XXXXX XXXXX"
                        value={formData.phoneNumber}
                        onChange={(e) => handleChange("phoneNumber", e.target.value)}
                        onBlur={() => handleBlur("phoneNumber")}
                        className={`h-11 text-sm transition-all ${
                          isFieldInvalid("phoneNumber")
                            ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                            : isFieldValid("phoneNumber")
                            ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                            : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                        }`}
                      />
                      {isFieldValid("phoneNumber") && (
                        <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                      )}
                      {isFieldInvalid("phoneNumber") && (
                        <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                      )}
                    </div>
                    {isFieldInvalid("phoneNumber") && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="size-3" />
                        {errors.phoneNumber}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Placement Requirements */}
              <div className="space-y-5 pt-4 border-t border-gray-100">
                <h3 className="text-lg font-bold text-[#0A1628] flex items-center gap-2">
                  <div className="size-1.5 bg-[#0066FF] rounded-full" />
                  Placement Requirements
                </h3>

                {/* Courses Offered */}
                <div className="space-y-2">
                  <Label htmlFor="coursesOffered" className="text-sm font-semibold text-[#0A1628]">
                    Courses Offered / Departments Seeking Placement Support <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="coursesOffered"
                    placeholder="E.g., B.E Mechanical, B.Tech Automobile, Diploma in Manufacturing"
                    value={formData.coursesOffered}
                    onChange={(e) => handleChange("coursesOffered", e.target.value)}
                    onBlur={() => handleBlur("coursesOffered")}
                    rows={2}
                    className={`text-sm resize-none transition-all ${
                      isFieldInvalid("coursesOffered")
                        ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                        : isFieldValid("coursesOffered")
                        ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                        : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                    }`}
                  />
                  {isFieldInvalid("coursesOffered") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.coursesOffered}
                    </p>
                  )}
                </div>

                {/* Number of Students */}
                <div className="space-y-2">
                  <Label htmlFor="numberOfStudents" className="text-sm font-semibold text-[#0A1628]">
                    Number of Final Year Students (Eligible for Placement) <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <Input
                      id="numberOfStudents"
                      type="number"
                      placeholder="E.g., 150"
                      value={formData.numberOfStudents}
                      onChange={(e) => handleChange("numberOfStudents", e.target.value)}
                      onBlur={() => handleBlur("numberOfStudents")}
                      min="1"
                      className={`h-11 text-sm transition-all ${
                        isFieldInvalid("numberOfStudents")
                          ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                          : isFieldValid("numberOfStudents")
                          ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                          : "border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                      }`}
                    />
                    {isFieldValid("numberOfStudents") && (
                      <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-green-500" />
                    )}
                    {isFieldInvalid("numberOfStudents") && (
                      <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-red-500" />
                    )}
                  </div>
                  {isFieldInvalid("numberOfStudents") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.numberOfStudents}
                    </p>
                  )}
                </div>

                {/* Placement Support Required */}
                <div className="space-y-3">
                  <Label className="text-sm font-semibold text-[#0A1628]">
                    Placement Support Required <span className="text-red-500">*</span>
                  </Label>
                  <div className="space-y-3">
                    {placementSupportOptions.map((option) => (
                      <div key={option.id} className="flex items-start gap-3">
                        <Checkbox
                          id={option.id}
                          checked={formData.placementSupport.includes(option.id)}
                          onCheckedChange={() => handleCheckboxChange(option.id)}
                          className="mt-0.5"
                        />
                        <Label
                          htmlFor={option.id}
                          className="text-sm text-[#475569] cursor-pointer leading-relaxed"
                        >
                          {option.label}
                        </Label>
                      </div>
                    ))}
                  </div>
                  {isFieldInvalid("placementSupport") && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="size-3" />
                      {errors.placementSupport}
                    </p>
                  )}

                  {/* Other Support Text Field */}
                  {formData.placementSupport.includes("other") && (
                    <div className="ml-7 space-y-2">
                      <Input
                        placeholder="Please specify other support needed"
                        value={formData.otherSupport}
                        onChange={(e) => handleChange("otherSupport", e.target.value)}
                        className="h-10 text-sm border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                      />
                    </div>
                  )}
                </div>

                {/* Past Placement Statistics */}
                <div className="space-y-2">
                  <Label htmlFor="placementStats" className="text-sm font-semibold text-[#0A1628]">
                    Past Placement Statistics <span className="text-gray-400 text-xs">(Optional)</span>
                  </Label>
                  <Textarea
                    id="placementStats"
                    placeholder="E.g., 2023-24: 85% placement rate, Average package: ₹3.5 LPA"
                    value={formData.placementStats}
                    onChange={(e) => handleChange("placementStats", e.target.value)}
                    rows={2}
                    className="text-sm resize-none border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                  />
                </div>

                {/* Special Requests */}
                <div className="space-y-2">
                  <Label htmlFor="specialRequests" className="text-sm font-semibold text-[#0A1628]">
                    Special Requests or Comments <span className="text-gray-400 text-xs">(Optional)</span>
                  </Label>
                  <Textarea
                    id="specialRequests"
                    placeholder="Any additional information or specific requirements"
                    value={formData.specialRequests}
                    onChange={(e) => handleChange("specialRequests", e.target.value)}
                    rows={2}
                    className="text-sm resize-none border-gray-200 focus:border-[#0066FF] focus:ring-[#0066FF]/20"
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="pt-6 border-t border-gray-100">
                <div className="flex flex-col items-center gap-4">
                  <Button
                    type="submit"
                    className="w-full lg:w-auto px-12 h-12 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] hover:from-[#0055DD] hover:to-[#00ACC4] text-white font-semibold shadow-lg hover:shadow-xl transition-all text-base"
                  >
                    <Send className="size-5 mr-2" />
                    Submit Registration
                  </Button>

                  <p className="text-sm text-[#64748B] text-center">
                    Our team will contact you within <span className="font-semibold text-[#0066FF]">48 hours</span>
                  </p>

                  <Button
                    type="button"
                    variant="ghost"
                    onClick={handleBackToHome}
                    className="text-[#64748B] hover:text-[#0066FF] hover:bg-[#0066FF]/5 text-sm"
                  >
                    <ArrowLeft className="size-4 mr-1.5" />
                    Back to Home
                  </Button>
                </div>
              </div>
            </form>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={formInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-8 text-center"
          >
            <p className="text-sm text-[#64748B]">
              Need assistance? Contact us at{" "}
              <a
                href="mailto:placements@tnautoskills.in"
                className="text-[#0066FF] font-semibold hover:underline"
              >
                placements@tnautoskills.in
              </a>{" "}
              or call{" "}
              <a
                href="tel:+911234567890"
                className="text-[#0066FF] font-semibold hover:underline"
              >
                +91 123 456 7890
              </a>
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
