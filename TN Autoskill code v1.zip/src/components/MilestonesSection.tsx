import { motion, useInView, useMotionValue, useTransform, animate } from "motion/react";
import { useRef, useEffect } from "react";
import { Users, CheckCircle2, Briefcase, FileCheck, Handshake, Heart } from "lucide-react";

const milestones = [
  { icon: Users, value: 2500, label: "Candidates Trained", suffix: "+" },
  { icon: CheckCircle2, value: 500, label: "Candidates Assessed", suffix: "+" },
  { icon: Briefcase, value: 200, label: "Candidates Placed", suffix: "+" },
  { icon: FileCheck, value: 35, label: "MoUs Signed", suffix: "+" },
  { icon: Handshake, value: 40, label: "Industry Partnerships", suffix: "+" },
  { icon: Heart, value: 10, label: "CSR Projects", suffix: "+" },
];

function Counter({ value, suffix = "" }: { value: number; suffix?: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const count = useMotionValue(0);
  const rounded = useTransform(count, (latest) => Math.round(latest));

  useEffect(() => {
    if (isInView) {
      const controls = animate(count, value, {
        duration: 2,
        ease: "easeOut",
      });
      return controls.stop;
    }
  }, [isInView, count, value]);

  return (
    <span ref={ref}>
      <motion.span>{rounded}</motion.span>
      {suffix}
    </span>
  );
}

export function MilestonesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-gradient-to-br from-[#0066FF] to-[#0090FF] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:4rem_4rem]" />
      
      {/* Floating Shapes */}
      <motion.div
        animate={{
          rotate: [0, 360],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "linear",
        }}
        className="absolute top-20 right-20 size-96 bg-white/5 rounded-full blur-3xl"
      />
      <motion.div
        animate={{
          rotate: [360, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 30,
          repeat: Infinity,
          ease: "linear",
        }}
        className="absolute bottom-20 left-20 size-[500px] bg-white/5 rounded-full blur-3xl"
      />

      <div className="relative max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/20 backdrop-blur-md rounded-full border border-white/30 mb-6">
            <div className="size-2 bg-white rounded-full animate-pulse" />
            <span className="text-sm font-semibold text-white">
              Impact & Achievements
            </span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-extrabold text-white mb-6 leading-tight">
            Our Milestones
          </h2>

          <p className="text-lg lg:text-xl text-white/90 max-w-3xl mx-auto">
            Driving automotive skill development across Tamil Nadu with measurable impact
          </p>
        </motion.div>

        {/* Milestones Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 lg:gap-8">
          {milestones.map((milestone, index) => {
            const IconComponent = milestone.icon;
            return (
              <motion.div
                key={milestone.label}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8, scale: 1.05 }}
                className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all text-center"
              >
                {/* Icon */}
                <div className="size-14 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <IconComponent className="size-7 text-white" strokeWidth={2} />
                </div>

                {/* Value */}
                <div className="text-4xl lg:text-5xl font-extrabold text-white mb-3">
                  <Counter value={milestone.value} suffix={milestone.suffix} />
                </div>

                {/* Label */}
                <div className="text-xs lg:text-sm text-white/90 font-medium leading-tight">
                  {milestone.label}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Additional Highlight */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-12 bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20 text-center"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Heart className="size-8 text-white" />
            <h3 className="text-2xl lg:text-3xl font-extrabold text-white">
              25+ CSR-Funded Initiatives
            </h3>
          </div>
          <p className="text-white/90 text-lg">
            Corporate partnerships driving social impact and skill development across communities
          </p>
        </motion.div>
      </div>
    </section>
  );
}
