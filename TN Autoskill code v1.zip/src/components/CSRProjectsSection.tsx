import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight, Heart, Target, Users, TrendingUp } from "lucide-react";

export function CSRProjectsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-28 bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-purple-100 rounded-full mb-6">
              <Heart className="size-4 text-purple-600 fill-purple-600" />
              <span className="text-sm font-semibold text-purple-600">
                Social Impact
              </span>
            </div>

            <h2 className="text-4xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-6 leading-tight">
              CSR Projects
            </h2>

            <p className="text-lg lg:text-xl text-[#64748b] mb-8 leading-relaxed">
              Driving social impact through corporate partnerships and skill development initiatives across communities.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-purple-100">
                <div className="text-4xl font-extrabold text-purple-600 mb-2">10+</div>
                <div className="text-sm text-[#64748b] font-semibold">CSR Projects Completed</div>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-purple-100">
                <div className="text-4xl font-extrabold text-purple-600 mb-2">25+</div>
                <div className="text-sm text-[#64748b] font-semibold">CSR-Funded Initiatives</div>
              </div>
            </div>

            {/* Impact Areas */}
            <div className="space-y-3 mb-8">
              {[
                { icon: Target, text: "Skill development for underprivileged youth" },
                { icon: Users, text: "Community empowerment programs" },
                { icon: TrendingUp, text: "Livelihood generation initiatives" },
              ].map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <motion.div
                    key={item.text}
                    initial={{ opacity: 0, x: -20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className="size-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <IconComponent className="size-5 text-purple-600" />
                    </div>
                    <span className="text-sm font-medium text-[#475569]">{item.text}</span>
                  </motion.div>
                );
              })}
            </div>

            {/* CTA */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl font-bold text-base shadow-xl hover:shadow-2xl transition-all"
            >
              <Heart className="size-5" />
              <span>Register New CSR Partnership</span>
              <ArrowRight className="size-5" />
            </motion.button>
          </motion.div>

          {/* Right: Visual */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="bg-gradient-to-br from-purple-100 to-pink-100 rounded-3xl p-8 lg:p-12">
              <h3 className="text-2xl font-extrabold text-[#0A0A0A] mb-6">
                Partner with Us for Social Impact
              </h3>
              
              <div className="space-y-4">
                <div className="bg-white rounded-xl p-5">
                  <h4 className="font-bold text-[#0A0A0A] mb-2">For Corporates</h4>
                  <p className="text-sm text-[#64748b]">
                    Fulfill your CSR objectives through impactful skill development programs
                  </p>
                </div>

                <div className="bg-white rounded-xl p-5">
                  <h4 className="font-bold text-[#0A0A0A] mb-2">For Communities</h4>
                  <p className="text-sm text-[#64748b]">
                    Access free or subsidized training to build automotive careers
                  </p>
                </div>

                <div className="bg-white rounded-xl p-5">
                  <h4 className="font-bold text-[#0A0A0A] mb-2">For Society</h4>
                  <p className="text-sm text-[#64748b]">
                    Creating sustainable livelihoods and empowering youth across Tamil Nadu
                  </p>
                </div>
              </div>
            </div>

            {/* Floating Element */}
            <motion.div
              animate={{
                y: [0, -20, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute -bottom-6 -right-6 size-32 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full blur-2xl opacity-40"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
