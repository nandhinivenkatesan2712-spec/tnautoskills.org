import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Zap,
  Wind,
  Cpu,
  Monitor,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function MinimalCentreOfExcellence() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    {
      icon: Zap,
      title: "EV & Hybrid Training Lab",
    },
    {
      icon: Wind,
      title: "BS6 Engine Diagnostic Lab",
    },
    {
      icon: Cpu,
      title: "Robotics & Automation Lab",
    },
    {
      icon: Monitor,
      title: "Simulation & Virtual Training",
    },
    {
      icon: ShieldCheck,
      title: "High-Voltage Safety & Testing Modules",
    },
  ];

  return (
    <section ref={ref} className="py-12 lg:py-16 bg-gradient-to-br from-[#F7F9FC] to-[#FFFFFF]">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-[30%_70%] gap-8 lg:gap-12 items-center">
          
          {/* LEFT — Small Modern Image */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-md">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1581092918484-8313e1f7e8d6?w=500&h=500&fit=crop"
                alt="Advanced automotive training lab"
                className="w-full aspect-square object-cover"
              />
              {/* Subtle Overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#0066FF]/10 to-transparent" />
            </div>
          </motion.div>

          {/* RIGHT — Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="space-y-5"
          >
            {/* Title */}
            <h2 className="text-3xl lg:text-4xl font-bold text-[#0A0A0A] leading-tight">
              Centre of Excellence
            </h2>

            {/* Short Description */}
            <p className="text-base lg:text-lg text-[#475569] leading-relaxed max-w-2xl">
              State-of-the-art training facilities equipped with advanced automotive technologies, 
              industry-grade equipment, and hands-on learning environments.
            </p>

            {/* Bullet List */}
            <ul className="space-y-3 pt-2">
              {features.map((feature, idx) => {
                const Icon = feature.icon;
                return (
                  <motion.li
                    key={idx}
                    initial={{ opacity: 0, x: -10 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.2 + idx * 0.08 }}
                    className="flex items-center gap-3 group cursor-default"
                  >
                    {/* Minimal Line Icon */}
                    <div className="flex-shrink-0 size-9 bg-[#0066FF]/10 rounded-lg flex items-center justify-center group-hover:bg-[#0066FF]/20 transition-colors">
                      <Icon className="size-4 text-[#0066FF]" strokeWidth={2} />
                    </div>

                    {/* Text */}
                    <span className="text-base text-[#0A0A0A] font-medium group-hover:text-[#0066FF] transition-colors">
                      {feature.title}
                    </span>
                  </motion.li>
                );
              })}
            </ul>

            {/* CTA Button */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ duration: 0.4, delay: 0.6 }}
              className="pt-3"
            >
              <a
                href="#facilities"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-lg font-semibold text-sm shadow-sm hover:shadow-md hover:scale-[1.02] transition-all"
              >
                <span>Explore Facilities</span>
                <ArrowRight className="size-4" strokeWidth={2} />
              </a>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
