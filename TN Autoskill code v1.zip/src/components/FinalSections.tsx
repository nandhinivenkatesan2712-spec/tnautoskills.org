import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import {
  ArrowRight,
  GraduationCap,
  Wrench,
  Briefcase,
  Users,
  TrendingUp,
  Handshake,
  CheckCircle,
  Play,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// SECTION 1 — Who We Are
export function FinalWhoWeAre() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-15 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left — Image with Parallax */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden">
              <motion.div
                initial={{ scale: 1.1 }}
                animate={isInView ? { scale: 1 } : {}}
                transition={{ duration: 1.2 }}
              >
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1581092918484-8313e1f7e8d6?w=700&h=600&fit=crop"
                  alt="Automotive training facility"
                  className="w-full h-[500px] object-cover"
                />
              </motion.div>
              {/* 20% Dark Overlay */}
              <div className="absolute inset-0 bg-black/20" />
            </div>
          </motion.div>

          {/* Right — Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative pl-8"
          >
            {/* Thin Vertical Accent Line */}
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-[#0066FF] to-[#00BCD4]" />

            {/* Heading */}
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
              Who We Are
            </h2>

            {/* Tamil Subtitle */}
            <p className="text-xl text-[#475569] mb-6" style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}>
              நாங்கள் யார்
            </p>

            {/* Content - Exact as provided */}
            <div className="space-y-4 mb-8">
              <p className="text-base text-[#475569] leading-relaxed">
                <strong className="text-[#0A0A0A]">TN Auto Skills</strong> is a government initiative focused on developing industry-ready automotive talent across Tamil Nadu.
              </p>
              <p className="text-base text-[#475569] leading-relaxed">
                Advanced, job-oriented training programs aligned with modern automobile technologies.
              </p>
              <p className="text-base text-[#475569] leading-relaxed">
                Bridge the skill gap and empower youth with hands-on learning.
              </p>
              <p className="text-base text-[#475569] leading-relaxed">
                Strong industry partnerships for career opportunities.
              </p>
            </div>

            {/* Two CTAs */}
            <div className="flex flex-wrap gap-4">
              <a
                href="#about"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#00BCD4] text-white rounded-xl font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all"
              >
                <span>Read More</span>
                <ArrowRight className="size-4" />
              </a>
              <a
                href="#programs"
                className="inline-flex items-center gap-2 px-6 py-3 bg-white border-2 border-[#0066FF] text-[#0066FF] rounded-xl font-semibold hover:bg-[#0066FF]/5 transition-all"
              >
                <span>Explore Programs</span>
                <ArrowRight className="size-4" />
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// SECTION 2 — Explore What We Are Doing
export function FinalExploreServices() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const services = [
    {
      icon: GraduationCap,
      title: "Industry-Aligned Skill Training",
      description: "Structured, government-certified automotive training programs based on evolving industry standards.",
    },
    {
      icon: Wrench,
      title: "Hands-On Technical Workshops",
      description: "Practical sessions, advanced labs, and real-world automotive tools.",
    },
    {
      icon: Briefcase,
      title: "Career Guidance & Placement",
      description: "Placement support with leading automotive companies, counseling, interview prep.",
    },
    {
      icon: Users,
      title: "Internship & On-the-Job Training",
      description: "Internships and OJT opportunities to understand real workflows.",
    },
    {
      icon: TrendingUp,
      title: "Upskilling for Working Professionals",
      description: "Short-term enhancement courses to grow in the workplace.",
    },
    {
      icon: Handshake,
      title: "Industry Partnership & Collaboration",
      description: "Work with OEMs, suppliers, and institutions to build the future workforce.",
    },
  ];

  return (
    <section ref={ref} className="py-15 bg-gradient-to-b from-[#F8FAFB] to-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Explore What We Are Doing
          </h2>
          <p className="text-lg text-[#64748B] max-w-3xl mx-auto">
            Comprehensive programs designed to develop automotive talent and bridge the industry skill gap
          </p>
        </motion.div>

        {/* 3-Column Card Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, idx) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="group bg-white/80 backdrop-blur-sm rounded-[20px] p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-xl transition-all"
              >
                {/* Icon */}
                <div className="size-14 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Icon className="size-7 text-[#0066FF]" strokeWidth={2} />
                </div>

                {/* Title */}
                <h3 className="font-bold text-lg text-[#0A0A0A] mb-2">
                  {service.title}
                </h3>

                {/* Description (2 lines) */}
                <p className="text-sm text-[#64748B] leading-relaxed line-clamp-2">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// SECTION 3 — Empowering Every Stakeholder
export function FinalStakeholders() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stakeholders = [
    {
      image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=400&fit=crop",
      title: "Candidates",
      description: "Access government-certified training, hands-on skills, and direct placement opportunities.",
    },
    {
      image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop",
      title: "Industry",
      description: "Partner with us to build a skilled workforce aligned with your technology needs.",
    },
    {
      image: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600&h=400&fit=crop",
      title: "Academia",
      description: "Collaborate on curriculum development and provide students with industry exposure.",
    },
    {
      image: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=600&h=400&fit=crop",
      title: "Trainers & Assessors",
      description: "Join our network of certified professionals delivering world-class training.",
    },
  ];

  return (
    <section ref={ref} className="py-15 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A]">
            Empowering Every Stakeholder
          </h2>
        </motion.div>

        {/* 2x2 Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {stakeholders.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              whileHover={{ scale: 1.02 }}
              className="group relative rounded-[24px] overflow-hidden h-[280px] cursor-pointer"
            >
              {/* Background Image */}
              <ImageWithFallback
                src={item.image}
                alt={item.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />

              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent group-hover:from-black/70 transition-colors" />

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-2xl font-bold mb-2">{item.title}</h3>
                <p className="text-sm text-white/90 mb-3 line-clamp-2">
                  {item.description}
                </p>
                <div className="inline-flex items-center gap-2 text-sm font-semibold">
                  <span>Learn More</span>
                  <ArrowRight className="size-4" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION 4 — Featured Training Programs (Horizontal Slider)
export function FinalFeaturedPrograms() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const scrollRef = useRef<HTMLDivElement>(null);

  const programs = [
    {
      image: "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=500&h=350&fit=crop",
      title: "Electric Vehicle Technology",
      duration: "6 Months",
      level: "Advanced",
    },
    {
      image: "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=500&h=350&fit=crop",
      title: "Automotive Service Technician",
      duration: "12 Months",
      level: "Beginner",
    },
    {
      image: "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d6?w=500&h=350&fit=crop",
      title: "Connected Vehicle Systems",
      duration: "4 Months",
      level: "Intermediate",
    },
    {
      image: "https://images.unsplash.com/photo-1485463611174-f302f6a5c1c9?w=500&h=350&fit=crop",
      title: "Hybrid Vehicle Maintenance",
      duration: "6 Months",
      level: "Advanced",
    },
  ];

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 400;
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  return (
    <section ref={ref} className="py-15 bg-gradient-to-b from-white to-[#F8FAFB]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-between mb-10"
        >
          <div>
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-2">
              Featured Training Programs
            </h2>
            <p className="text-lg text-[#64748B]">Industry-aligned certification programs</p>
          </div>

          {/* Scroll Arrows */}
          <div className="hidden lg:flex gap-2">
            <button
              onClick={() => scroll("left")}
              className="size-10 bg-white border border-gray-200 rounded-full flex items-center justify-center hover:bg-[#0066FF] hover:text-white hover:border-[#0066FF] transition-all"
            >
              <ChevronLeft className="size-5" />
            </button>
            <button
              onClick={() => scroll("right")}
              className="size-10 bg-white border border-gray-200 rounded-full flex items-center justify-center hover:bg-[#0066FF] hover:text-white hover:border-[#0066FF] transition-all"
            >
              <ChevronRight className="size-5" />
            </button>
          </div>
        </motion.div>

        {/* Horizontal Scrollable Cards */}
        <div
          ref={scrollRef}
          className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide -mx-6 px-6 lg:mx-0 lg:px-0"
        >
          {programs.map((program, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: 50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="group min-w-[320px] bg-white rounded-[20px] overflow-hidden shadow-md hover:shadow-2xl transition-all snap-start"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <ImageWithFallback
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                
                {/* Level Badge */}
                <div className="absolute top-4 right-4 px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-bold text-[#0066FF]">
                  {program.level}
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <h3 className="font-bold text-lg text-[#0A0A0A] mb-2">{program.title}</h3>
                <p className="text-sm text-[#64748B] mb-4">Duration: {program.duration}</p>
                <a
                  href="#programs"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[#0066FF] hover:gap-3 transition-all"
                >
                  <span>View Details</span>
                  <ArrowRight className="size-4" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
