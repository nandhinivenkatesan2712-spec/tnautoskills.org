import { motion, useInView } from "motion/react";
import { useRef, useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Quote, Briefcase, GraduationCap } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const stories = [
  {
    name: "Rajesh Kumar",
    program: "EV Technology Specialist",
    role: "EV Technician",
    company: "Hyundai Motor India",
    quote:
      "The hands-on training and industry exposure at TN AutoSkills transformed my career. I'm now working on cutting-edge electric vehicle technology.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
  },
  {
    name: "Priya Sharma",
    program: "Advanced Automotive Engineering",
    role: "Automotive Engineer",
    company: "Bosch India",
    quote:
      "The curriculum was perfectly aligned with industry needs. Within 3 months of completing the program, I secured my dream job.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
  },
  {
    name: "Mohammed Farhan",
    program: "Robotics & Automation",
    role: "Robotics Specialist",
    company: "BMW Group India",
    quote:
      "The robotics and automation training gave me skills that are in high demand. I'm grateful for the world-class facilities and expert mentorship.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop",
  },
  {
    name: "Lakshmi Devi",
    program: "Quality Management Systems",
    role: "Quality Analyst",
    company: "Toyota Kirloskar",
    quote:
      "From classroom to career, TN AutoSkills supported me every step of the way. The placement assistance was excellent.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop",
  },
  {
    name: "Arun Prakash",
    program: "Hybrid Vehicle Technology",
    role: "Service Engineer",
    company: "Maruti Suzuki",
    quote:
      "The blend of theory and practical training prepared me for real-world challenges. I now lead a team of technicians.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
  },
  {
    name: "Divya Reddy",
    program: "Manufacturing Excellence",
    role: "Production Supervisor",
    company: "Mahindra & Mahindra",
    quote:
      "TN AutoSkills didn't just teach me technical skills—they built my confidence and leadership abilities.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
  },
];

export function SuccessStories() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Auto-scroll functionality
  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % stories.length);
    }, 5000); // Change slide every 5 seconds

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const next = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % stories.length);
  };

  const prev = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + stories.length) % stories.length);
  };

  const goToSlide = (index: number) => {
    setIsAutoPlaying(false);
    setCurrentIndex(index);
  };

  return (
    <section 
      ref={ref} 
      className="pt-20 pb-14 bg-[#F3F6F9] relative overflow-hidden"
    >
      {/* Background Decorative Elements */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.15, 0.25, 0.15],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-20 right-10 w-[300px] sm:w-[400px] lg:w-[500px] h-[300px] sm:h-[400px] lg:h-[500px] bg-[#004ABB]/15 rounded-full blur-3xl"
      />
      <motion.div
        initial={{ opacity: 0.3, scale: 0.8 }}
        animate={{
          opacity: [0.3, 0.5, 0.3],
          scale: [0.8, 1, 0.8],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute bottom-20 left-10 w-[300px] sm:w-[400px] lg:w-[500px] h-[300px] sm:h-[400px] lg:h-[500px] bg-[#0055DD]/15 rounded-full blur-3xl"
      />

      <div className="relative max-w-[1440px] mx-auto px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="w-24 h-1 bg-gradient-to-r from-[#004ABB] to-[#0055DD] rounded-full mx-auto mb-8" />
          <h2 className="text-5xl lg:text-6xl font-extrabold text-[#0A0A0A] mb-4">
            Success Stories
          </h2>
          <p className="text-lg xl:text-xl text-[#475569] max-w-3xl mx-auto">
            Real stories from our alumni making waves in the automotive industry
          </p>
        </motion.div>

        {/* Carousel Container */}
        <div className="relative">
          {/* Navigation Arrows - Desktop */}
          <motion.button
            whileHover={{ scale: 1.1, x: -4 }}
            whileTap={{ scale: 0.95 }}
            onClick={prev}
            className="hidden lg:flex absolute left-0 top-1/2 -translate-y-1/2 -translate-x-6 z-20 size-12 lg:size-14 rounded-full bg-white shadow-xl hover:shadow-2xl items-center justify-center text-[#0066FF] hover:bg-[#0066FF] hover:text-white transition-all duration-300 border border-gray-100 focus:outline-none focus:ring-2 focus:ring-white/80 focus:ring-offset-2"
            aria-label="Previous success story"
          >
            <ChevronLeft className="size-5 lg:size-6" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.1, x: 4 }}
            whileTap={{ scale: 0.95 }}
            onClick={next}
            className="hidden lg:flex absolute right-0 top-1/2 -translate-y-1/2 translate-x-6 z-20 size-12 lg:size-14 rounded-full bg-white shadow-xl hover:shadow-2xl items-center justify-center text-[#0066FF] hover:bg-[#0066FF] hover:text-white transition-all duration-300 border border-gray-100 focus:outline-none focus:ring-2 focus:ring-white/80 focus:ring-offset-2"
            aria-label="Next success story"
          >
            <ChevronRight className="size-5 lg:size-6" />
          </motion.button>

          {/* Cards Container */}
          <div className="overflow-hidden">
            <motion.div
              className="flex gap-4 sm:gap-6"
              animate={{
                x: `-${currentIndex * (100 / 3)}%`,
              }}
              transition={{
                type: "spring",
                stiffness: 300,
                damping: 30,
              }}
            >
              {stories.map((story, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  animate={
                    isInView
                      ? { opacity: 1, y: 0 }
                      : { opacity: 0, y: 50 }
                  }
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="min-w-full md:min-w-[calc(50%-12px)] lg:min-w-[calc(33.333%-16px)] flex-shrink-0"
                >
                  <div className="bg-white rounded-[20px] shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden border border-gray-100 h-full group">
                    {/* Card Header - Photo & Company */}
                    <div className="relative h-64 overflow-hidden bg-[#F3F6F9]">
                      {/* Photo */}
                      <div className="absolute inset-0">
                        <ImageWithFallback
                          src={story.image}
                          alt={`${story.name} - ${story.role} at ${story.company}`}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        />
                        {/* Gradient Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
                      </div>

                      {/* Company Badge */}
                      <motion.div
                        whileHover={{ scale: 1.05 }}
                        className="absolute top-4 right-4 bg-white/95 backdrop-blur-md rounded-xl px-3 py-1.5 shadow-lg border border-blue-100"
                      >
                        <span className="text-xs font-bold text-[#0066FF]">
                          {story.company}
                        </span>
                      </motion.div>

                      {/* Quote Icon */}
                      <div className="absolute top-4 left-4 size-12 bg-gradient-to-br from-[#004ABB]/90 to-[#0055DD]/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg">
                        <Quote className="size-6 text-white fill-white" />
                      </div>

                      {/* Name Overlay */}
                      <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
                        <h3 className="text-xl font-bold mb-1">{story.name}</h3>
                        <div className="flex items-center gap-2 text-sm text-white/90">
                          <Briefcase className="size-3.5" />
                          <span>{story.role}</span>
                        </div>
                      </div>
                    </div>

                    {/* Card Body - Testimonial & Program */}
                    <div className="p-6 space-y-4">
                      {/* Program Badge */}
                      <div className="flex items-center gap-2 text-sm">
                        <div className="size-8 rounded-lg bg-[#EEF5FF] flex items-center justify-center">
                          <GraduationCap className="size-4 text-[#004ABB]" />
                        </div>
                        <span className="text-[#64748b] font-medium">{story.program}</span>
                      </div>

                      {/* Testimonial */}
                      <blockquote className="text-[#475569] leading-relaxed text-sm line-clamp-4">
                        "{story.quote}"
                      </blockquote>

                      {/* Gradient Accent Bar */}
                      <div className="pt-2">
                        <div className="h-1 w-16 bg-gradient-to-r from-[#004ABB] to-[#0055DD] rounded-full" />
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Mobile Navigation */}
          <div className="flex lg:hidden justify-center gap-3 mt-6">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={prev}
              className="size-12 rounded-full bg-white shadow-lg hover:shadow-xl flex items-center justify-center text-[#0066FF] hover:bg-[#0066FF] hover:text-white transition-all border border-gray-200 focus:outline-none focus:ring-2 focus:ring-white/80 focus:ring-offset-2"
              aria-label="Previous success story"
            >
              <ChevronLeft className="size-5" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={next}
              className="size-12 rounded-full bg-white shadow-lg hover:shadow-xl flex items-center justify-center text-[#0066FF] hover:bg-[#0066FF] hover:text-white transition-all border border-gray-200 focus:outline-none focus:ring-2 focus:ring-white/80 focus:ring-offset-2"
              aria-label="Next success story"
            >
              <ChevronRight className="size-5" />
            </motion.button>
          </div>
        </div>

        {/* Dots Indicator */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {stories.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`transition-all duration-300 rounded-full ${
                index === currentIndex
                  ? "w-10 h-2 bg-gradient-to-r from-[#004ABB] to-[#0055DD]"
                  : "w-2 h-2 bg-gray-300 hover:bg-gray-400"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

        {/* Auto-play indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-center mt-6"
        >
          <button
            onClick={() => setIsAutoPlaying(!isAutoPlaying)}
            className="text-xs text-[#64748b] hover:text-[#0066FF] transition-colors font-medium"
          >
            {isAutoPlaying ? "⏸ Pause Auto-play" : "▶ Resume Auto-play"}
          </button>
        </motion.div>
      </div>
    </section>
  );
}