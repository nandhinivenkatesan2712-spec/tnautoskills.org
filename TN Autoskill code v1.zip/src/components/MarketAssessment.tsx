import { motion, useInView } from "motion/react";
import { useRef } from "react";
import imgAssessment from "figma:asset/33f1931cde1427ff194ad3f5dc684b5ea1d0c1fe.png";

export function MarketAssessment() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section ref={ref} className="relative py-24 bg-white overflow-hidden">
      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="col-span-12 lg:col-span-6"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img src={imgAssessment} alt="Market Assessment" className="w-full h-auto" />
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="col-span-12 lg:col-span-6 space-y-6"
          >
            <h2 className="text-[#0b1220] text-4xl md:text-5xl tracking-tight">
              Our Approach
            </h2>
            <p className="text-gray-500 text-lg leading-relaxed">
              We conduct comprehensive market assessments to identify skill gaps and align our
              training programs with industry demands. Our data-driven approach ensures that
              every graduate is equipped with the most relevant and in-demand skills.
            </p>
            <ul className="space-y-4">
              {["Industry Analysis", "Skill Gap Identification", "Curriculum Design", "Continuous Improvement"].map((item, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="flex items-center gap-3 text-gray-600"
                >
                  <div className="size-6 rounded-full bg-gradient-to-br from-[#0f73f7] to-[#0ea5e9] flex items-center justify-center flex-shrink-0">
                    <svg className="size-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span>{item}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
