import { motion, useInView } from "motion/react";
import { useRef } from "react";
import svgPaths from "../imports/svg-nlmkrgxccf";

const stats = [
  {
    icon: (
      <svg className="size-7" fill="none" viewBox="0 0 28 28">
        <path
          d={svgPaths.p184ba090}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d={svgPaths.p294ecc00}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d={svgPaths.p2f1426c0}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d={svgPaths.p5d36b00}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
      </svg>
    ),
    value: "2,242+",
    label: "Trained",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: (
      <svg className="size-7" fill="none" viewBox="0 0 28 28">
        <path
          d={svgPaths.p275e0300}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d={svgPaths.p3997a780}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
      </svg>
    ),
    value: "85%",
    label: "Placement Rate",
    gradient: "from-blue-500 to-purple-500"
  },
  {
    icon: (
      <svg className="size-7" fill="none" viewBox="0 0 28 28">
        <path
          d={svgPaths.pa75a70}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d={svgPaths.p1082cc0}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d={svgPaths.pcc42cc0}
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d="M11.6667 7H16.3333"
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d="M11.6667 11.6667H16.3333"
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d="M11.6667 16.3333H16.3333"
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
        <path
          d="M11.6667 21H16.3333"
          stroke="#0F73F7"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.33333"
        />
      </svg>
    ),
    value: "100+",
    label: "Industry Partners",
    gradient: "from-cyan-500 to-blue-500"
  }
];

export function StatsCard() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <div className="relative max-w-[1440px] mx-auto px-6 lg:px-8 -mt-20 pb-24">
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 50 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6 }}
        className="bg-white/70 backdrop-blur-lg rounded-3xl shadow-xl shadow-blue-500/15 border border-white/80 overflow-hidden"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-gray-200">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: index * 0.1 + 0.2, duration: 0.5 }}
              whileHover={{ scale: 1.05 }}
              className="p-8 flex flex-col items-center text-center gap-4 cursor-pointer group"
            >
              {/* Icon */}
              <motion.div
                whileHover={{ rotate: 5 }}
                className="size-14 rounded-2xl border-2 border-blue-200/50 bg-white flex items-center justify-center shadow-lg shadow-blue-500/10 group-hover:shadow-blue-500/20 transition-shadow"
              >
                {stat.icon}
              </motion.div>

              {/* Value with gradient */}
              <div
                className="bg-gradient-to-r bg-clip-text text-transparent"
                style={{
                  backgroundImage: `linear-gradient(to right, rgb(11, 18, 32), rgb(11, 18, 32))`
                }}
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={isInView ? { scale: 1 } : {}}
                  transition={{ delay: index * 0.1 + 0.4, type: "spring", stiffness: 200 }}
                  className="text-[#0b1220] text-4xl lg:text-5xl"
                >
                  {stat.value}
                </motion.div>
              </div>

              {/* Label */}
              <div className="text-slate-600">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
