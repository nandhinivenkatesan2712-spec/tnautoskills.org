import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  Target,
  Users,
  Award,
  TrendingUp,
  GraduationCap,
  Wrench,
  Briefcase,
  Handshake,
  Building2,
  BookOpen,
  CheckCircle,
  ChevronRight,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// 1. WHO WE ARE - Enhanced Visual Design
export function EnhancedWhoWeAre() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-16 bg-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-40">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#0066FF]/5 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-[#0090FF]/5 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-[52%_48%] gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="space-y-6"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#0090FF]/10 rounded-full border border-[#0066FF]/20"
            >
              <Sparkles className="size-3.5 text-[#0066FF]" />
              <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">About Us</span>
            </motion.div>

            {/* Title */}
            <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] leading-[1.1] tracking-tight">
              Who We Are
            </h2>

            {/* Main Content */}
            <p className="text-lg text-[#475569] leading-relaxed">
              <strong className="text-[#0A0A0A] font-bold">TN Auto Skills</strong> is a government initiative focused on developing industry-ready automotive talent across Tamil Nadu.
            </p>

            {/* Feature Points */}
            <div className="space-y-3 pt-2">
              {[
                "Advanced, job-oriented training programs aligned with modern automobile technologies",
                "Bridge the skill gap and empower youth with hands-on learning",
                "Strong industry partnerships for career opportunities and internships",
                "Continuous upskilling and real-world expertise development",
              ].map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.2 + idx * 0.1 }}
                  className="flex items-start gap-3 group"
                >
                  <div className="mt-1 size-5 rounded-full bg-[#0066FF]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#0066FF] transition-colors">
                    <CheckCircle className="size-3.5 text-[#0066FF] group-hover:text-white transition-colors" />
                  </div>
                  <span className="text-[15px] text-[#475569] leading-relaxed">{item}</span>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <motion.a
              href="#about"
              whileHover={{ x: 4 }}
              className="inline-flex items-center gap-2 text-[#0066FF] font-semibold text-[15px] hover:gap-3 transition-all pt-2"
            >
              <span>Read More About Us</span>
              <ArrowRight className="size-4" />
            </motion.a>
          </motion.div>

          {/* Right Visual */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-gray-100">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1581092918484-8313e1f7e8d6?w=700&h=500&fit=crop"
                alt="Automotive training facility"
                className="w-full h-[420px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0066FF]/30 via-transparent to-transparent" />
              
              {/* Floating Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-md rounded-2xl p-5 shadow-xl border border-white/50"
              >
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { value: "2500+", label: "Trained" },
                    { value: "500+", label: "Certified" },
                    { value: "95%", label: "Success" },
                  ].map((stat, idx) => (
                    <div key={idx} className="text-center">
                      <div className="text-2xl font-extrabold text-[#0066FF] mb-0.5">{stat.value}</div>
                      <div className="text-[11px] text-[#64748B] font-medium uppercase tracking-wide">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 size-24 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-2xl rotate-12 opacity-20 blur-xl" />
            <div className="absolute -bottom-4 -left-4 size-20 bg-gradient-to-br from-[#0090FF] to-[#0066FF] rounded-2xl -rotate-12 opacity-20 blur-xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// 2. EXPLORE WHAT WE ARE DOING - Enhanced Cards
export function EnhancedExploreServices() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const services = [
    {
      icon: GraduationCap,
      title: "Industry-Aligned Skill Training",
      description: "Structured, government-certified automotive training programs based on evolving industry standards.",
      gradient: "from-blue-500 via-blue-600 to-indigo-600",
      iconBg: "from-blue-50 to-indigo-50",
    },
    {
      icon: Wrench,
      title: "Hands-On Technical Workshops",
      description: "Practical sessions, advanced labs, and real-world automotive tools.",
      gradient: "from-indigo-500 via-purple-600 to-purple-600",
      iconBg: "from-indigo-50 to-purple-50",
    },
    {
      icon: Briefcase,
      title: "Career Guidance & Placement",
      description: "Placement support with leading automotive companies, counseling, interview prep.",
      gradient: "from-purple-500 via-pink-600 to-rose-600",
      iconBg: "from-purple-50 to-pink-50",
    },
    {
      icon: Users,
      title: "Internship & On-the-Job Training",
      description: "Internships and OJT opportunities to understand real workflows.",
      gradient: "from-rose-500 via-red-600 to-orange-600",
      iconBg: "from-rose-50 to-orange-50",
    },
    {
      icon: TrendingUp,
      title: "Upskilling for Working Professionals",
      description: "Short-term enhancement courses to grow in the workplace.",
      gradient: "from-orange-500 via-amber-600 to-yellow-600",
      iconBg: "from-orange-50 to-amber-50",
    },
    {
      icon: Handshake,
      title: "Industry Partnership & Collaboration",
      description: "Work with OEMs, suppliers, and institutions to build the future workforce.",
      gradient: "from-emerald-500 via-teal-600 to-cyan-600",
      iconBg: "from-emerald-50 to-teal-50",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-b from-[#F8FAFB] to-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-gray-100 mb-5">
            <div className="size-1.5 bg-[#0066FF] rounded-full animate-pulse" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Our Services</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] mb-4 leading-[1.1] tracking-tight">
            Explore What We Are Doing
          </h2>

          <p className="text-lg text-[#64748B] max-w-3xl mx-auto leading-relaxed">
            Comprehensive programs designed to develop automotive talent and bridge the industry skill gap
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, idx) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group relative bg-white rounded-2xl p-7 shadow-md hover:shadow-2xl transition-all border border-gray-100 overflow-hidden"
              >
                {/* Background Gradient on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />
                
                <div className="relative z-10">
                  {/* Icon */}
                  <div className={`size-14 bg-gradient-to-br ${service.iconBg} rounded-xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="size-7 text-[#0066FF]" strokeWidth={2.5} />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-bold text-[#0A0A0A] mb-3 leading-tight">
                    {service.title}
                  </h3>
                  <p className="text-[15px] text-[#64748B] leading-relaxed mb-4">
                    {service.description}
                  </p>

                  {/* Arrow */}
                  <div className="flex items-center gap-2 text-[#0066FF] font-semibold text-sm opacity-0 group-hover:opacity-100 transition-opacity">
                    <span>Learn more</span>
                    <ChevronRight className="size-4" />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// 3. EMPOWERING STAKEHOLDERS - Enhanced Visual Cards
export function EnhancedStakeholders() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stakeholders = [
    {
      icon: Users,
      title: "Candidates",
      description: "Access government-certified training, hands-on skills, and direct placement opportunities.",
      color: "from-blue-500 to-blue-600",
      bgPattern: "from-blue-50 to-blue-100/50",
    },
    {
      icon: Building2,
      title: "Industry",
      description: "Partner with us to build a skilled workforce aligned with your technology needs.",
      color: "from-indigo-500 to-indigo-600",
      bgPattern: "from-indigo-50 to-indigo-100/50",
    },
    {
      icon: BookOpen,
      title: "Academia",
      description: "Collaborate on curriculum development and provide students with industry exposure.",
      color: "from-purple-500 to-purple-600",
      bgPattern: "from-purple-50 to-purple-100/50",
    },
    {
      icon: Award,
      title: "Trainers & Assessors",
      description: "Join our network of certified professionals delivering world-class training.",
      color: "from-pink-500 to-pink-600",
      bgPattern: "from-pink-50 to-pink-100/50",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-[#0066FF]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-[#0090FF]/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#0090FF]/10 rounded-full border border-[#0066FF]/20 mb-5">
            <Target className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Stakeholders</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] leading-[1.1] tracking-tight">
            Empowering Every Stakeholder
          </h2>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stakeholders.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -8, scale: 1.03 }}
                className="group relative bg-white rounded-2xl p-6 shadow-md hover:shadow-2xl transition-all border border-gray-100 overflow-hidden cursor-pointer"
              >
                {/* Background Pattern */}
                <div className={`absolute inset-0 bg-gradient-to-br ${item.bgPattern} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                
                <div className="relative z-10">
                  {/* Icon */}
                  <div className={`size-14 bg-gradient-to-br ${item.color} rounded-xl flex items-center justify-center mb-5 shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}>
                    <Icon className="size-7 text-white" strokeWidth={2.5} />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-bold text-[#0A0A0A] mb-3 leading-tight">
                    {item.title}
                  </h3>
                  <p className="text-[15px] text-[#64748B] leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Hover Arrow */}
                <div className="absolute bottom-6 right-6 size-8 bg-[#0066FF] rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 transition-all">
                  <ChevronRight className="size-4 text-white" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
