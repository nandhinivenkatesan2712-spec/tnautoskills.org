import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import { 
  ArrowRight,
  Zap,
  MonitorPlay,
  Bot,
  Gauge,
  Wrench,
  Battery,
  ChevronDown,
  ChevronUp,
  Award,
  CheckCircle,
  Calendar,
  GraduationCap
} from "lucide-react";
import { UnifiedBanner } from "./UnifiedBanner";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// Facilities data
const facilities = [
  {
    id: 1,
    icon: Zap,
    name: "Electric Vehicle Lab",
    description: "Advanced EV technology training with real vehicle platforms",
    color: "#0066FF",
    image: "electric vehicle lab",
    fullDescription: "State-of-the-art Electric Vehicle Laboratory equipped with cutting-edge EV platforms, battery management systems, and charging infrastructure. Students gain hands-on experience with electric powertrains, regenerative braking systems, and advanced battery technologies.",
    whatStudentsLearn: [
      "EV powertrain components and architecture",
      "Battery pack assembly and management systems",
      "Electric motor control and diagnostics",
      "Charging infrastructure and protocols",
      "High-voltage safety procedures"
    ],
    technologiesUsed: [
      "Tesla Model 3 Platform",
      "BYD Battery Systems",
      "Bosch EV Diagnostic Tools",
      "Level 2 & DC Fast Chargers",
      "CANalyzer Software"
    ]
  },
  {
    id: 2,
    icon: MonitorPlay,
    name: "Advanced Simulation Lab",
    description: "Virtual reality and simulation-based automotive training",
    color: "#0090FF",
    image: "automotive simulation lab",
    fullDescription: "Industry-leading simulation laboratory featuring VR/AR technology for immersive automotive training. Students experience realistic scenarios in a safe, controlled environment before working on actual vehicles.",
    whatStudentsLearn: [
      "Virtual vehicle assembly and disassembly",
      "Diagnostic simulation scenarios",
      "Collision repair simulations",
      "Paint booth operations in VR",
      "Safety protocol training"
    ],
    technologiesUsed: [
      "Oculus Quest VR Headsets",
      "ANSYS Automotive Simulation",
      "Unity 3D Engine",
      "HTC Vive Pro Systems",
      "Haptic Feedback Controllers"
    ]
  },
  {
    id: 3,
    icon: Bot,
    name: "Robotics & Automation Center",
    description: "Smart manufacturing with industrial robots and automation",
    color: "#0066FF",
    image: "robotics automation lab",
    fullDescription: "Comprehensive robotics facility showcasing Industry 4.0 technologies. Students learn programming, operation, and maintenance of industrial robots used in modern automotive manufacturing.",
    whatStudentsLearn: [
      "Industrial robot programming (ABB, KUKA)",
      "Automated assembly line operations",
      "PLC programming and control",
      "Collaborative robotics (Cobots)",
      "Vision systems and sensors"
    ],
    technologiesUsed: [
      "ABB IRB 6700 Robots",
      "KUKA KR QUANTEC Series",
      "Siemens PLC Systems",
      "Universal Robots UR10",
      "Cognex Vision Systems"
    ]
  },
  {
    id: 4,
    icon: Gauge,
    name: "Vehicle Dynamics Testing Lab",
    description: "Performance testing with dynamometers and telemetry systems",
    color: "#0090FF",
    image: "vehicle testing lab",
    fullDescription: "Professional-grade vehicle dynamics laboratory equipped with chassis dynamometers, suspension testing rigs, and advanced data acquisition systems for comprehensive vehicle performance analysis.",
    whatStudentsLearn: [
      "Chassis dynamometer operations",
      "Suspension geometry analysis",
      "Brake system performance testing",
      "Wheel alignment and balancing",
      "Vehicle telemetry data analysis"
    ],
    technologiesUsed: [
      "4WD Chassis Dynamometer",
      "K&C Suspension Test Rig",
      "Hunter Alignment Systems",
      "MOTEC Data Logging",
      "AVL Vehicle Instrumentation"
    ]
  },
  {
    id: 5,
    icon: Wrench,
    name: "Diagnostics & Repair Lab",
    description: "Modern diagnostic tools and repair bay facilities",
    color: "#0066FF",
    image: "automotive repair shop",
    fullDescription: "Fully-equipped diagnostic and repair facility featuring the latest OEM-level diagnostic equipment, specialized tools, and complete service bay infrastructure for comprehensive automotive repair training.",
    whatStudentsLearn: [
      "Advanced diagnostic scan tools usage",
      "Engine management system repair",
      "Transmission diagnostics and service",
      "ADAS calibration procedures",
      "Air conditioning system service"
    ],
    technologiesUsed: [
      "Bosch KTS Diagnostic Systems",
      "Launch X-431 Scanners",
      "Autel MaxiSys Elite",
      "ADAS Calibration Frames",
      "Robinair AC Service Stations"
    ]
  },
  {
    id: 6,
    icon: Battery,
    name: "Battery & Energy Systems Lab",
    description: "Battery technology research and energy management systems",
    color: "#0090FF",
    image: "battery technology lab",
    fullDescription: "Specialized laboratory for advanced battery technologies and energy storage systems. Focus on lithium-ion battery chemistry, thermal management, and next-generation energy solutions for electric mobility.",
    whatStudentsLearn: [
      "Battery cell chemistry and construction",
      "Thermal management system design",
      "Battery pack testing and validation",
      "Energy storage system integration",
      "Battery recycling and sustainability"
    ],
    technologiesUsed: [
      "Battery Cyclers and Testers",
      "Thermal Imaging Cameras",
      "Electrochemical Analyzers",
      "High-Voltage Testing Equipment",
      "Battery Management System Tools"
    ]
  }
];

// Gallery images (placeholder data)
const galleryImages = [
  { id: 1, alt: "Electric Vehicle Workshop", query: "electric car workshop" },
  { id: 2, alt: "Robotics Lab", query: "industrial robotics lab" },
  { id: 3, alt: "Simulation Training", query: "vr training automotive" },
  { id: 4, alt: "Vehicle Testing", query: "automotive testing lab" },
  { id: 5, alt: "Modern Workshop", query: "modern automotive workshop" },
  { id: 6, alt: "Battery Lab", query: "battery research lab" }
];

export function FacilitiesPage() {
  const gridRef = useRef(null);
  const detailsRef = useRef(null);
  const galleryRef = useRef(null);
  const ctaRef = useRef(null);
  
  const isGridInView = useInView(gridRef, { once: true, margin: "-100px" });
  const isDetailsInView = useInView(detailsRef, { once: true, margin: "-100px" });
  const isGalleryInView = useInView(galleryRef, { once: true, margin: "-100px" });
  const isCtaInView = useInView(ctaRef, { once: true, margin: "-100px" });

  const [expandedLab, setExpandedLab] = useState<number | null>(null);

  return (
    <div className="bg-white">
      {/* Unified Banner */}
      <UnifiedBanner
        title="Centre of Excellence – Facilities"
        subtitle="Industry-grade labs enabling hands-on automotive learning"
        badge={
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/90 backdrop-blur-md rounded-2xl shadow-lg border border-gray-100">
              <Award className="size-8 text-[#0066FF]" />
              <div className="text-left">
                <div className="text-sm font-bold text-[#0A0A0A]">100% Modern Facilities</div>
                <div className="text-xs text-[#64748b]">Latest Technology</div>
              </div>
            </div>
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/90 backdrop-blur-md rounded-2xl shadow-lg border border-gray-100">
              <CheckCircle className="size-8 text-[#0090FF]" />
              <div className="text-left">
                <div className="text-sm font-bold text-[#0A0A0A]">Industry Supported</div>
                <div className="text-xs text-[#64748b]">OEM Partnerships</div>
              </div>
            </div>
          </div>
        }
      />

      {/* Section 1: Facilities Grid */}
      <section ref={gridRef} className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isGridInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-6" />
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
              World-Class Training Facilities
            </h2>
            <p className="text-lg text-[#475569] max-w-3xl mx-auto">
              Experience cutting-edge automotive technology in our state-of-the-art laboratories
            </p>
          </motion.div>

          {/* Facilities Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {facilities.map((facility, index) => {
              const IconComponent = facility.icon;
              return (
                <motion.div
                  key={facility.id}
                  initial={{ opacity: 0, y: 50 }}
                  animate={isGridInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ y: -8, scale: 1.02 }}
                  className="bg-gradient-to-br from-[#F8FBFF] to-[#EEF5FF] rounded-3xl p-8 border border-gray-200 shadow-md hover:shadow-2xl transition-all cursor-pointer"
                  onClick={() => {
                    setExpandedLab(facility.id);
                    // Scroll to details section
                    detailsRef.current?.scrollIntoView({ behavior: "smooth" });
                  }}
                >
                  {/* Icon */}
                  <div 
                    className="size-16 rounded-2xl flex items-center justify-center mb-5 shadow-lg"
                    style={{
                      background: `linear-gradient(135deg, ${facility.color} 0%, #0090FF 100%)`
                    }}
                  >
                    <IconComponent className="size-8 text-white" />
                  </div>

                  {/* Name */}
                  <h3 className="text-xl font-bold text-[#0A0A0A] mb-3">
                    {facility.name}
                  </h3>

                  {/* Description */}
                  <p className="text-base text-[#475569] mb-6 leading-relaxed">
                    {facility.description}
                  </p>

                  {/* View Details Button */}
                  <motion.button
                    whileHover={{ x: 5 }}
                    className="inline-flex items-center gap-2 text-[#0066FF] font-semibold text-sm"
                  >
                    <span>View Details</span>
                    <ArrowRight className="size-4" />
                  </motion.button>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Section 2: Lab Detail Preview */}
      <section ref={detailsRef} className="pt-20 pb-14 bg-[#F3F6F9]">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isDetailsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-6" />
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
              Explore Our Facilities
            </h2>
            <p className="text-lg text-[#475569]">
              Click on a facility to learn more about equipment and training
            </p>
          </motion.div>

          {/* Expandable Lab Details */}
          <div className="space-y-6">
            {facilities.map((facility, index) => {
              const IconComponent = facility.icon;
              const isExpanded = expandedLab === facility.id;

              return (
                <motion.div
                  key={facility.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isDetailsInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.05 }}
                  className="bg-white rounded-3xl shadow-lg overflow-hidden border border-gray-200"
                >
                  {/* Header - Always Visible */}
                  <button
                    onClick={() => setExpandedLab(isExpanded ? null : facility.id)}
                    className="w-full p-6 lg:p-8 flex items-center justify-between hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div 
                        className="size-14 rounded-xl flex items-center justify-center shadow-md flex-shrink-0"
                        style={{
                          background: `linear-gradient(135deg, ${facility.color} 0%, #0090FF 100%)`
                        }}
                      >
                        <IconComponent className="size-7 text-white" />
                      </div>
                      <div className="text-left">
                        <h3 className="text-xl lg:text-2xl font-bold text-[#0A0A0A] mb-1">
                          {facility.name}
                        </h3>
                        <p className="text-sm text-[#64748b]">
                          {facility.description}
                        </p>
                      </div>
                    </div>
                    <div className="flex-shrink-0 ml-4">
                      {isExpanded ? (
                        <ChevronUp className="size-6 text-[#0066FF]" />
                      ) : (
                        <ChevronDown className="size-6 text-[#475569]" />
                      )}
                    </div>
                  </button>

                  {/* Expanded Content */}
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.4 }}
                      className="border-t border-gray-200"
                    >
                      <div className="p-6 lg:p-8">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                          {/* Left: Image */}
                          <div className="relative rounded-2xl overflow-hidden shadow-xl aspect-[4/3] bg-gradient-to-br from-gray-100 to-gray-200">
                            <ImageWithFallback
                              src={`https://source.unsplash.com/800x600/?${facility.image}`}
                              alt={facility.name}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                          </div>

                          {/* Right: Details */}
                          <div className="space-y-6">
                            {/* Full Description */}
                            <div>
                              <h4 className="text-lg font-bold text-[#0A0A0A] mb-3">
                                About This Facility
                              </h4>
                              <p className="text-base text-[#475569] leading-relaxed">
                                {facility.fullDescription}
                              </p>
                            </div>

                            {/* What Students Learn */}
                            <div>
                              <h4 className="text-lg font-bold text-[#0A0A0A] mb-3 flex items-center gap-2">
                                <GraduationCap className="size-5 text-[#0066FF]" />
                                What Students Learn
                              </h4>
                              <ul className="space-y-2">
                                {facility.whatStudentsLearn.map((item, idx) => (
                                  <li key={idx} className="flex items-start gap-2 text-sm text-[#475569]">
                                    <CheckCircle className="size-4 text-[#0066FF] flex-shrink-0 mt-0.5" />
                                    <span>{item}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {/* Technologies Used */}
                            <div>
                              <h4 className="text-lg font-bold text-[#0A0A0A] mb-3 flex items-center gap-2">
                                <Award className="size-5 text-[#0090FF]" />
                                Technologies Used
                              </h4>
                              <ul className="space-y-2">
                                {facility.technologiesUsed.map((tech, idx) => (
                                  <li key={idx} className="flex items-start gap-2 text-sm text-[#475569]">
                                    <CheckCircle className="size-4 text-[#0090FF] flex-shrink-0 mt-0.5" />
                                    <span>{tech}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {/* CTA */}
                            <motion.a
                              href="#apply"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-2xl font-semibold shadow-lg hover:shadow-xl transition-all"
                            >
                              <span>Apply Now</span>
                              <ArrowRight className="size-5" />
                            </motion.a>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Section 3: Photo Gallery */}
      <section ref={galleryRef} className="pt-20 pb-14 bg-white">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isGalleryInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="w-24 h-1 bg-gradient-to-r from-[#0066FF] to-[#0090FF] rounded-full mx-auto mb-6" />
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-4">
              Facility Gallery
            </h2>
            <p className="text-lg text-[#475569]">
              See our world-class facilities in action
            </p>
          </motion.div>

          {/* Horizontal Scroll Gallery */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isGalleryInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="overflow-x-auto pb-6 scrollbar-hide">
              <div className="flex gap-6" style={{ width: 'max-content' }}>
                {galleryImages.map((image, index) => (
                  <motion.div
                    key={image.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={isGalleryInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ scale: 1.05, y: -10 }}
                    className="relative rounded-2xl overflow-hidden shadow-xl w-[400px] h-[300px] flex-shrink-0 cursor-pointer"
                  >
                    <ImageWithFallback
                      src={`https://source.unsplash.com/800x600/?${image.query}`}
                      alt={image.alt}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent flex items-end p-6">
                      <h4 className="text-white font-bold text-lg">
                        {image.alt}
                      </h4>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Scroll Indicator */}
            <div className="text-center mt-6">
              <p className="text-sm text-[#64748b]">
                ← Scroll to explore more →
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Section 4: CTA Footer */}
      <section ref={ctaRef} className="pt-20 pb-14 bg-[#F3F6F9]">
        <div className="max-w-[1440px] mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isCtaInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-3xl p-12 lg:p-16 text-center shadow-2xl relative overflow-hidden"
          >
            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full -mr-40 -mt-40" />
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-white/10 rounded-full -ml-40 -mb-40" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
            
            <div className="relative z-10">
              <div className="size-20 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <GraduationCap className="size-10 text-white" />
              </div>
              
              <h2 className="text-4xl lg:text-5xl font-extrabold text-white mb-4">
                Start Your Automotive Skill Journey
              </h2>
              
              <p className="text-xl text-white/90 max-w-3xl mx-auto mb-10">
                Train in world-class facilities with industry-standard equipment and expert guidance
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <motion.a
                  href="#apply"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white text-[#0066FF] rounded-2xl font-semibold text-base shadow-xl hover:shadow-2xl transition-all min-h-[44px] flex items-center gap-2"
                >
                  <GraduationCap className="size-5" />
                  <span>Apply for Training</span>
                </motion.a>

                <motion.a
                  href="#contact"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white/20 backdrop-blur-md border-2 border-white text-white rounded-2xl font-semibold text-base hover:bg-white hover:text-[#0066FF] transition-all shadow-lg min-h-[44px] flex items-center gap-2"
                >
                  <Calendar className="size-5" />
                  <span>Schedule a Visit</span>
                </motion.a>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12 pt-12 border-t border-white/20">
                <div>
                  <div className="text-4xl font-extrabold text-white mb-2">6</div>
                  <div className="text-sm text-white/80">Specialized Labs</div>
                </div>
                <div>
                  <div className="text-4xl font-extrabold text-white mb-2">50+</div>
                  <div className="text-sm text-white/80">Industry Tools</div>
                </div>
                <div>
                  <div className="text-4xl font-extrabold text-white mb-2">100%</div>
                  <div className="text-sm text-white/80">Hands-On Training</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Custom CSS for hiding scrollbar */}
      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}