import { motion, useInView } from "motion/react";
import { useRef } from "react";

export function JoinFamilies() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section ref={ref} className="relative py-24 bg-gradient-to-br from-[#0b1220] to-[#1e3a5f] overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: "radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)",
          backgroundSize: "40px 40px"
        }} />
      </div>

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="space-y-8"
        >
          {/* Year Badge */}
          <div className="inline-flex items-center justify-center">
            <div className="text-8xl md:text-9xl bg-gradient-to-r from-[#0f73f7] to-[#06b6d4] bg-clip-text text-transparent">
              2030
            </div>
          </div>

          {/* Heading */}
          <h2 className="text-white text-3xl md:text-4xl lg:text-5xl tracking-tight max-w-3xl mx-auto">
            Join Families 2030
          </h2>

          {/* Description */}
          <p className="text-blue-200 text-lg md:text-xl max-w-2xl mx-auto">
            Be part of our vision to create a skilled workforce ready for the future of mobility.
            Together, we're shaping the automotive industry of tomorrow.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 max-w-4xl mx-auto">
            {[
              { value: "10,000+", label: "Target Graduates" },
              { value: "500+", label: "Partner Companies" },
              { value: "95%", label: "Employment Goal" }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl text-white mb-2">{stat.value}</div>
                <div className="text-blue-300">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
