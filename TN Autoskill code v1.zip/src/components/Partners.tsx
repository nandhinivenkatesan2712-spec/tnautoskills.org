import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { CTAButton } from "./CTAButton";

const partners = [
  "TATA MOTORS",
  "MAHINDRA",
  "HYUNDAI",
  "MARUTI SUZUKI",
  "HERO MOTOCORP",
  "ASHOK LEYLAND",
  "TVS MOTORS",
  "BOSCH",
  "CONTINENTAL",
  "VALEO",
  "MOTHERSON",
  "BHARAT FORGE",
];

export function Partners() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 lg:py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 lg:mb-16 space-y-3"
        >
          <div className="w-16 h-1 bg-gradient-to-r from-[#004ABB] to-[#0055DD] rounded-full mx-auto" />
          <h2 className="text-[#0b1220] text-4xl lg:text-5xl xl:text-6xl font-extrabold">
            Our Partners
          </h2>
          <p className="text-[#475569] text-lg lg:text-xl max-w-3xl mx-auto">
            Trusted by Leading Automotive Companies
          </p>
        </motion.div>

        {/* Logo Slider Container */}
        <div className="relative overflow-hidden bg-white rounded-3xl shadow-lg border border-gray-100 py-12">
          {/* Gradient Fade Edges */}
          <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-white via-white to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-white via-white to-transparent z-10 pointer-events-none" />
          
          {/* Scrolling Logos - First Row */}
          <motion.div
            animate={{
              x: [0, -1400],
            }}
            transition={{
              x: {
                repeat: Infinity,
                repeatType: "loop",
                duration: 30,
                ease: "linear",
              },
            }}
            className="flex gap-16 items-center mb-8"
          >
            {[...partners, ...partners, ...partners].map((partner, i) => (
              <div
                key={i}
                className="flex-shrink-0 px-8 py-4 min-w-[200px] flex items-center justify-center"
              >
                <span className="text-[#0b1220] text-lg font-bold tracking-wider whitespace-nowrap hover:text-[#004ABB] transition-colors">
                  {partner}
                </span>
              </div>
            ))}
          </motion.div>

          {/* Scrolling Logos - Second Row (Reverse) */}
          <motion.div
            animate={{
              x: [-1400, 0],
            }}
            transition={{
              x: {
                repeat: Infinity,
                repeatType: "loop",
                duration: 30,
                ease: "linear",
              },
            }}
            className="flex gap-16 items-center"
          >
            {[...partners, ...partners, ...partners].reverse().map((partner, i) => (
              <div
                key={i}
                className="flex-shrink-0 px-8 py-4 min-w-[200px] flex items-center justify-center"
              >
                <span className="text-[#64748b] text-base font-semibold tracking-wider whitespace-nowrap hover:text-[#004ABB] transition-colors">
                  {partner}
                </span>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Stats Banner */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          <div className="bg-white rounded-2xl p-6 shadow-md border border-gray-100 text-center">
            <div className="text-3xl font-extrabold text-[#004ABB] mb-1">100+</div>
            <div className="text-[#64748b] text-sm font-medium">Industry Partners</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-md border border-gray-100 text-center">
            <div className="text-3xl font-extrabold text-[#004ABB] mb-1">213</div>
            <div className="text-[#64748b] text-sm font-medium">MoUs Signed</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-md border border-gray-100 text-center">
            <div className="text-3xl font-extrabold text-[#004ABB] mb-1">50+</div>
            <div className="text-[#64748b] text-sm font-medium">Global Collaborations</div>
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.6 }}
          className="text-center mt-12"
        >
          <p className="text-[#64748b] mb-4 text-lg">Want to partner with us?</p>
          <CTAButton variant="primary" size="lg">
            Become a Partner
          </CTAButton>
        </motion.div>
      </div>
    </section>
  );
}