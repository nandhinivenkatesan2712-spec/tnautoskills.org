import { motion } from "motion/react";
import svgPaths from "../imports/svg-nlmkrgxccf";

const footerLinks = {
  "Quick Links": [
    { label: "About Us", href: "#about" },
    { label: "Programs", href: "#programs" },
    { label: "Courses", href: "#courses" },
    { label: "Success Stories", href: "#success-stories" },
    { label: "Contact", href: "#contact" }
  ],
  "Programs": [
    { label: "Electric Vehicles", href: "#programs" },
    { label: "Automotive Diagnostics", href: "#programs" },
    { label: "Smart Manufacturing", href: "#programs" },
    { label: "Design Engineering", href: "#programs" }
  ],
  "Resources": [
    { label: "Student Portal", href: "#" },
    { label: "Downloads", href: "#" },
    { label: "Career Guidance", href: "#" },
    { label: "FAQs", href: "#" },
    { label: "Contact", href: "#contact" }
  ],
  "Connect": [
    { label: "Facebook", href: "#" },
    { label: "Twitter", href: "#" },
    { label: "LinkedIn", href: "#" },
    { label: "Instagram", href: "#" },
    { label: "YouTube", href: "#" }
  ]
};

export function Footer() {
  return (
    <footer className="relative bg-[#0b1220] text-white overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: "radial-gradient(circle at 2px 2px, white 1px, transparent 0)",
          backgroundSize: "40px 40px"
        }} />
      </div>

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-8">
        {/* Main Footer */}
        <div className="py-16 border-b border-white/10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
            {/* Brand Column */}
            <div className="lg:col-span-2 space-y-6">
              <div className="flex items-center gap-3">
                <div className="size-12 rounded-full bg-gradient-to-br from-[#0f73f7] to-[#0ea5e9] flex items-center justify-center">
                  <svg className="size-7" fill="none" viewBox="0 0 28 28">
                    <path
                      d={svgPaths.p19a01780}
                      stroke="white"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2.33333"
                    />
                    <path
                      d={svgPaths.p15663e00}
                      stroke="white"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2.33333"
                    />
                    <path
                      d={svgPaths.p3911f600}
                      stroke="white"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2.33333"
                    />
                  </svg>
                </div>
                <span className="text-2xl">TN AutoSkills</span>
              </div>
              <p className="text-blue-200 max-w-md">
                Tamil Nadu's premier institution for automotive skill development, building
                the workforce of tomorrow.
              </p>
              
              {/* Social Links */}
              <div className="flex gap-3">
                {["Facebook", "Twitter", "LinkedIn", "Instagram"].map((social) => (
                  <motion.a
                    key={social}
                    href="#"
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    className="size-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                    aria-label={social}
                  >
                    <svg className="size-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.477 2 2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.879V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.989C18.343 21.129 22 16.99 22 12c0-5.523-4.477-10-10-10z" />
                    </svg>
                  </motion.a>
                ))}
              </div>
            </div>

            {/* Link Columns */}
            {Object.entries(footerLinks).slice(0, 3).map(([title, links]) => (
              <div key={title} className="space-y-4">
                <h3 className="text-lg">{title}</h3>
                <ul className="space-y-3">
                  {links.map((link) => (
                    <li key={link.label}>
                      <motion.a
                        href={link.href}
                        whileHover={{ x: 3 }}
                        className="text-blue-200 hover:text-white transition-colors inline-block"
                      >
                        {link.label}
                      </motion.a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-blue-200">
            <div>© 2024 TN AutoSkills. All rights reserved.</div>
            <div className="flex gap-6">
              <motion.a href="#" whileHover={{ y: -2 }} className="hover:text-white transition-colors">
                Privacy Policy
              </motion.a>
              <motion.a href="#" whileHover={{ y: -2 }} className="hover:text-white transition-colors">
                Terms of Service
              </motion.a>
              <motion.a href="#" whileHover={{ y: -2 }} className="hover:text-white transition-colors">
                Sitemap
              </motion.a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}