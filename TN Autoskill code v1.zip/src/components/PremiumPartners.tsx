import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Building2, Award, Handshake } from "lucide-react";

export function PremiumPartners() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const partners = [
    { name: "Hyundai", category: "OEM" },
    { name: "Maruti Suzuki", category: "OEM" },
    { name: "Tata Motors", category: "OEM" },
    { name: "TVS Motors", category: "OEM" },
    { name: "Ashok Leyland", category: "OEM" },
    { name: "Royal Enfield", category: "OEM" },
    { name: "Ather Energy", category: "EV" },
    { name: "Ola Electric", category: "EV" },
    { name: "Bosch", category: "Supplier" },
    { name: "NVIDIA", category: "Tech" },
    { name: "ASDC", category: "Partner" },
    { name: "ICAT", category: "Partner" },
  ];

  // Duplicate partners for infinite scroll effect
  const infinitePartners = [...partners, ...partners];

  return (
    <section
      ref={ref}
      className="py-[140px] bg-gradient-to-br from-white via-[#F8FAFB] to-[#F0F9FF] relative overflow-hidden"
    >
      {/* Subtle Background Accents */}
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gradient-to-br from-[#0066FF]/5 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-gradient-to-tr from-[#00BCD4]/5 to-transparent rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          {/* Tag */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white/60 backdrop-blur-sm rounded-full border border-[#0066FF]/20 shadow-sm mb-4"
          >
            <Handshake className="size-4 text-[#0066FF]" strokeWidth={2} />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">
              Industry Partnerships
            </span>
          </motion.div>

          {/* Title */}
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#0A0A0A] mb-3">
            Trusted by Leading Automotive Companies
          </h2>

          {/* Tagline */}
          <p className="text-lg font-semibold text-[#0066FF] mb-3">
            Our Partners
          </p>

          {/* Description */}
          <p className="text-[15px] text-[#64748B] max-w-3xl mx-auto leading-relaxed">
            Our industry partnerships strengthen training, placements, internships, and curriculum development.
          </p>
        </motion.div>

        {/* Static Grid (Primary Display) */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 mb-12">
          {partners.map((partner, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: idx * 0.05 }}
              whileHover={{ y: -6, scale: 1.03 }}
              className="group bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-gray-100/50 hover:border-[#0066FF]/30 hover:shadow-lg transition-all relative overflow-hidden"
            >
              {/* Gradient Overlay on Hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#0066FF]/5 to-[#00BCD4]/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl" />

              {/* Content */}
              <div className="relative z-10 text-center">
                {/* Icon */}
                <div className="size-12 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                  <Building2 className="size-6 text-[#0066FF]" strokeWidth={1.5} />
                </div>

                {/* Partner Name */}
                <h3 className="font-bold text-[15px] text-[#0A0A0A] mb-1 group-hover:text-[#0066FF] transition-colors">
                  {partner.name}
                </h3>

                {/* Category Badge */}
                <div className="inline-flex items-center px-2 py-0.5 bg-[#F3F6F9] rounded-full">
                  <span className="text-[10px] font-semibold text-[#64748B] uppercase tracking-wide">
                    {partner.category}
                  </span>
                </div>
              </div>

              {/* Shine Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </motion.div>
          ))}
        </div>

        {/* Infinite Horizontal Auto-Scroll (Optional Visual Enhancement) */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="relative overflow-hidden"
        >
          <div className="flex gap-4 animate-scroll">
            {infinitePartners.map((partner, idx) => (
              <div
                key={idx}
                className="flex-shrink-0 w-[180px] bg-white/40 backdrop-blur-sm rounded-xl p-5 border border-gray-100/50 hover:bg-white/60 transition-all"
              >
                <div className="flex items-center justify-center gap-3">
                  <Award className="size-5 text-[#0066FF]" strokeWidth={1.5} />
                  <span className="font-bold text-sm text-[#0A0A0A] whitespace-nowrap">
                    {partner.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12"
        >
          {[
            { value: "40+", label: "Industry Partners" },
            { value: "1000+", label: "Placement Opportunities" },
            { value: "500+", label: "Internship Programs" },
            { value: "100%", label: "Curriculum Alignment" },
          ].map((stat, idx) => (
            <div
              key={idx}
              className="bg-white/40 backdrop-blur-sm rounded-xl p-5 border border-gray-100/50 text-center hover:bg-white/60 transition-all"
            >
              <div className="text-3xl font-extrabold text-[#0066FF] mb-1">
                {stat.value}
              </div>
              <div className="text-xs text-[#64748B] font-medium uppercase tracking-wide">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Custom Scroll Animation */}
      <style>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        .animate-scroll {
          animation: scroll 30s linear infinite;
        }

        .animate-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
    </section>
  );
}