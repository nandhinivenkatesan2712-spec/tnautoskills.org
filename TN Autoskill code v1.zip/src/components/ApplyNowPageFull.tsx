import { ApplyNowPage } from "./ApplyNowPage";

export function ApplyNowPageFull() {
  return <ApplyNowPage />;
}
