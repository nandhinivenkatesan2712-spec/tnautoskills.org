import { motion } from "motion/react";

export function MarqueeStrip() {
  const text1 = "TAMILNADU APEX SKILL DEVELOPMENT CENTRE FOR AUTOMOBILE";
  const text2 = "தமிழ்நாடு உயர்திறன் மேம்பாட்டு மையம் - ஆட்டோமொபைல்";

  return (
    <div className="relative bg-gradient-to-r from-[#e3f2fd] via-[#f0f7ff] to-[#e3f2fd] overflow-hidden border-b border-blue-100">
      <div className="py-2.5">
        <motion.div
          animate={{
            x: [0, -1000],
          }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: "loop",
              duration: 25,
              ease: "linear",
            },
          }}
          className="flex whitespace-nowrap gap-12"
        >
          {[...Array(10)].map((_, i) => (
            <div key={i} className="flex items-center gap-12 shrink-0">
              <span className="text-[#004ABB] text-sm tracking-wide font-medium">
                {text1}
              </span>
              <span className="text-gray-400">•</span>
              <span
                className="text-[#004ABB] text-sm tracking-wide font-medium"
                style={{ fontFamily: "'Noto Sans Tamil UI', sans-serif" }}
              >
                {text2}
              </span>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}