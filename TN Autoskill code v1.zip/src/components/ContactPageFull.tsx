import { motion, useInView, AnimatePresence } from "motion/react";
import { useRef, useState } from "react";
import { Mail, Phone, MapPin, CheckCircle, X } from "lucide-react";

export function ContactPageFull() {
  const headerRef = useRef(null);
  const contactInfoRef = useRef(null);
  const formRef = useRef(null);
  const mapRef = useRef(null);

  const isHeaderInView = useInView(headerRef, { once: true, margin: "-100px" });
  const isContactInfoInView = useInView(contactInfoRef, { once: true, margin: "-100px" });
  const isFormInView = useInView(formRef, { once: true, margin: "-100px" });
  const isMapInView = useInView(mapRef, { once: true, margin: "-100px" });

  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const [errors, setErrors] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    const newErrors = {
      name: "",
      email: "",
      phone: "",
      message: "",
    };

    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.email.trim()) newErrors.email = "Email is required";
    if (!formData.phone.trim()) newErrors.phone = "Phone is required";
    if (!formData.message.trim()) newErrors.message = "Message is required";

    setErrors(newErrors);

    // Check if there are any errors
    if (Object.values(newErrors).some(error => error !== "")) {
      return;
    }

    // Show success modal
    setShowSuccessModal(true);
    
    // Reset form
    setFormData({
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    });

    // Auto-close after 3.5 seconds
    setTimeout(() => {
      setShowSuccessModal(false);
    }, 3500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    // Clear error when user starts typing
    if (errors[name as keyof typeof errors]) {
      setErrors({
        ...errors,
        [name]: "",
      });
    }
  };

  return (
    <div className="bg-white">
      {/* Success Modal */}
      <AnimatePresence>
        {showSuccessModal && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50"
              onClick={() => setShowSuccessModal(false)}
            />
            
            {/* Modal */}
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                transition={{ type: "spring", duration: 0.5 }}
                className="bg-white rounded-2xl shadow-2xl p-10 max-w-md w-full relative"
              >
                {/* Close Button */}
                <button
                  onClick={() => setShowSuccessModal(false)}
                  className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="size-5 text-gray-500" />
                </button>

                {/* Success Icon with Animation */}
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="mx-auto mb-6 size-16 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-full flex items-center justify-center"
                >
                  <motion.div
                    initial={{ scale: 0, rotate: -90 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
                  >
                    <CheckCircle className="size-10 text-white" strokeWidth={2.5} />
                  </motion.div>
                </motion.div>

                {/* Success Message */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-center"
                >
                  <p className="text-[17px] text-[#475569] leading-[1.6]">
                    Your message has been sent. Our team will contact you shortly.
                  </p>
                </motion.div>
              </motion.div>
            </div>
          </>
        )}
      </AnimatePresence>

      {/* Main Contact Section */}
      <section className="py-[120px] bg-white relative">
        {/* Subtle Section Divider Top */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E2E8F0] to-transparent" />

        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          {/* 1. Section Header */}
          <motion.div
            ref={headerRef}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16 space-y-4"
          >
            <h1 className="text-5xl lg:text-6xl font-extrabold text-[#0066FF] tracking-tight">
              Contact Us
            </h1>
            <p className="text-[17px] text-[#475569] leading-[1.6] max-w-3xl mx-auto">
              We're here to help. Connect with TN AutoSkills for any support.
            </p>
          </motion.div>

          {/* 2. Get in Touch - Quick Contact Card (Horizontal) */}
          <motion.div
            ref={contactInfoRef}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="mb-20"
          >
            <div className="bg-white rounded-xl border-2 border-[#E2E8F0] shadow-sm hover:shadow-xl hover:shadow-[#0066FF]/10 transition-all duration-300 p-8 lg:p-10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Phone */}
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <div className="p-3 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-lg">
                      <Phone className="size-6 text-white" strokeWidth={2} />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0A0A0A] mb-1">Phone</h3>
                    <a 
                      href="tel:+919445158093"
                      className="text-[15px] text-[#475569] hover:text-[#0066FF] transition-colors"
                    >
                      +91 94451 58093
                    </a>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <div className="p-3 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-lg">
                      <Mail className="size-6 text-white" strokeWidth={2} />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0A0A0A] mb-1">Email</h3>
                    <a 
                      href="mailto:info@tnautoskills.org"
                      className="text-[15px] text-[#475569] hover:text-[#0066FF] transition-colors break-all"
                    >
                      info@tnautoskills.org
                    </a>
                  </div>
                </div>

                {/* Address */}
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <div className="p-3 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-lg">
                      <MapPin className="size-6 text-white" strokeWidth={2} />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0A0A0A] mb-1">Address</h3>
                    <p className="text-[15px] text-[#475569] leading-[1.6]">
                      1st Floor, 42, Alandur Rd, Guindy, Chennai - 600032
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* 3. Send Us a Message - Contact Form */}
          <motion.div
            ref={formRef}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="mb-20"
          >
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-extrabold text-[#0A0A0A] mb-3">
                Send Us a Message
              </h2>
              <p className="text-[17px] text-[#475569] leading-[1.6] max-w-2xl mx-auto">
                Fill out the form below and we'll get back to you shortly
              </p>
            </div>

            <div className="bg-white rounded-xl border-2 border-[#E2E8F0] shadow-sm p-8 lg:p-10 max-w-[900px] mx-auto">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Two-column layout on desktop */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Name */}
                  <div>
                    <label 
                      htmlFor="name" 
                      className="block font-bold text-[#0A0A0A] mb-2"
                    >
                      Name<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 bg-white border-2 ${errors.name ? 'border-red-500' : 'border-[#E2E8F0]'} rounded-lg focus:outline-none focus:border-[#0066FF] hover:border-[#94A3B8] transition-all text-[#0A0A0A]`}
                      placeholder="Your name"
                    />
                    {errors.name && (
                      <p className="mt-1.5 text-sm text-red-500">{errors.name}</p>
                    )}
                  </div>

                  {/* Email */}
                  <div>
                    <label 
                      htmlFor="email" 
                      className="block font-bold text-[#0A0A0A] mb-2"
                    >
                      Email Address<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 bg-white border-2 ${errors.email ? 'border-red-500' : 'border-[#E2E8F0]'} rounded-lg focus:outline-none focus:border-[#0066FF] hover:border-[#94A3B8] transition-all text-[#0A0A0A]`}
                      placeholder="your.email@example.com"
                    />
                    {errors.email && (
                      <p className="mt-1.5 text-sm text-red-500">{errors.email}</p>
                    )}
                  </div>

                  {/* Phone */}
                  <div>
                    <label 
                      htmlFor="phone" 
                      className="block font-bold text-[#0A0A0A] mb-2"
                    >
                      Phone Number<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 bg-white border-2 ${errors.phone ? 'border-red-500' : 'border-[#E2E8F0]'} rounded-lg focus:outline-none focus:border-[#0066FF] hover:border-[#94A3B8] transition-all text-[#0A0A0A]`}
                      placeholder="+91 98765 43210"
                    />
                    {errors.phone && (
                      <p className="mt-1.5 text-sm text-red-500">{errors.phone}</p>
                    )}
                  </div>

                  {/* Subject */}
                  <div>
                    <label 
                      htmlFor="subject" 
                      className="block font-bold text-[#0A0A0A] mb-2"
                    >
                      Subject
                    </label>
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 bg-white border-2 border-[#E2E8F0] rounded-lg focus:outline-none focus:border-[#0066FF] hover:border-[#94A3B8] transition-all text-[#0A0A0A]"
                      placeholder="Brief subject"
                    />
                  </div>
                </div>

                {/* Message - Full Width */}
                <div>
                  <label 
                    htmlFor="message" 
                    className="block font-bold text-[#0A0A0A] mb-2"
                  >
                    Message<span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    rows={5}
                    className={`w-full px-4 py-3 bg-white border-2 ${errors.message ? 'border-red-500' : 'border-[#E2E8F0]'} rounded-lg focus:outline-none focus:border-[#0066FF] hover:border-[#94A3B8] transition-all resize-none text-[#0A0A0A]`}
                    placeholder="Tell us how we can help..."
                  />
                  {errors.message && (
                    <p className="mt-1.5 text-sm text-red-500">{errors.message}</p>
                  )}
                </div>

                {/* Submit Button */}
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-lg font-bold shadow-sm hover:shadow-lg transition-all"
                >
                  Submit Message
                </motion.button>
              </form>
            </div>
          </motion.div>

          {/* 4. Address and Map Section */}
          <motion.div
            ref={mapRef}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Left: Address Details */}
              <div className="bg-white rounded-xl border-2 border-[#E2E8F0] shadow-sm hover:shadow-xl hover:shadow-[#0066FF]/10 transition-all duration-300 p-10 h-full flex flex-col justify-center">
                <div className="p-4 bg-gradient-to-br from-[#0066FF] to-[#0090FF] rounded-xl w-fit mb-6">
                  <MapPin className="size-7 text-white" strokeWidth={2} />
                </div>
                
                <h3 className="text-2xl lg:text-3xl font-extrabold text-[#0A0A0A] mb-4">
                  Visit Our Campus
                </h3>
                
                <div className="space-y-3">
                  <p className="text-[17px] text-[#475569] leading-[1.6]">
                    <strong className="text-[#0A0A0A]">TN AutoSkills</strong>
                  </p>
                  <p className="text-[17px] text-[#475569] leading-[1.6]">
                    1st Floor, 42, Alandur Rd,<br />
                    Thiru Vi Ka Industrial Estate,<br />
                    SIDCO Industrial Estate,<br />
                    Guindy, Chennai,<br />
                    Tamil Nadu – 600032
                  </p>
                  
                  <div className="pt-4 space-y-2">
                    <div className="flex items-center gap-3">
                      <Phone className="size-5 text-[#0066FF]" strokeWidth={2} />
                      <a href="tel:+919445158093" className="text-[15px] text-[#475569] hover:text-[#0066FF] transition-colors">
                        +91 94451 58093
                      </a>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="size-5 text-[#0066FF]" strokeWidth={2} />
                      <a href="mailto:info@tnautoskills.org" className="text-[15px] text-[#475569] hover:text-[#0066FF] transition-colors">
                        info@tnautoskills.org
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: Map */}
              <div className="bg-white rounded-xl border-2 border-[#E2E8F0] shadow-sm overflow-hidden h-[450px]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.4719425916845!2d80.21526931482208!3d13.006912590826766!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5267b5e88c0001%3A0x1!2sGuindy%2C%20Chennai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1234567890123!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="TN AutoSkills Location"
                  className="w-full h-full"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
