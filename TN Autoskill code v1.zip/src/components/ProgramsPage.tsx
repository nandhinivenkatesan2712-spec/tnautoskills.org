import { UnifiedBanner } from "./UnifiedBanner";
import { FeaturedTrainingPrograms } from "./FeaturedTrainingPrograms";

export function ProgramsPage() {
  return (
    <div className="bg-white">
      <UnifiedBanner
        title="Training Programs"
        subtitle="Industry-certified automotive training programs designed for career success"
        badge={
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/95 backdrop-blur-sm rounded-full shadow-md border border-[#0066FF]/20">
            <div className="size-2 bg-[#0066FF] rounded-full animate-pulse" />
            <span className="text-sm font-semibold text-[#0A0A0A]">
              Programs
            </span>
          </div>
        }
      />
      <FeaturedTrainingPrograms />
    </div>
  );
}
