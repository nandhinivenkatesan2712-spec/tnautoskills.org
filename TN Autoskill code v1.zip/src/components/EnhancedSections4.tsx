import { motion, useInView } from "motion/react";
import { useRef } from "react";
import {
  UserPlus,
  Heart,
  GraduationCap,
  CheckCircle,
  ArrowRight,
  Users,
  BookOpen,
  Sparkles,
} from "lucide-react";

// 12. HR REGISTRATION - Enhanced CTA Card
export function EnhancedHRRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-16 bg-gradient-to-b from-[#F8FAFB] to-white relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#0066FF]/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-5xl mx-auto px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="relative bg-gradient-to-br from-white to-gray-50 rounded-3xl p-10 lg:p-12 shadow-2xl border border-gray-100 overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#0066FF]/5 to-transparent rounded-full blur-2xl" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-[#0090FF]/5 to-transparent rounded-full blur-2xl" />

          <div className="grid lg:grid-cols-[58%_42%] gap-10 items-center relative z-10">
            {/* Left Content */}
            <div className="space-y-5">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#0090FF]/10 rounded-full border border-[#0066FF]/20">
                <UserPlus className="size-3.5 text-[#0066FF]" />
                <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Recruitment</span>
              </div>

              {/* Title */}
              <h2 className="text-3xl lg:text-5xl font-extrabold text-[#0A0A0A] leading-tight">
                HR Registration for Recruitment
              </h2>

              {/* Description */}
              <p className="text-base text-[#475569] leading-relaxed">
                Register your organization to access our pool of trained and certified automotive professionals. Connect with skilled candidates ready to join your workforce.
              </p>

              {/* Features */}
              <ul className="space-y-3">
                {[
                  "Access to 2500+ trained candidates",
                  "Industry-certified professionals",
                  "Streamlined recruitment process",
                  "Customized skill matching",
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <div className="size-6 rounded-full bg-[#0066FF]/10 flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="size-4 text-[#0066FF]" />
                    </div>
                    <span className="text-[15px] text-[#475569]">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Right CTA */}
            <div className="flex flex-col gap-4">
              <a
                href="#hr-register"
                className="px-7 py-5 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-base shadow-xl hover:shadow-2xl hover:scale-105 transition-all text-center"
              >
                Register Now
              </a>
              <a
                href="#contact"
                className="px-7 py-5 bg-white text-[#0066FF] border-2 border-[#0066FF] rounded-xl font-bold text-base hover:bg-[#0066FF]/5 transition-all text-center"
              >
                Contact Us
              </a>
              
              {/* Info Text */}
              <p className="text-xs text-[#64748B] text-center mt-2">
                Free registration • Quick approval • Instant access
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// 13. CSR PROJECTS - Enhanced Project Cards
export function EnhancedCSRProjects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const projects = [
    {
      icon: Heart,
      title: "Community Skill Development",
      description: "Partner with us to provide free automotive training to underprivileged youth and create employment opportunities in rural Tamil Nadu.",
      impact: "500+ beneficiaries trained",
      gradient: "from-rose-500 to-pink-600",
      bgGradient: "from-rose-50 to-pink-50",
    },
    {
      icon: GraduationCap,
      title: "Women in Automotive Initiative",
      description: "Support our program to train and empower women in automotive technology, breaking gender barriers in the industry.",
      impact: "200+ women professionals",
      gradient: "from-purple-500 to-indigo-600",
      bgGradient: "from-purple-50 to-indigo-50",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gradient-to-br from-[#0066FF]/5 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-gradient-to-tr from-[#0090FF]/5 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0066FF]/10 to-[#0090FF]/10 rounded-full border border-[#0066FF]/20 mb-5">
            <Heart className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Social Impact</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] mb-5 leading-[1.1] tracking-tight">
            CSR Projects
          </h2>

          <p className="text-lg text-[#64748B] max-w-3xl mx-auto leading-relaxed">
            Collaborate with us on Corporate Social Responsibility initiatives to create lasting social impact
          </p>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {projects.map((project, idx) => {
            const Icon = project.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.2 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group relative bg-gradient-to-br from-white to-gray-50 rounded-3xl p-10 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all overflow-hidden"
              >
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${project.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity`} />

                <div className="relative z-10">
                  {/* Icon */}
                  <div className={`size-20 bg-gradient-to-br ${project.gradient} rounded-2xl flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 group-hover:rotate-6 transition-all`}>
                    <Icon className="size-10 text-white" strokeWidth={2.5} />
                  </div>

                  {/* Title */}
                  <h3 className="text-2xl font-bold text-[#0A0A0A] mb-4 leading-tight">
                    {project.title}
                  </h3>

                  {/* Description */}
                  <p className="text-base text-[#475569] leading-relaxed mb-6">
                    {project.description}
                  </p>

                  {/* Impact Badge */}
                  <div className="inline-flex items-center gap-3 px-5 py-3 bg-white rounded-xl shadow-md border border-gray-100">
                    <Users className="size-5 text-[#0066FF]" />
                    <span className="text-sm font-bold text-[#0066FF]">{project.impact}</span>
                  </div>
                </div>

                {/* Decorative Element */}
                <div className={`absolute -bottom-10 -right-10 size-40 bg-gradient-to-br ${project.gradient} opacity-10 rounded-full blur-2xl`} />
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#csr-register"
            className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-[15px] shadow-lg hover:shadow-2xl hover:scale-105 transition-all"
          >
            <span>CSR Partnership Registration</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 14. ACADEMIA & ALUMNI - Enhanced Two-Card Design
export function EnhancedAcademiaAlumni() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const cards = [
    {
      icon: BookOpen,
      title: "Academia Support",
      points: [
        "Curriculum co-development and faculty training programs",
        "Student placement and direct industry connections",
        "Research collaboration and innovation initiatives",
      ],
      gradient: "from-blue-500 to-indigo-600",
      bgGradient: "from-blue-50 to-indigo-50",
    },
    {
      icon: Users,
      title: "Alumni Support",
      points: [
        "Continuous upskilling and certification programs",
        "Career advancement support and mentorship",
        "Networking opportunities and industry events",
      ],
      gradient: "from-purple-500 to-pink-600",
      bgGradient: "from-purple-50 to-pink-50",
    },
  ];

  return (
    <section ref={ref} className="py-16 bg-gradient-to-b from-[#F8FAFB] to-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-gray-100 mb-5">
            <Sparkles className="size-3.5 text-[#0066FF]" />
            <span className="text-xs font-bold text-[#0066FF] uppercase tracking-wider">Education Network</span>
          </div>

          <h2 className="text-4xl lg:text-[56px] font-extrabold text-[#0A0A0A] mb-5 leading-[1.1] tracking-tight">
            Academia & Alumni Support
          </h2>

          <p className="text-lg text-[#64748B] max-w-3xl mx-auto leading-relaxed">
            We collaborate with engineering colleges, polytechnics, and ITIs to bridge the gap between academic learning and industry requirements
          </p>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {cards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: idx * 0.2 }}
                whileHover={{ y: -8 }}
                className="group relative bg-white rounded-3xl p-10 border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all overflow-hidden"
              >
                {/* Gradient Border Effect */}
                <div className={`absolute inset-0 bg-gradient-to-br ${card.gradient} opacity-0 group-hover:opacity-100 transition-opacity`} style={{ padding: '2px', borderRadius: '24px' }}>
                  <div className="w-full h-full bg-white rounded-3xl" />
                </div>

                {/* Background Pattern on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${card.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity`} />

                <div className="relative z-10">
                  {/* Icon */}
                  <div className={`size-20 bg-gradient-to-br ${card.gradient} rounded-2xl flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 group-hover:rotate-6 transition-all`}>
                    <Icon className="size-10 text-white" strokeWidth={2.5} />
                  </div>

                  {/* Title */}
                  <h3 className="text-2xl font-bold text-[#0A0A0A] mb-6 leading-tight">
                    {card.title}
                  </h3>

                  {/* Points */}
                  <ul className="space-y-4">
                    {card.points.map((point, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="mt-1 size-6 rounded-full bg-[#0066FF]/10 flex items-center justify-center flex-shrink-0">
                          <CheckCircle className="size-4 text-[#0066FF]" />
                        </div>
                        <span className="text-base text-[#475569] leading-relaxed">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Decorative Element */}
                <div className={`absolute -bottom-12 -right-12 size-48 bg-gradient-to-br ${card.gradient} opacity-5 rounded-full blur-3xl`} />
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <a
            href="#academia"
            className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-bold text-[15px] shadow-lg hover:shadow-2xl hover:scale-105 transition-all"
          >
            <span>Partner With Us</span>
            <ArrowRight className="size-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// 15. PLACEMENT REGISTRATION - Enhanced Gradient CTA
export function EnhancedPlacementRegistration() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-16 bg-white relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-br from-[#0066FF]/10 to-[#0090FF]/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-5xl mx-auto px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="relative bg-gradient-to-br from-[#0066FF] via-[#0055DD] to-[#0090FF] rounded-3xl p-12 lg:p-16 text-center text-white shadow-2xl overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-80 h-80 bg-white rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-white rounded-full blur-3xl" />
          </div>

          <div className="relative z-10 space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-md rounded-full border border-white/30">
              <GraduationCap className="size-3.5 text-white" />
              <span className="text-xs font-bold uppercase tracking-wider">For Colleges</span>
            </div>

            {/* Title */}
            <h2 className="text-4xl lg:text-5xl font-extrabold leading-tight max-w-3xl mx-auto">
              College Placement Registration
            </h2>

            {/* Description */}
            <p className="text-lg text-white/90 leading-relaxed max-w-2xl mx-auto">
              Register your college to enable your students to access placement opportunities with leading automotive companies through TN Auto Skills.
            </p>

            {/* Features */}
            <div className="flex flex-wrap justify-center gap-6 text-base">
              {["Free Registration", "Direct Industry Connections", "100% Placement Support"].map((item, i) => (
                <div key={i} className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-5 py-3 rounded-full border border-white/20">
                  <CheckCircle className="size-5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <a
              href="#placement-register"
              className="inline-flex items-center gap-3 px-10 py-5 bg-white text-[#0066FF] rounded-xl font-bold text-lg shadow-2xl hover:shadow-3xl hover:scale-105 transition-all"
            >
              <span>College Registration</span>
              <ArrowRight className="size-6" />
            </a>

            {/* Additional Info */}
            <p className="text-sm text-white/70">
              Join 500+ colleges already registered with TN Auto Skills
            </p>
          </div>

          {/* Decorative Elements */}
          <div className="absolute top-8 right-8 size-24 bg-white/10 rounded-2xl rotate-12 blur-xl" />
          <div className="absolute bottom-8 left-8 size-20 bg-white/10 rounded-2xl -rotate-12 blur-xl" />
        </motion.div>
      </div>
    </section>
  );
}
