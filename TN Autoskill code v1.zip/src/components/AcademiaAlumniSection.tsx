import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { GraduationCap, Users, BookOpen, Award, ArrowRight } from "lucide-react";

export function AcademiaAlumniSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const offerings = [
    {
      icon: GraduationCap,
      title: "Faculty Training Programs",
      description: "Professional development workshops for academic faculty in automotive technologies",
    },
    {
      icon: BookOpen,
      title: "Curriculum Co-Development",
      description: "Collaborate with us to design industry-aligned academic programs",
    },
    {
      icon: Users,
      title: "Alumni Network Support",
      description: "Exclusive career guidance, mentorship, and networking opportunities for graduates",
    },
    {
      icon: Award,
      title: "Certification & Recognition",
      description: "Academic partnerships with certification programs and industry recognition",
    },
  ];

  return (
    <section ref={ref} className="py-20 bg-white relative overflow-hidden">
      {/* Subtle Background Accent */}
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-[#0066FF]/5 to-transparent rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl lg:text-[52px] font-extrabold text-[#0A1628] leading-tight mb-3">
            Academia & Alumni Support
          </h2>
          <p className="text-xl lg:text-[22px] text-[#475569] font-medium leading-relaxed max-w-4xl mx-auto">
            Support for institutions, alumni groups, placement cells, and academic initiatives.
          </p>
        </motion.div>

        {/* 2×2 Grid of Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {offerings.map((offering, idx) => {
            const Icon = offering.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 + idx * 0.1 }}
                whileHover={{ y: -4 }}
                className="group bg-gradient-to-br from-white to-[#F8FAFB] rounded-xl p-6 border border-gray-100 hover:border-[#0066FF]/30 hover:shadow-lg transition-all"
              >
                {/* Icon */}
                <div className="size-12 bg-gradient-to-br from-[#0066FF]/10 to-[#00BCD4]/10 rounded-lg flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Icon className="size-6 text-[#0066FF]" strokeWidth={2} />
                </div>

                {/* Title */}
                <h3 className="text-xl lg:text-[22px] font-bold text-[#0A1628] leading-tight mb-2">
                  {offering.title}
                </h3>

                {/* Description */}
                <p className="text-base lg:text-[17px] text-[#64748B] leading-relaxed">
                  {offering.description}
                </p>

                {/* Hover Indicator */}
                <div className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-[#0066FF] opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Learn more</span>
                  <ArrowRight className="size-3.5" strokeWidth={2.5} />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="text-center"
        >
          <a
            href="#academia-partnership"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#0066FF] to-[#0090FF] text-white rounded-xl font-semibold text-[15px] shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            <span>Explore Partnership Opportunities</span>
            <ArrowRight className="size-4" strokeWidth={2.5} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}