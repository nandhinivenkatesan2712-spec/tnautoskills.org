import { motion } from "motion/react";
import { useState } from "react";
import svgPaths from "../imports/svg-nlmkrgxccf";

const navItems = [
  { label: "Home", href: "#home", active: true },
  { label: "Programs", href: "#programs" },
  { label: "Courses", href: "#courses" },
  { label: "Partners", href: "#partners" },
  { label: "Success Stories", href: "#success-stories" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" }
];

export function Navigation() {
  const [activeItem, setActiveItem] = useState("Home");
  const [language, setLanguage] = useState<"EN" | "TA">("EN");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.4 }}
      className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200/50 shadow-sm"
    >
      <div className="max-w-[1440px] mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-2">
            {navItems.map((item, index) => (
              <motion.a
                key={item.label}
                href={item.href}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 + 0.5 }}
                onClick={() => setActiveItem(item.label)}
                className={`relative px-5 py-3 rounded-xl transition-colors ${
                  activeItem === item.label
                    ? "text-[#0f73f7]"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                <span className="relative z-10">{item.label}</span>
                {activeItem === item.label && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute inset-0 bg-blue-50 rounded-xl"
                    style={{ zIndex: 0 }}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                {activeItem === item.label && (
                  <motion.div
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 w-6 bg-[#0f73f7] rounded-full"
                  />
                )}
              </motion.a>
            ))}
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-4">
            {/* Language Switcher */}
            <div className="hidden md:flex items-center bg-gray-100/80 border border-gray-200/80 rounded-xl p-1 gap-1">
              <button
                onClick={() => setLanguage("EN")}
                className={`px-4 py-2 rounded-lg text-sm transition-all ${
                  language === "EN"
                    ? "bg-white text-[#0f73f7] shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage("TA")}
                className={`px-4 py-2 rounded-lg text-sm transition-all ${
                  language === "TA"
                    ? "bg-white text-[#0f73f7] shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }`}
                style={{ fontFamily: "'Noto Sans Tamil', sans-serif" }}
              >
                தமிழ்
              </button>
            </div>

            {/* Login Button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="hidden sm:flex items-center gap-3 px-6 py-3 border-2 border-[#0f73f7] text-[#0f73f7] rounded-xl hover:bg-blue-50 transition-colors"
            >
              <svg className="size-4.5" fill="none" viewBox="0 0 18 18">
                <path
                  d="M7.5 12.75L11.25 9L7.5 5.25"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.875"
                />
                <path
                  d="M11.25 9H2.25"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.875"
                />
                <path
                  d={svgPaths.p33c08740}
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.875"
                />
              </svg>
              <span>Login</span>
            </motion.button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-gray-600 hover:text-gray-900"
            >
              <svg className="size-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {mobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-gray-200 py-4 space-y-2"
          >
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => {
                  setActiveItem(item.label);
                  setMobileMenuOpen(false);
                }}
                className={`block px-4 py-3 rounded-xl transition-colors ${
                  activeItem === item.label
                    ? "bg-blue-50 text-[#0f73f7]"
                    : "text-slate-700 hover:bg-gray-50"
                }`}
              >
                {item.label}
              </a>
            ))}
            <div className="pt-4 border-t border-gray-200 space-y-2">
              <button className="w-full flex items-center justify-center gap-3 px-6 py-3 border-2 border-[#0f73f7] text-[#0f73f7] rounded-xl hover:bg-blue-50 transition-colors">
                <svg className="size-4.5" fill="none" viewBox="0 0 18 18">
                  <path
                    d="M7.5 12.75L11.25 9L7.5 5.25"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.875"
                  />
                  <path
                    d="M11.25 9H2.25"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.875"
                  />
                </svg>
                <span>Login</span>
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
}
