import svgPaths from "./svg-q2wila3vzz";

function EmploymentOpportunities() {
  return (
    <div className="absolute h-[65px] left-0 top-0 w-[1136px]" data-name="EmploymentOpportunities">
      <p className="absolute font-['Arial:Black',sans-serif] leading-[65px] left-[568.25px] not-italic text-[#0a1628] text-[52px] text-center text-nowrap top-[1.6px] translate-x-[-50%] whitespace-pre">Employment Opportunities</p>
    </div>
  );
}

function EmploymentOpportunities1() {
  return (
    <div className="absolute h-[35.75px] left-[120px] top-[77px] w-[896px]" data-name="EmploymentOpportunities">
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[35.75px] left-[448.13px] not-italic text-[22px] text-center text-nowrap text-slate-600 top-[-3.6px] translate-x-[-50%] whitespace-pre">Partner with TN AutoSkills across OEMs, Auto Suppliers, Retail, and Startups.</p>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute h-[112.75px] left-[32px] top-0 w-[1136px]" data-name="Container">
      <EmploymentOpportunities />
      <EmploymentOpportunities1 />
    </div>
  );
}

function Text() {
  return (
    <div className="absolute h-[22.5px] left-[24px] top-[12px] w-[149.688px]" data-name="Text">
      <p className="absolute font-['Arial:Bold',sans-serif] leading-[22.5px] left-[75px] not-italic text-[15px] text-center text-nowrap text-white top-[-1.2px] translate-x-[-50%] whitespace-pre">Explore Opportunities</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute left-[181.69px] size-[16px] top-[15.25px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d405500} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Link() {
  return (
    <div className="absolute bg-gradient-to-b from-[#0066ff] h-[46.5px] left-[489.15px] rounded-[14px] shadow-[0px_4px_6px_-1px_rgba(0,0,0,0.1),0px_2px_4px_-2px_rgba(0,0,0,0.1)] to-[#0090ff] top-[1117.55px] w-[221.688px]" data-name="Link">
      <Text />
      <Icon />
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute left-[385.75px] rounded-[2.13909e+07px] size-[382.5px] top-[407.85px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1.275px] border-[rgba(0,102,255,0.25)] border-solid inset-0 pointer-events-none rounded-[2.13909e+07px]" />
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute left-[449.5px] rounded-[2.13909e+07px] size-[255px] top-[471.6px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1.275px] border-[rgba(0,102,255,0.38)] border-solid inset-0 pointer-events-none rounded-[2.13909e+07px]" />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[44.625px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 45 45">
        <g id="Icon">
          <path d={svgPaths.p1c831900} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.78906" />
          <path d={svgPaths.p26aab900} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.78906" />
          <path d="M16.7344 31.6094H27.8906" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.78906" />
          <path d={svgPaths.p32a83e80} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.78906" />
        </g>
      </svg>
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute box-border content-stretch flex items-center justify-center left-[529.19px] rounded-[2.13909e+07px] shadow-[0px_7.969px_11.953px_-2.391px_rgba(0,0,0,0.1),0px_3.188px_4.781px_-3.188px_rgba(0,0,0,0.1)] size-[95.625px] top-[551.29px]" data-name="Container">
      <Icon1 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[23.763px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p19787c80} id="Vector" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d={svgPaths.p3f1b9d80} id="Vector_2" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
        </g>
      </svg>
    </div>
  );
}

function Container4() {
  return (
    <div className="relative rounded-[9.901px] shrink-0 size-[47.527px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex items-center justify-center relative size-[47.527px]">
        <Icon2 />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[24.754px] relative shrink-0 w-[137.432px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24.754px] relative w-[137.432px]">
        <p className="absolute font-['Arial:Bold',sans-serif] leading-[24.754px] left-[68.52px] not-italic text-[#0a1628] text-[19.803px] text-center text-nowrap top-[-1.78px] translate-x-[-50%] whitespace-pre">Auto Suppliers</p>
      </div>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[217.832px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[217.832px]">
        <p className="absolute font-['Arial:Regular',sans-serif] leading-[24.135px] left-[109.29px] not-italic text-[14.852px] text-center text-slate-500 top-[-1.39px] translate-x-[-50%] w-[201.989px]">Tier-1 and tier-2 automotive component partners for skilled talent</p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.882px] h-[160.527px] items-center left-[875px] top-[460px] w-[217.832px]" data-name="Container">
      <Container4 />
      <Heading />
      <Paragraph />
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[23.763px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p33d6f00} id="Vector" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d={svgPaths.pf5bc180} id="Vector_2" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d={svgPaths.p80fb480} id="Vector_3" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d="M1.98021 6.93108H21.7831" id="Vector_4" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d={svgPaths.p2113b680} id="Vector_5" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
        </g>
      </svg>
    </div>
  );
}

function Container6() {
  return (
    <div className="relative rounded-[9.901px] shrink-0 size-[47.527px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex items-center justify-center relative size-[47.527px]">
        <Icon3 />
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[24.754px] relative shrink-0 w-[136.12px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24.754px] relative w-[136.12px]">
        <p className="absolute font-['Arial:Bold',sans-serif] leading-[24.754px] left-[68.02px] not-italic text-[#0a1628] text-[19.803px] text-center text-nowrap top-[-1.78px] translate-x-[-50%] whitespace-pre">Retail Partners</p>
      </div>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[217.832px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[217.832px]">
        <p className="absolute font-['Arial:Regular',sans-serif] leading-[24.135px] left-[109.23px] not-italic text-[14.852px] text-center text-slate-500 top-[-1.39px] translate-x-[-50%] w-[210.901px]">Dealership and service networks upskilling for next-gen service</p>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.882px] h-[136.392px] items-center left-[480.58px] top-[859.91px] w-[217.832px]" data-name="Container">
      <Container6 />
      <Heading1 />
      <Paragraph1 />
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[23.763px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p30214600} id="Vector" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d={svgPaths.p12437380} id="Vector_2" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d={svgPaths.p16f8b200} id="Vector_3" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d={svgPaths.p12d43ac0} id="Vector_4" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
        </g>
      </svg>
    </div>
  );
}

function Container8() {
  return (
    <div className="relative rounded-[9.901px] shrink-0 size-[47.527px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex items-center justify-center relative size-[47.527px]">
        <Icon4 />
      </div>
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[24.754px] relative shrink-0 w-[78.11px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24.754px] relative w-[78.11px]">
        <p className="absolute font-['Arial:Bold',sans-serif] leading-[24.754px] left-[38.52px] not-italic text-[#0a1628] text-[19.803px] text-center text-nowrap top-[-1.78px] translate-x-[-50%] whitespace-pre">Startups</p>
      </div>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[217.832px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[217.832px]">
        <p className="absolute font-['Arial:Regular',sans-serif] leading-[24.135px] left-[109.08px] not-italic text-[14.852px] text-center text-slate-500 top-[-1.39px] translate-x-[-50%] w-[212.881px]">Innovation and mobility startups partnering for talent development</p>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.882px] h-[160.527px] items-center left-[61px] top-[459px] w-[217.832px]" data-name="Container">
      <Container8 />
      <Heading2 />
      <Paragraph2 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[23.763px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M11.8816 15.8424H11.8914" id="Vector" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d="M15.8421 15.8424H15.8519" id="Vector_2" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d={svgPaths.p1586bf00} id="Vector_3" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
          <path d="M7.92118 15.8424H7.93098" id="Vector_4" stroke="var(--stroke-0, #0066FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.98029" />
        </g>
      </svg>
    </div>
  );
}

function Container10() {
  return (
    <div className="relative rounded-[9.901px] shrink-0 size-[47.527px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex items-center justify-center relative size-[47.527px]">
        <Icon5 />
      </div>
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[24.754px] relative shrink-0 w-[53.22px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24.754px] relative w-[53.22px]">
        <p className="absolute font-['Arial:Bold',sans-serif] leading-[24.754px] left-[27.51px] not-italic text-[#0a1628] text-[19.803px] text-center text-nowrap top-[-1.78px] translate-x-[-50%] whitespace-pre">OEMs</p>
      </div>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[217.832px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[217.832px]">
        <p className="absolute font-['Arial:Regular',sans-serif] leading-[24.135px] left-[109.32px] not-italic text-[14.852px] text-center text-slate-500 top-[-1.39px] translate-x-[-50%] w-[190.108px]">Original equipment manufacturers partnering for workforce development</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.882px] h-[160.527px] items-center left-[469.4px] top-[157px] w-[217.832px]" data-name="Container">
      <Container10 />
      <Heading3 />
      <Paragraph3 />
    </div>
  );
}

export default function Container12() {
  return (
    <div className="relative size-full" data-name="Container">
      <Container />
      <Link />
      <Container1 />
      <Container2 />
      <Container3 />
      <Container5 />
      <Container7 />
      <Container9 />
      <Container11 />
    </div>
  );
}